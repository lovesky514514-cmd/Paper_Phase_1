"""阻止工具适配器误连接外部地址；验证幂等与并发访问。"""
import threading
import unittest

from vgrouter.model import Effect
from vgrouter.tools import HttpTool, MemoryTool


class ToolsTests(unittest.TestCase):
    def test_http_only_localhost(self):
        for address in ("https://127.0.0.1:8912", "http://evil.test:8912",
                        "http://127.0.0.1:8912@evil.test", "http://127.0.0.1:8912/path",
                        "http://127.0.0.1:8912/?redirect=evil", "http://localhost"):
            with self.assertRaises(ValueError, msg=address):
                HttpTool(address)
        self.assertIsInstance(HttpTool(), HttpTool)

    def test_opaque_append_is_not_idempotent(self):
        tool = MemoryTool()
        for _ in range(2):
            tool.apply("a", "b", Effect.OPAQUE, "x", "same")
        self.assertEqual(tool.read("a", "b"), ["x", "x"])

    def test_stable_idempotent_key(self):
        tool = MemoryTool()
        a = tool.apply("a", "b", Effect.IDEMPOTENT, "x", "k")
        b = tool.apply("a", "b", Effect.IDEMPOTENT, "y", "k")
        self.assertEqual(a, b)
        self.assertEqual(tool.read("a", "b"), ["x"])

    def test_concurrent_writes(self):
        tool = MemoryTool()
        threads = [threading.Thread(target=tool.apply, args=("a", "b", Effect.OPAQUE, "x", "k"))
                   for _ in range(50)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(len(tool.read("a", "b")), 50)


if __name__ == "__main__":
    unittest.main()
