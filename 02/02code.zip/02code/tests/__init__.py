"""可由标准库 unittest 发现的测试。"""
