"""业务终态、失败升级与硬预算的回归测试。"""
import unittest

from vgrouter.config import defaults
from vgrouter.model import Effect, Step, Task
from vgrouter.runner import Runner
from vgrouter.tools import MemoryTool


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tool = MemoryTool()
        self.runner = Runner(defaults(), self.tool)

    def make_task(self, effect, outputs, trusted=False, risk=.08, budget=.05, success=.60):
        return Task("fixture", (Step("a", effect, "good", outputs, severity=1,
                                    trusted_contract=trusted),),
                    risk_limit=risk, budget_usd=budget, success_floor=success)

    def test_contract_rejects_all_wrong_before_side_effect(self):
        task = self.make_task(Effect.OPAQUE, {"S": "bad", "M": "bad", "L": "bad"}, trusted=True)
        result = self.runner.run(task)
        self.assertEqual(result.status, "validation_stop")
        self.assertEqual(self.tool.read("fixture", "a"), [])
        self.assertTrue(result.safe)

    def test_opaque_without_evidence_refuses(self):
        task = self.make_task(Effect.OPAQUE, {"S": "good", "M": "good", "L": "good"})
        result = self.runner.run(task)
        self.assertEqual(result.status, "escalate")
        self.assertEqual(self.tool.read("fixture", "a"), [])

    def test_fallback_consumes_rework_and_only_one_write(self):
        task = self.make_task(Effect.OPAQUE, {"S": "bad", "M": "bad", "L": "good"}, trusted=True)
        result = self.runner.run(task)
        self.assertTrue(result.success, result.steps)
        self.assertEqual(self.tool.read("fixture", "a"), ["good"])
        self.assertGreater(result.cost.rework, 0)
        self.assertEqual(result.steps[0].get("fallback_model"), "L")

    def test_nonverified_write_can_damage_state(self):
        task = self.make_task(Effect.REVERSIBLE, {"S": "bad", "M": "bad", "L": "bad"},
                              risk=1, success=.10)
        result = self.runner.run(task, "never_verify")
        self.assertFalse(result.success)
        self.assertFalse(result.safe)
        self.assertEqual(self.tool.read("fixture", "a"), ["bad"])

    def test_budget_never_exceeded_with_fallback(self):
        task = self.make_task(Effect.OPAQUE, {"S": "bad", "M": "bad", "L": "good"},
                              trusted=True, budget=.0035)
        result = self.runner.run(task)
        self.assertLessEqual(result.cost.total, task.budget_usd + 1e-10)

    def test_dependency_requires_topological_order(self):
        task = Task("bad", (Step("a", Effect.READ, "x", {"S": "x"}, depends_on=("b",)),))
        with self.assertRaises(ValueError):
            self.runner.run(task)

    def test_read_does_not_mutate_state(self):
        task = self.make_task(Effect.READ, {"S": "good", "M": "good", "L": "good"})
        result = self.runner.run(task)
        self.assertTrue(result.success)
        self.assertEqual(self.tool.read("fixture", "a"), [])

    def test_unknown_network_write_is_not_retried(self):
        class Unknown:
            def __init__(self):
                self.calls = 0
            def apply(self, *args):
                self.calls += 1
                raise TimeoutError("lost response")
            def read(self, *args):
                return []
        unknown = Unknown()
        task = self.make_task(Effect.OPAQUE, {"S": "good", "M": "good", "L": "good"}, trusted=True)
        result = Runner(defaults(), unknown).run(task)
        self.assertEqual(result.status, "unknown_effect")
        self.assertEqual(unknown.calls, 1)
        self.assertIsNone(result.safe, "写入状态未知不得错误上报为安全")
        self.assertGreater(result.cost.tool, 0, "不确定响应仍需计入已发起工具费用")

    def test_no_success_from_http_only(self):
        class Lies(MemoryTool):
            def read(self, *args):
                return ["bad"]
        task = self.make_task(Effect.IDEMPOTENT, {"S": "good", "M": "good", "L": "good"}, trusted=True)
        result = Runner(defaults(), Lies()).run(task)
        self.assertFalse(result.success)
        self.assertFalse(result.safe)


if __name__ == "__main__":
    unittest.main()
