"""评测可重复性、费用口径与任务拆分。"""
import tempfile
from pathlib import Path
import json
import unittest

from vgrouter.bench import POLICIES, benchmark, evaluate
from vgrouter.fixtures import tasks


class BenchTests(unittest.TestCase):
    def test_split_is_disjoint(self):
        all_tasks = tasks()
        self.assertEqual(len(all_tasks), 36)
        for split in ("train", "dev", "test"):
            self.assertEqual(len([t for t in all_tasks if t.split == split]), 12)
        self.assertEqual(len({t.task_id for t in all_tasks}), 36)

    def test_all_policies_replay_deterministically(self):
        for policy in POLICIES:
            a, _ = evaluate(policy)
            b, _ = evaluate(policy)
            self.assertEqual(a, b, policy)
            self.assertEqual(a["task_count"], 12)

    def test_total_includes_breakdown(self):
        report, _ = evaluate("vgr")
        self.assertAlmostEqual(report["total_cost_usd_synthetic"],
                               sum(report["cost_breakdown_usd_synthetic"].values()))

    def test_files_saved_and_tagged_synthetic(self):
        with tempfile.TemporaryDirectory() as dirname:
            benchmark(Path(dirname))
            metadata = json.loads((Path(dirname) / "metadata.json").read_text())
            self.assertEqual(metadata["kind"], "SYNTHETIC_OFFLINE_REPLAY")
            self.assertGreater((Path(dirname) / "traces.jsonl").stat().st_size, 0)


if __name__ == "__main__":
    unittest.main()
