"""持久化审计与重复写入拒绝。"""
import sqlite3
import tempfile
from pathlib import Path
import unittest

from vgrouter.config import defaults
from vgrouter.ledger import OutcomeLedger
from vgrouter.model import Effect, Step, Task
from vgrouter.runner import Runner
from vgrouter.tools import MemoryTool


class LedgerTests(unittest.TestCase):
    def test_append_and_uniqueness(self):
        with tempfile.TemporaryDirectory() as dirname:
            ledger = OutcomeLedger(Path(dirname) / "audit.db")
            task = Task("sample", (Step("read", Effect.READ, "ok",
                                       {"S": "ok", "M": "ok", "L": "ok"}),))
            result = Runner(defaults(), MemoryTool()).run(task)
            ledger.append(result)
            self.assertEqual(ledger.count(), 1)
            with self.assertRaises(sqlite3.IntegrityError):
                ledger.append(result)
            self.assertEqual(ledger.count(), 1)

    def test_record_does_not_store_contents(self):
        with tempfile.TemporaryDirectory() as dirname:
            ledger = OutcomeLedger(Path(dirname) / "audit.db")
            secret = "should-not-appear-in-audit"
            task = Task("sample", (Step("a", Effect.READ, secret,
                                       {"S": secret, "M": secret, "L": secret}),))
            ledger.append(Runner(defaults(), MemoryTool()).run(task))
            raw = (Path(dirname) / "audit.db").read_bytes()
            self.assertNotIn(secret.encode(), raw)
