"""面向路由接口的行为测试。"""
import unittest

from vgrouter.config import defaults
from vgrouter.model import Effect, Step, Verify
from vgrouter.policy import Limits, Router


class RouterTests(unittest.TestCase):
    def setUp(self):
        self.router = Router(defaults())
        self.limits = Limits(.04, 900, .08, .6)

    def step(self, effect=Effect.READ, trusted=False, severity=1):
        return Step("a", effect, "correct", {"S": "correct", "M": "correct", "L": "correct"},
                    severity=severity, trusted_contract=trusted)

    def test_no_opaque_without_trust(self):
        for policy in ("vgr", "never_verify", "cheapest", "strongest"):
            self.assertFalse(self.router.choose(self.step(Effect.OPAQUE), self.limits, policy).allowed)

    def test_opaque_requires_preflight(self):
        for policy in ("vgr", "strongest", "cheapest", "never_verify"):
            decision = self.router.choose(self.step(Effect.OPAQUE, True), self.limits, policy)
            if decision.allowed:
                self.assertEqual(decision.verify, Verify.CONTRACT)
            else:
                self.assertEqual(policy, "never_verify")

    def test_strongest_prefers_more_accurate(self):
        decision = self.router.choose(self.step(), self.limits, "strongest")
        self.assertEqual(decision.model, "L")

    def test_tiny_budget_stops(self):
        self.assertFalse(self.router.choose(self.step(), Limits(.00001, 900, .1, .1)).allowed)

    def test_tiny_deadline_stops(self):
        self.assertFalse(self.router.choose(self.step(), Limits(1, 1, .1, .1)).allowed)

    def test_risk_blocks_unverified_write(self):
        decision = self.router.choose(self.step(Effect.REVERSIBLE, True), Limits(.04, 900, .001, .6))
        self.assertTrue(decision.allowed)
        self.assertEqual(decision.verify, Verify.CONTRACT)

    def test_deterministic_random_policy(self):
        x = self.step(Effect.IDEMPOTENT, True)
        self.assertEqual(self.router.choose(x, self.limits, "random"),
                         self.router.choose(x, self.limits, "random"))

    def test_unknown_policy_raises(self):
        with self.assertRaises(ValueError):
            self.router.choose(self.step(), self.limits, "invalid")

    def test_poor_model_quality_can_force_escalation(self):
        decision = self.router.choose(self.step(), Limits(.04, 900, .1, 1))
        self.assertFalse(decision.allowed)


if __name__ == "__main__":
    unittest.main()
