# 出错先看这里

| 现象 | 检查与修复 |
|---|---|
| `python` / `py` / `go` not found | 安装 Python 3.11+ 和 Go 1.21+，重新打开终端，运行 `python --version` / `go version` |
| `ModuleNotFoundError: vgrouter` | 切换到 `02code` 根目录再运行 `python -m vgrouter demo`；不要从 `scripts` 目录启动 |
| 8911 / 8912 端口已占用 | 关闭之前的实验进程；`netstat -ano` (Windows) 或 `lsof -i :8912` (macOS/Linux) 找占用者 |
| Go 沙箱连接被拒绝 | 先启动 `scripts/start_windows.bat` 或 `sh scripts/start.sh`；确认 `/health` 返回 `ok` |
| HTTP 400 `unknown fixture task_id` | `GET http://127.0.0.1:8911/tasks` 查看存在的测试 ID；不支持提交真实订单 |
| HTTP 503 / `unknown_effect` | Go 未启动或连接中断；**不要重试不透明写入**，先查沙箱状态/重启隔离试验 |
| `escalate` / `validation_stop` | 属于预期的安全停止；阅读单步 `reason` 并检查可信契约、预算、模型配置 |
| `wrong_terminal_state` | 路由结果与工具状态不符；这是可用来分析的合成失败，不代表程序崩溃 |
| `sqlite3.IntegrityError` | 检查是否将相同 run_id 写两次；应给每次运行独立 ID，不要覆盖历史记录 |
| 压缩包中没有 `data/results` | 结果属于运行产物；在根目录执行 `python -m vgrouter bench` 重新生成 |

**逐文件排错**：每个程序/脚本文件对应一个独立文档。

- [`vgrouter/__init__.py`](files/vgrouter____init___py.md)
- [`vgrouter/model.py`](files/vgrouter__model_py.md)
- [`vgrouter/config.py`](files/vgrouter__config_py.md)
- [`vgrouter/policy.py`](files/vgrouter__policy_py.md)
- [`vgrouter/fixtures.py`](files/vgrouter__fixtures_py.md)
- [`vgrouter/tools.py`](files/vgrouter__tools_py.md)
- [`vgrouter/runner.py`](files/vgrouter__runner_py.md)
- [`vgrouter/bench.py`](files/vgrouter__bench_py.md)
- [`vgrouter/server.py`](files/vgrouter__server_py.md)
- [`vgrouter/ledger.py`](files/vgrouter__ledger_py.md)
- [`vgrouter/__main__.py`](files/vgrouter____main___py.md)
- [`mock/main.go`](files/mock__main_go.md)
- [`mock/main_test.go`](files/mock__main_test_go.md)
- [`mock/go.mod`](files/mock__go_mod.md)
- [`scripts/check.sh`](files/scripts__check_sh.md)
- [`scripts/start.sh`](files/scripts__start_sh.md)
- [`scripts/wait.py`](files/scripts__wait_py.md)
- [`scripts/smoke_http.py`](files/scripts__smoke_http_py.md)
- [`scripts/check_windows.bat`](files/scripts__check_windows_bat.md)
- [`scripts/start_windows.bat`](files/scripts__start_windows_bat.md)
- [`tests/__init__.py`](files/tests____init___py.md)
- [`tests/test_policy.py`](files/tests__test_policy_py.md)
- [`tests/test_runner.py`](files/tests__test_runner_py.md)
- [`tests/test_bench.py`](files/tests__test_bench_py.md)
- [`tests/test_tools.py`](files/tests__test_tools_py.md)
- [`tests/test_ledger.py`](files/tests__test_ledger_py.md)
- [`.gitignore`](files/_gitignore.md)
完整自检：`sh scripts/check.sh` 或双击 `scripts/check_windows.bat`。检查失败时不要把代码当作可投入真实业务的系统。
