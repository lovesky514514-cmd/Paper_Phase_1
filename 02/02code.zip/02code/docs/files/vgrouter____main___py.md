# `vgrouter/__main__.py`

**职责**：CLI 入口。

**典型症状**：命令参数无效。

**排查和修复**：在根目录执行 python -m vgrouter --help，检查 bench/demo/serve 子命令。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
