# `vgrouter/fixtures.py`

**职责**：合成任务生成器。

**典型症状**：结果与示例不一致。

**排查和修复**：确保 SHA-256 任务生成规则、count 与 train/dev/test 分离不变。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
