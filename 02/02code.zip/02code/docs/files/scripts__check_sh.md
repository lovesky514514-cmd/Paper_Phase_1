# `scripts/check.sh`

**职责**：Unix 全量自检。

**典型症状**：权限或命令找不到。

**排查和修复**：使用 sh scripts/check.sh；核对 python3、go 位于 PATH。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
