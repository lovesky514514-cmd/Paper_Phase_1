# `tests/test_tools.py`

**职责**：适配器测试。

**典型症状**：非环回地址允许或并发计数不准。

**排查和修复**：校验 urlsplit 检查与 MemoryTool 锁。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
