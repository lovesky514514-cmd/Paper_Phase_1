# `tests/__init__.py`

**职责**：测试包标记。

**典型症状**：测试无法发现。

**排查和修复**：从项目根目录运行 python -m unittest discover -s tests。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
