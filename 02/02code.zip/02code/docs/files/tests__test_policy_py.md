# `tests/test_policy.py`

**职责**：路由行为测试。

**典型症状**：意外选模或安全门失效。

**排查和修复**：先复现单个测试，再检查 policy.py 的候选过滤。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
