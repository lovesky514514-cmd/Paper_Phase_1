# `scripts/wait.py`

**职责**：沙箱就绪探针。

**典型症状**：等待超时。

**排查和修复**：先手工访问本机 Go /health；确认端口和防火墙。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
