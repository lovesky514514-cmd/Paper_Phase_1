# `.gitignore`

**职责**：生成物排除规则。

**典型症状**：误把缓存或二进制提交。

**排查和修复**：确认仅排除 __pycache__/、*.exe、结果文件等。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
