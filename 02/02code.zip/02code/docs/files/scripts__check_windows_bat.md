# `scripts/check_windows.bat`

**职责**：Windows 自检。

**典型症状**：找不到 py 或 go。

**排查和修复**：确认环境变量 PATH 并从资源管理器双击或 cmd 运行。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
