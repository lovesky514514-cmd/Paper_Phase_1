# `scripts/start.sh`

**职责**：Unix 启动入口。

**典型症状**：启动后服务退出。

**排查和修复**：使用 sh scripts/start.sh，查 8912 被占用或 Go 编译失败。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
