# `mock/main_test.go`

**职责**：Go 并发与幂等测试。

**典型症状**：竞态、重复写入计数不对。

**排查和修复**：运行 go test -race；确保 map 修改和读取在同一互斥锁保护下。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
