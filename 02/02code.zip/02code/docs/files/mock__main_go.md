# `mock/main.go`

**职责**：Go 合成工具服务器。

**典型症状**：Go 编译错误、重复副作用。

**排查和修复**：在 mock 目录执行 go test；不透明写入重复追加是设计行为。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
