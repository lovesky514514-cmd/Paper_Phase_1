# `scripts/start_windows.bat`

**职责**：Windows 双服务启动。

**典型症状**：窗口一闪而过。

**排查和修复**：在 cmd 运行脚本查看错误；安装 Go 和 Python，检查 8912 端口。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
