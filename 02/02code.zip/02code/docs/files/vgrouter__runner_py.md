# `vgrouter/runner.py`

**职责**：任务执行与预算。

**典型症状**：验证失败、状态不符、未知副作用。

**排查和修复**：定位 Outcome.steps 的 reason/check，先查依赖、契约再查工具回读。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
