# `vgrouter/model.py`

**职责**：领域对象。

**典型症状**：未知 effect / missing key。

**排查和修复**：检查 Effect/Verify 枚举、Step.outputs 模型名、任务预算和类型。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
