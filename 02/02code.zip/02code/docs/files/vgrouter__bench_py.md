# `vgrouter/bench.py`

**职责**：对照与指标。

**典型症状**：无报告或策略异常。

**排查和修复**：运行 python -m vgrouter bench --out data/results，确认 split 和虚拟成本口径。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
