# `vgrouter/__init__.py`

**职责**：公开入口。

**典型症状**：导入失败。

**排查和修复**：根目录运行；核对 Python 环境和导出的名称。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
