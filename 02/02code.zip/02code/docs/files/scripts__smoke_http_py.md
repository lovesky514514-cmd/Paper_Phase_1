# `scripts/smoke_http.py`

**职责**：HTTP 真实联动冒烟测试。

**典型症状**：固定端口冲突、服务未就绪。

**排查和修复**：停止旧测试进程后重新执行 python scripts/smoke_http.py。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
