# `tests/test_bench.py`

**职责**：合成对照测试。

**典型症状**：结果不稳定。

**排查和修复**：核对 fixtures.py SHA-256 生成与各任务使用独立工具实例。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
