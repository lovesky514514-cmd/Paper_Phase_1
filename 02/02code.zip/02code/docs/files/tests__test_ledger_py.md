# `tests/test_ledger.py`

**职责**：SQLite 测试。

**典型症状**：审计重复或泄露原文。

**排查和修复**：检查 UNIQUE run_id 和只保存结构化元数据。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
