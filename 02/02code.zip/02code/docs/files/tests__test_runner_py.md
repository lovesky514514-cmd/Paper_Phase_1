# `tests/test_runner.py`

**职责**：状态型任务测试。

**典型症状**：副作用重复、成本超限。

**排查和修复**：优先检查 runner.py 的执行前验证和预算扣费顺序。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
