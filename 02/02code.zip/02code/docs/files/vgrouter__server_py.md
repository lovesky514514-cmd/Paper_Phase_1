# `vgrouter/server.py`

**职责**：本机 HTTP 网关。

**典型症状**：400/503、端口占用。

**排查和修复**：用 /health、/tasks 核对；只允许固定 synthetic 任务。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
