# `vgrouter/policy.py`

**职责**：约束筛选与选择。

**典型症状**：意外停止、错误验证动作。

**排查和修复**：检查 Limits 和候选前安全门；运行 tests/test_policy.py。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
