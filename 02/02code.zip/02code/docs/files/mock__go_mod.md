# `mock/go.mod`

**职责**：Go 模块定义。

**典型症状**：go: go.mod file not found。

**排查和修复**：切换到 mock 目录运行 Go 命令，检查 Go 版本大于等于 1.21。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
