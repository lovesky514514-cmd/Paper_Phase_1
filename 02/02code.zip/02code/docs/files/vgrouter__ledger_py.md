# `vgrouter/ledger.py`

**职责**：SQLite 结果账本。

**典型症状**：数据库锁、重复 run_id。

**排查和修复**：关闭僵尸进程、检查 8911 端口；重复 ID 不得覆盖旧实验。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
