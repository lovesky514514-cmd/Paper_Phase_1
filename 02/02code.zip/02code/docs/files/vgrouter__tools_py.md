# `vgrouter/tools.py`

**职责**：状态服务 adapter。

**典型症状**：连接失败、地址非法。

**排查和修复**：先测 Go /health；仅连接本机，勿改成远程真实服务。

**基础自检**：在项目根目录执行 `python -m unittest discover -s tests -v`；Go 相关问题在 `mock/` 执行 `go test ./...`；改动后再跑全量 `scripts/check.sh` 或 `scripts/check_windows.bat`。
