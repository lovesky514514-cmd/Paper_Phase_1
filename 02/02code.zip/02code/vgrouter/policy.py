"""受约束路由：在硬约束筛选后按预期全成本挑选动作。"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib

from .model import Choice, Effect, ModelSpec, Settings, Step, Verify


@dataclass(frozen=True)
class Limits:
    budget_usd: float
    deadline_ms: float
    risk: float
    min_quality: float


class Router:
    """纯计算模块，易于离线评测；预测数值不是安全认证。"""

    def __init__(self, settings: Settings):
        self.settings = settings

    def choose(self, step: Step, limits: Limits, policy: str = "vgr") -> Choice:
        models = [model for model in self.settings.models if model.enabled]
        if not models:
            return self._stop("无可用模型")
        if step.effect is Effect.OPAQUE and not step.trusted_contract:
            return self._stop("不透明写入缺少可信的执行前契约")
        if not 0 <= limits.risk <= 1 or limits.budget_usd < 0 or limits.deadline_ms < 0:
            return self._stop("剩余预算或风险约束无效")

        choices: list[tuple[float, Choice]] = []
        for model in models:
            for verify in self._verify_options(policy, step):
                candidate = self._candidate(model, step, verify)
                if step.effect is Effect.OPAQUE and verify is not Verify.CONTRACT:
                    continue
                if candidate.predicted_cost_usd > limits.budget_usd + 1e-12:
                    continue
                if candidate.predicted_latency_ms > limits.deadline_ms:
                    continue
                # 固定强弱基线保留同样的硬安全准入，避免越权执行。
                if policy in {"vgr", "no_effect", "no_verify_cost", "always_verify", "never_verify"}:
                    if model.success_rate(step.effect) + 1e-12 < limits.min_quality:
                        continue
                if candidate.predicted_risk > limits.risk + 1e-12:
                    continue
                quality = model.success_rate(step.effect)
                score = candidate.predicted_cost_usd + (1 - quality) * (
                    self.settings.rework_cost_usd + self.settings.failure_penalty_usd
                )
                if policy == "no_rework":
                    score = candidate.predicted_cost_usd
                if policy == "no_verify_cost":
                    score -= self.settings.verify_cost_usd[verify]
                if policy == "cheapest":
                    score = model.price_usd + self.settings.verify_cost_usd[verify]
                if policy == "strongest":
                    score = -quality
                if policy == "quality_only":
                    score = -quality
                if policy == "rules":
                    target = {Effect.READ: "S", Effect.REVERSIBLE: "M",
                              Effect.IDEMPOTENT: "M", Effect.OPAQUE: "L"}[step.effect]
                    score = (0 if model.name == target else 10) + candidate.predicted_cost_usd
                if policy == "random":
                    # 与输入绑定的伪随机顺序，消除测试中的非确定性。
                    digest = hashlib.sha256(f"{step.step_id}/{step.expected}/{model.name}/{verify.value}".encode()).digest()
                    score = int.from_bytes(digest[:8], "big") / 2**64
                choices.append((score, candidate))
        if not choices:
            return self._stop("无动作同时满足预算、时限、质量与风险准入")
        return min(choices, key=lambda item: (item[0], item[1].predicted_cost_usd, item[1].model or ""))[1]

    def _candidate(self, model: ModelSpec, step: Step, verify: Verify) -> Choice:
        s = self.settings
        quality = model.success_rate(step.effect)
        # CONTRACT 是执行前的可信精确值校验；只有已经验证了契约来源才可用。
        risk = 0.0 if step.effect is Effect.READ or verify is Verify.CONTRACT else (1 - quality) * step.severity
        cost = model.price_usd + s.verify_cost_usd[verify] + s.router_cost_usd + s.tool_cost_usd
        latency = model.latency_ms + s.verify_latency_ms[verify] + s.router_latency_ms + s.tool_latency_ms
        return Choice(model.name, verify, cost, risk, latency, "满足约束")

    @staticmethod
    def _verify_options(policy: str, step: Step) -> tuple[Verify, ...]:
        if policy == "always_verify":
            return (Verify.CONTRACT,) if step.trusted_contract else (Verify.SCHEMA,)
        if policy == "never_verify":
            return (Verify.NONE,)
        if policy == "no_effect":
            # 消融：不利用业务严重性来决定是否强验证，但保留不可逆写入的强制门禁。
            return (Verify.CONTRACT,) if step.effect is Effect.OPAQUE else (Verify.NONE, Verify.SCHEMA)
        if policy == "quality_only":
            return (Verify.CONTRACT,) if step.effect is Effect.OPAQUE else (Verify.NONE,)
        if policy in {"vgr", "no_rework", "no_verify_cost", "cheapest", "strongest", "rules", "random"}:
            return (Verify.NONE, Verify.SCHEMA, Verify.CONTRACT) if step.trusted_contract else (Verify.NONE, Verify.SCHEMA)
        raise ValueError(f"未知策略: {policy}")

    @staticmethod
    def _stop(reason: str) -> Choice:
        return Choice(None, Verify.NONE, 0, 0, 0, reason)
