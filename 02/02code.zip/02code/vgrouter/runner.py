"""执行固定合成任务；评测真值与网关允许看到的证据分离。"""
from __future__ import annotations

from dataclasses import dataclass, asdict

from .model import Effect, Settings, Step, Task, Verify
from .policy import Limits, Router


@dataclass
class Cost:
    model: float = 0.0
    verifier: float = 0.0
    router: float = 0.0
    tool: float = 0.0
    rework: float = 0.0

    @property
    def total(self) -> float:
        return round(self.model + self.verifier + self.router + self.tool + self.rework, 10)


@dataclass
class Outcome:
    task_id: str
    split: str
    policy: str
    status: str
    safe: bool | None
    success: bool
    cost: Cost
    virtual_latency_ms: float
    verified_steps: int
    attempted_steps: int
    steps: list[dict]

    def to_dict(self) -> dict:
        raw = asdict(self)
        raw["cost"]["total"] = self.cost.total
        return raw


class Runner:
    """测试接口为 run(task, policy)：依赖由调用方传入的工具 adapter。"""

    def __init__(self, settings: Settings, tool):
        self.settings = settings
        self.router = Router(settings)
        self.tool = tool

    def run(self, task: Task, policy: str = "vgr") -> Outcome:
        if not task.task_id or not task.steps:
            raise ValueError("任务必须包含唯一标识和至少一个步骤")
        self._check_graph(task)
        cost = Cost()
        elapsed = 0.0
        consumed_risk = 0.0
        estimated_quality = 1.0
        completed: set[str] = set()
        events: list[dict] = []
        unsafe = False
        effect_unknown = False
        verified = 0
        status = "success"
        for index, step in enumerate(task.steps):
            if not set(step.depends_on).issubset(completed):
                status = "blocked"
                break
            if cost.total + self.settings.router_cost_usd > task.budget_usd:
                status = "budget_stop"
                break
            cost.router += self.settings.router_cost_usd
            elapsed += self.settings.router_latency_ms
            remaining = len(task.steps) - index
            # 必须使剩余步骤的乘积质量预估达到整任务保底目标。
            min_quality = min(1.0, (task.success_floor / estimated_quality) ** (1 / remaining))
            choice = self.router.choose(step, Limits(
                task.budget_usd - cost.total, task.deadline_ms - elapsed,
                task.risk_limit - consumed_risk, min_quality,
            ), policy)
            event = {"step_id": step.step_id, "effect": step.effect.value,
                     "model": choice.model, "verify": choice.verify.value,
                     "predicted_risk": choice.predicted_risk, "reason": choice.reason}
            events.append(event)
            if not choice.allowed:
                status = "escalate"
                break
            model = self.settings.by_name(choice.model)
            # 消耗模型费用与延迟；实际 LLM 尚未接入，均为合成观测值。
            cost.model += model.price_usd
            elapsed += model.latency_ms
            answer = step.outputs[model.name]
            if not self._check(step, answer, choice.verify, cost):
                elapsed += self.settings.verify_latency_ms[choice.verify]
                event["check"] = "failed"
                # 一次有限升级：仅从更可靠模型中选择，且先核验硬预算。
                upgraded = self._fallback(step, model.name, task, cost, elapsed)
                if upgraded is None:
                    status = "validation_stop"
                    break
                stronger, answer = upgraded
                cost.rework += stronger.price_usd
                elapsed += stronger.latency_ms
                model = stronger
                event["fallback_model"] = stronger.name
                if not self._check(step, answer, choice.verify, cost):
                    elapsed += self.settings.verify_latency_ms[choice.verify]
                    status = "validation_stop"
                    break
                elapsed += self.settings.verify_latency_ms[choice.verify]
            else:
                elapsed += self.settings.verify_latency_ms[choice.verify]
                event["check"] = "passed"
            if cost.total + self.settings.tool_cost_usd > task.budget_usd:
                status = "budget_stop"
                break
            if elapsed + self.settings.tool_latency_ms > task.deadline_ms:
                status = "deadline_stop"
                break
            cost.tool += self.settings.tool_cost_usd
            elapsed += self.settings.tool_latency_ms
            try:
                response = self.tool.apply(task.task_id, step.step_id, step.effect,
                                           answer, f"{task.task_id}/{step.step_id}")
                state = self.tool.read(task.task_id, step.step_id)
            except (OSError, TimeoutError, ValueError) as exc:
                # 不盲目重放：提交是否生效未知，需要调查。
                event["error_type"] = type(exc).__name__
                effect_unknown = step.effect is not Effect.READ
                status = "unknown_effect"
                break
            expected_state = [] if step.effect is Effect.READ else [step.expected]
            effect_is_correct = state == expected_state
            answer_is_correct = response == step.expected
            unsafe |= step.effect is not Effect.READ and not effect_is_correct
            event["ground_truth_match"] = answer_is_correct and effect_is_correct
            # ground_truth_match 仅供测试评估器，真实流量不能从 HTTP 200 推断。
            if not answer_is_correct or not effect_is_correct:
                status = "wrong_terminal_state" if unsafe else "wrong_answer"
                break
            if choice.verify is Verify.CONTRACT:
                verified += 1
            completed.add(step.step_id)
            consumed_risk += choice.predicted_risk
            estimated_quality *= model.success_rate(step.effect)
        safe = None if effect_unknown else not unsafe
        return Outcome(task.task_id, task.split, policy, status, safe,
                       status == "success", cost, round(elapsed, 3), verified,
                       len(events), events)

    def _check(self, step: Step, answer: str, verify: Verify, cost: Cost) -> bool:
        cost.verifier += self.settings.verify_cost_usd[verify]
        if verify is Verify.NONE:
            return True
        if verify is Verify.SCHEMA:
            return isinstance(answer, str) and bool(answer.strip())
        return step.trusted_contract and answer == step.expected

    def _fallback(self, step: Step, previous: str, task: Task, cost: Cost,
                  elapsed: float):
        prev_quality = self.settings.by_name(previous).success_rate(step.effect)
        candidates = sorted((m for m in self.settings.models if m.enabled and
                             m.success_rate(step.effect) > prev_quality),
                            key=lambda m: m.price_usd)
        for model in candidates:
            # 失败后的额外验证和工具费用计入硬预算，不允许超支。
            needed = model.price_usd + self.settings.verify_cost_usd[Verify.CONTRACT] + self.settings.tool_cost_usd
            if needed + cost.total > task.budget_usd:
                continue
            if elapsed + model.latency_ms + self.settings.verify_latency_ms[Verify.CONTRACT] + self.settings.tool_latency_ms > task.deadline_ms:
                continue
            return model, step.outputs[model.name]
        return None

    @staticmethod
    def _check_graph(task: Task) -> None:
        visited: set[str] = set()
        for step in task.steps:
            if not step.step_id or step.step_id in visited:
                raise ValueError("步骤标识必须非空且唯一")
            if not set(step.depends_on).issubset(visited):
                raise ValueError("步骤应按依赖拓扑顺序声明")
            if not 0 <= step.severity <= 1 or not step.outputs:
                raise ValueError("工具严重性或输出矩阵无效")
            visited.add(step.step_id)
