"""实验运行的最小 SQLite 审计账本：只保存脱敏元数据。"""
from __future__ import annotations

from pathlib import Path
import json
import sqlite3

from .runner import Outcome


class OutcomeLedger:
    def __init__(self, path: str | Path = "data/outcomes.sqlite3"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                run_id TEXT NOT NULL UNIQUE,
                policy TEXT NOT NULL,
                status TEXT NOT NULL,
                safe INTEGER,
                success INTEGER NOT NULL,
                cost_usd REAL NOT NULL,
                virtual_latency_ms REAL NOT NULL,
                decisions_json TEXT NOT NULL
            )""")

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        db.execute("PRAGMA busy_timeout=5000")
        return db

    def append(self, result: Outcome) -> None:
        # 原始模型输出、凭据、上下文均不写入数据库。
        compact = [{"step_id": event["step_id"], "model": event["model"],
                    "verify": event["verify"], "reason": event["reason"]}
                   for event in result.steps]
        with self._connect() as db:
            db.execute("""INSERT INTO runs
                (run_id, policy, status, safe, success, cost_usd,
                 virtual_latency_ms, decisions_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                       (result.task_id, result.policy, result.status, None if result.safe is None else int(result.safe),
                        int(result.success), result.cost.total, result.virtual_latency_ms,
                        json.dumps(compact, ensure_ascii=False)))

    def count(self) -> int:
        with self._connect() as db:
            return db.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
