"""仅供本地展示的 HTTP 网关，入站不接受任意工具写入。"""
from __future__ import annotations

from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from uuid import uuid4

from .config import defaults
from .fixtures import tasks
from .policy import Limits, Router
from .ledger import OutcomeLedger
from .runner import Runner
from .tools import HttpTool


class Handler(BaseHTTPRequestHandler):
    dataset = {task.task_id: task for task in tasks()}
    tool_url = "http://127.0.0.1:8912"

    def do_GET(self):
        if self.path == "/health":
            self._send(200, {"status": "ok", "mode": "synthetic-sandbox-only"})
        elif self.path == "/tasks":
            self._send(200, {"task_ids": sorted(self.dataset)})
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path not in {"/route", "/run"}:
            return self._send(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > 8192:
                return self._send(400, {"error": "payload size invalid"})
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                return self._send(400, {"error": "JSON body must be an object"})
            task_id = payload.get("task_id")
            task = self.dataset.get(task_id)
            if task is None:
                return self._send(400, {"error": "unknown fixture task_id"})
            policy = payload.get("policy", "vgr")
            if policy != "vgr" and policy not in {"cheapest", "strongest", "rules", "always_verify", "never_verify"}:
                return self._send(400, {"error": "unknown demo policy"})
            if self.path == "/route":
                step = task.steps[0]
                choice = Router(defaults()).choose(step, Limits(task.budget_usd, task.deadline_ms,
                                                                task.risk_limit, task.success_floor ** (1 / len(task.steps))), policy)
                return self._send(200, {"task_id": task_id, "step_id": step.step_id,
                                        "model": choice.model, "verify": choice.verify.value,
                                        "reason": choice.reason})
            # 每次运行使用不同的隔离命名空间。绝不重放历史写入。
            unique = replace(task, task_id=f"{task.task_id}-{uuid4().hex[:16]}")
            # 沙箱中的工具通过 HTTP 真实执行，模型输出仍来自静态矩阵。
            outcome = Runner(defaults(), HttpTool(self.tool_url)).run(unique, policy)
            OutcomeLedger().append(outcome)
            return self._send(200, {"fixture_task_id": task_id, "run": outcome.to_dict()})
        except (OSError, TimeoutError, ValueError, TypeError, KeyError) as exc:
            return self._send(503, {"error": type(exc).__name__, "message": str(exc)[:150]})

    def _send(self, status: int, payload: dict):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):
        # 不记录请求体；实验端只在结果中展示合成任务标识。
        pass


def serve(port: int = 8911):
    if not 1024 <= port <= 65535:
        raise ValueError("port must be in 1024..65535")
    print(f"VGRouter demo: http://127.0.0.1:{port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
