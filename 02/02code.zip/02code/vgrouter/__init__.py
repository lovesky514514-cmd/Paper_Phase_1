"""VGRouter：面向有状态工具调用的合成研究网关。"""

from .config import defaults
from .policy import Router, Limits
from .runner import Runner

__all__ = ["Router", "Limits", "Runner", "defaults"]
