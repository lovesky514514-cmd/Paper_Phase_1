"""命令行入口：bench、demo、serve。"""
import argparse
import json
from pathlib import Path

from .bench import POLICIES, benchmark
from .config import defaults
from .fixtures import tasks
from .runner import Runner
from .server import serve
from .tools import MemoryTool


def main() -> None:
    parser = argparse.ArgumentParser(description="VGRouter 本地合成科研骨架")
    command = parser.add_subparsers(dest="command", required=True)
    bench = command.add_parser("bench", help="离线对照测试")
    bench.add_argument("--out", default="data/results")
    bench.add_argument("--split", choices=("train", "dev", "test"), default="test")
    demo = command.add_parser("demo", help="在进程内沙箱运行一个合成任务")
    demo.add_argument("--task", default="synthetic-034")
    demo.add_argument("--policy", choices=POLICIES, default="vgr")
    server = command.add_parser("serve", help="启动 127.0.0.1 HTTP 沙箱网关")
    server.add_argument("--port", type=int, default=8911)
    args = parser.parse_args()
    if args.command == "bench":
        report = benchmark(Path(args.out), args.split)
        for item in report:
            print(f"{item['policy']:15s} success={item['success_count']:2}/{item['task_count']} "
                  f"unsafe={item['unsafe_task_count']:2} "
                  f"synthetic_cost=${item['total_cost_usd_synthetic']:.5f}")
        print(f"结果保存到: {args.out}")
    elif args.command == "demo":
        task = next((task for task in tasks() if task.task_id == args.task), None)
        if task is None:
            parser.error("unknown task ID")
        print(json.dumps(Runner(defaults(), MemoryTool()).run(task, args.policy).to_dict(),
                         indent=2, ensure_ascii=False))
    elif args.command == "serve":
        serve(args.port)


if __name__ == "__main__":
    main()
