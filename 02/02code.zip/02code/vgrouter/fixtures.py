"""生成确定性的合成任务矩阵；与真实模型准确率无关。"""
from __future__ import annotations

import hashlib

from .model import Effect, Step, Task


def _score(key: str) -> float:
    return int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], "big") / 2**64


def tasks(count: int = 36) -> tuple[Task, ...]:
    suite: list[Task] = []
    qualities = {
        Effect.READ: (.84, .94, .98),
        Effect.REVERSIBLE: (.77, .89, .97),
        Effect.IDEMPOTENT: (.74, .88, .96),
        Effect.OPAQUE: (.64, .82, .93),
    }
    effects = tuple(Effect)
    for idx in range(count):
        effect = effects[idx % len(effects)]
        size = 1 + (idx % 3)
        sequence: list[Step] = []
        for j in range(size):
            kind = Effect.READ if j < size - 1 else effect
            identifier = f"synthetic-{idx:03d}"
            expected = f"ok-{idx}-{j}"
            outputs = {
                name: expected if _score(f"{idx}/{j}/{name}") < threshold else f"wrong-{idx}-{j}"
                for name, threshold in zip(("S", "M", "L"), qualities[kind])
            }
            sequence.append(Step(
                step_id=f"step-{j}", effect=kind, expected=expected, outputs=outputs,
                depends_on=(f"step-{j - 1}",) if j else (),
                severity=1.0 if kind is Effect.OPAQUE else .4,
                trusted_contract=(kind is not Effect.READ and idx % 7 != 0) or (idx % 5 == 0),
            ))
        # 任务模板隔离：留出完整测试组，避免任务 ID 层面泄漏。
        split = "train" if idx < count // 3 else "dev" if idx < 2 * count // 3 else "test"
        suite.append(Task(identifier, tuple(sequence), budget_usd=.028,
                          deadline_ms=1000, risk_limit=.08, success_floor=.62, split=split))
    return tuple(suite)
