"""领域对象：状态型工具调用和路由决策，不含网络/存储细节。"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Effect(str, Enum):
    READ = "read"
    REVERSIBLE = "reversible"
    IDEMPOTENT = "idempotent"
    OPAQUE = "opaque"


class Verify(str, Enum):
    NONE = "none"
    SCHEMA = "schema"
    CONTRACT = "contract"


@dataclass(frozen=True)
class ModelSpec:
    name: str
    price_usd: float
    latency_ms: float
    quality: dict[str, float]
    enabled: bool = True

    def success_rate(self, effect: Effect) -> float:
        return self.quality[effect.value]


@dataclass(frozen=True)
class Step:
    step_id: str
    effect: Effect
    expected: str
    outputs: dict[str, str]
    depends_on: tuple[str, ...] = ()
    severity: float = 1.0
    trusted_contract: bool = False


@dataclass(frozen=True)
class Task:
    task_id: str
    steps: tuple[Step, ...]
    budget_usd: float = 0.05
    deadline_ms: float = 2000.0
    risk_limit: float = 0.05
    success_floor: float = 0.65
    split: str = "test"


@dataclass(frozen=True)
class Choice:
    model: str | None
    verify: Verify
    predicted_cost_usd: float
    predicted_risk: float
    predicted_latency_ms: float
    reason: str

    @property
    def allowed(self) -> bool:
        return self.model is not None


@dataclass(frozen=True)
class Settings:
    models: tuple[ModelSpec, ...]
    verify_cost_usd: dict[Verify, float]
    verify_latency_ms: dict[Verify, float]
    router_cost_usd: float = 0.00004
    router_latency_ms: float = 2.0
    tool_cost_usd: float = 0.0001
    tool_latency_ms: float = 4.0
    failure_penalty_usd: float = 0.008
    rework_cost_usd: float = 0.002

    def by_name(self, name: str) -> ModelSpec:
        return next(model for model in self.models if model.name == name)
