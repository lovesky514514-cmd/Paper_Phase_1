"""固定种子下比较不同路由策略；仅用于科研原型验证。"""
from __future__ import annotations

from collections import Counter
import json
from pathlib import Path

from .config import defaults
from .fixtures import tasks
from .runner import Runner
from .tools import MemoryTool


POLICIES = (
    "vgr", "strongest", "cheapest", "rules", "random", "quality_only",
    "always_verify", "never_verify", "no_effect", "no_verify_cost", "no_rework",
)


def percentile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, int((len(ordered) - 1) * fraction + .999999))]


def evaluate(policy: str, split: str = "test") -> tuple[dict, list[dict]]:
    chosen = [task for task in tasks() if task.split == split]
    outcomes = [Runner(defaults(), MemoryTool()).run(task, policy) for task in chosen]
    total_cost = sum(outcome.cost.total for outcome in outcomes)
    completed = sum(outcome.success for outcome in outcomes)
    unsafe = sum(outcome.safe is False for outcome in outcomes)
    unknown = sum(outcome.safe is None for outcome in outcomes)
    steps = sum(outcome.attempted_steps for outcome in outcomes)
    verified = sum(outcome.verified_steps for outcome in outcomes)
    latency = [outcome.virtual_latency_ms for outcome in outcomes]
    selected = Counter(event["model"] for outcome in outcomes for event in outcome.steps if event["model"])
    summary = {
        "policy": policy, "split": split, "task_count": len(outcomes),
        "success_count": completed, "unsafe_task_count": unsafe,
        "unknown_effect_count": unknown,
        "task_success_rate": round(completed / len(outcomes), 4) if outcomes else 0,
        "unsafe_task_rate": round(unsafe / len(outcomes), 4) if outcomes else 0,
        "total_cost_usd_synthetic": round(total_cost, 8),
        "cost_per_success_usd_synthetic": round(total_cost / completed, 8) if completed else None,
        "success_per_usd_synthetic": round(completed / total_cost, 4) if total_cost else None,
        "verification_rate": round(verified / steps, 4) if steps else 0,
        "virtual_p95_ms": percentile(latency, .95),
        "virtual_p99_ms": percentile(latency, .99),
        "cost_breakdown_usd_synthetic": {
            field: round(sum(getattr(outcome.cost, field) for outcome in outcomes), 8)
            for field in ("model", "verifier", "router", "tool", "rework")
        },
        "model_calls": dict(sorted(selected.items())),
        "status_counts": dict(sorted(Counter(outcome.status for outcome in outcomes).items())),
    }
    return summary, [outcome.to_dict() for outcome in outcomes]


def benchmark(destination: Path, split: str = "test") -> list[dict]:
    destination.mkdir(parents=True, exist_ok=True)
    summary: list[dict] = []
    traces: list[dict] = []
    for policy in POLICIES:
        result, records = evaluate(policy, split)
        summary.append(result)
        traces.extend(records)
    (destination / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    (destination / "traces.jsonl").write_text("".join(json.dumps(item, ensure_ascii=False) + "\n" for item in traces), encoding="utf-8")
    (destination / "metadata.json").write_text(json.dumps({
        "kind": "SYNTHETIC_OFFLINE_REPLAY", "ground_truth": "fixture reference value",
        "model_price": "illustrative USD, not provider billing",
        "latency": "virtual, not measured P95", "frozen_split": split,
        "warning": "Neither real model performance nor SCI findings are established by this test.",
    }, indent=2), encoding="utf-8")
    return summary
