"""工具执行的两个真实 adapter：进程内测试版、Go HTTP 沙箱版。"""
from __future__ import annotations

import json
import threading
from urllib.request import Request, urlopen
from urllib.parse import urlsplit

from .model import Effect


class MemoryTool:
    """仅在合成试验中使用；写入效果与只读结果可检查。"""

    def __init__(self):
        self._state: dict[tuple[str, str], list[str]] = {}
        self._keys: dict[str, str] = {}
        self._lock = threading.Lock()

    def apply(self, task_id: str, step_id: str, effect: Effect, value: str, key: str) -> str:
        with self._lock:
            locator = (task_id, step_id)
            if effect is Effect.READ:
                return value
            if effect is Effect.IDEMPOTENT and key in self._keys:
                return self._keys[key]
            if effect is Effect.OPAQUE:
                self._state.setdefault(locator, []).append(value)
            else:
                self._state[locator] = [value]
            if effect is Effect.IDEMPOTENT:
                self._keys[key] = value
            return value

    def read(self, task_id: str, step_id: str) -> list[str]:
        with self._lock:
            return list(self._state.get((task_id, step_id), []))


class HttpTool:
    """仅连接本机受控 Go 沙箱，不发送真实客户数据。"""

    def __init__(self, base: str = "http://127.0.0.1:8912"):
        url = urlsplit(base)
        if (url.scheme != "http" or url.hostname not in {"127.0.0.1", "localhost"}
                or url.username or url.password or url.path not in {"", "/"}
                or url.query or url.fragment or url.port is None):
            raise ValueError("仅允许本机 Go 沙箱 HTTP 地址")
        self.base = base.rstrip("/")

    def _call(self, path: str, payload: dict) -> dict:
        request = Request(self.base + path, data=json.dumps(payload).encode(),
                          headers={"Content-Type": "application/json"}, method="POST")
        with urlopen(request, timeout=3) as response:
            return json.loads(response.read())

    def apply(self, task_id: str, step_id: str, effect: Effect, value: str, key: str) -> str:
        result = self._call("/apply", {"task_id": task_id, "step_id": step_id,
                                        "effect": effect.value, "value": value, "key": key})
        return result["value"]

    def read(self, task_id: str, step_id: str) -> list[str]:
        return self._call("/read", {"task_id": task_id, "step_id": step_id})["values"]
