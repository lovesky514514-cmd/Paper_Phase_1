"""示例估计参数；在正式实验中必须由开发集校准后冻结。"""
from .model import ModelSpec, Settings, Verify


def defaults() -> Settings:
    # 以下质量/价目均为合成数值，不代表任何厂商真实价格。
    return Settings(
        models=(
            ModelSpec("S", 0.00035, 24, {"read": .87, "reversible": .78, "idempotent": .76, "opaque": .66}),
            ModelSpec("M", 0.0012, 55, {"read": .95, "reversible": .90, "idempotent": .88, "opaque": .84}),
            ModelSpec("L", 0.0032, 115, {"read": .99, "reversible": .97, "idempotent": .96, "opaque": .94}),
        ),
        verify_cost_usd={Verify.NONE: 0, Verify.SCHEMA: .00006, Verify.CONTRACT: .0005},
        verify_latency_ms={Verify.NONE: 0, Verify.SCHEMA: 1, Verify.CONTRACT: 9},
    )
