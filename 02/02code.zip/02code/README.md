# 02code · VGRouter

**目标**：研究 Agent 在多模型之间路由时，如何把工具状态风险、检查开销、任务预算同时计入决策。

当前是**合成科研原型**，不是已校准算法或生产代理，不使用真实 LLM、MCP、支付/业务 API。

**安装**：Python **3.11+**、Go **1.21+**；**不用 pip、不用密钥**。

| 做什么 | Windows | macOS / Linux |
|---|---|---|
| 运行离线演示 | `py -3 -m vgrouter demo` | `python3 -m vgrouter demo` |
| 生成 11 组对照结果 | `py -3 -m vgrouter bench` | `python3 -m vgrouter bench` |
| 启动本地 HTTP 网关与 Go 沙箱 | 双击 `scripts/start_windows.bat` | `sh scripts/start.sh` |
| 完整自检 | 双击 `scripts/check_windows.bat` | `sh scripts/check.sh` |

命令需在**解压后的项目根目录**运行。离线报告写入 `data/results/`，启动 HTTP 后查看 `http://127.0.0.1:8911/health`。

**HTTP 示例**（另开终端）：

```bash
curl -X POST http://127.0.0.1:8911/run -H "Content-Type: application/json" -d '{"task_id":"synthetic-034"}'
```

只有预置假任务可调用；Go 假工具在 `127.0.0.1:8912`。HTTP 运行记录在 `data/outcomes.sqlite3`；均为合成元数据。

- 出错：先读 [排错索引](docs/DEBUG_INDEX.md)，逐文件帮助在 `docs/files/`。
- 架构与安全边界：[DESIGN](docs/DESIGN.md)；测试结论：[QUALITY](docs/QUALITY.md)。
- 原始选题：[research/02_original.md](research/02_original.md)。
