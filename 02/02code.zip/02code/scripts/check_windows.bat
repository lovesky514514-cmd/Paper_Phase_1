@echo off
setlocal
cd /d "%~dp0\.."
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m compileall -q vgrouter tests || goto :error
%PY% -m unittest discover -s tests -v || goto :error
cd mock
go test ./... || goto :error
go vet ./... || goto :error
rem Race detector requires cgo/C compiler on Windows; use scripts/check.sh on Linux for mandatory race check.
cd ..
%PY% -m vgrouter bench --out data/results || goto :error
%PY% scripts\smoke_http.py || goto :error
echo Tests passed. Results in data\results
pause
exit /b 0
:error
echo Check failed. See docs\DEBUG_INDEX.md
pause
exit /b 1
