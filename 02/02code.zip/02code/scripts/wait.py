"""等待本地 Go 假工具就绪；失败时给出明确退出码。"""
import sys
import time
from urllib.request import urlopen


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: python scripts/wait.py http://127.0.0.1:8912/health")
        return 2
    for _ in range(60):
        try:
            with urlopen(sys.argv[1], timeout=.3) as response:
                if response.status == 200:
                    return 0
        except OSError:
            time.sleep(.2)
    print("Go 沙箱未能就绪，请检查 Go 版本、端口和启动日志")
    return 1


if __name__ == "__main__":
    sys.exit(main())
