@echo off
setlocal
cd /d "%~dp0\.."
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
where go >nul 2>nul || (echo Go not found. Install Go 1.21+ & pause & exit /b 1)
if not exist data mkdir data
cd mock
go build -o ..\data\vgrouter-mock.exe . || (echo Go build failed & pause & exit /b 1)
cd ..
start "VGRouter Go sandbox" "%CD%\data\vgrouter-mock.exe"
%PY% scripts\wait.py http://127.0.0.1:8912/health || (pause & exit /b 1)
%PY% -m vgrouter serve
pause
