"""实际启动 Python 网关与 Go 沙箱，验证路由→执行→回读全过程。"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.request import urlopen, Request


ROOT = Path(__file__).resolve().parents[1]


def wait_for(url: str, proc: subprocess.Popen):
    for _ in range(120):
        if proc.poll() is not None:
            raise RuntimeError(f"服务提前退出: {url} rc={proc.returncode}")
        try:
            with urlopen(url, timeout=.3) as response:
                if response.status == 200:
                    return
        except OSError:
            time.sleep(.1)
    raise TimeoutError(f"等待服务超时: {url}")


def post(url, payload):
    request = Request(url, data=json.dumps(payload).encode(), method="POST",
                      headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=5) as response:
        return json.loads(response.read())


def main():
    python = sys.executable
    env = os.environ.copy()
    # 限制为固定本地测试端口；生产网络环境不应运行该脚本。
    with subprocess.Popen(["go", "run", "."], cwd=ROOT / "mock", stdout=subprocess.DEVNULL,
                          stderr=subprocess.PIPE) as tool:
        gateway = None
        try:
            wait_for("http://127.0.0.1:8912/health", tool)
            gateway = subprocess.Popen([python, "-m", "vgrouter", "serve"], cwd=ROOT,
                                       env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            wait_for("http://127.0.0.1:8911/health", gateway)
            routed = post("http://127.0.0.1:8911/route", {"task_id": "synthetic-034"})
            run = post("http://127.0.0.1:8911/run", {"task_id": "synthetic-034"})["run"]
            # 每次提交隔离任务 ID，避免沙箱遗留状态影响实验。
            again = post("http://127.0.0.1:8911/run", {"task_id": "synthetic-034"})["run"]
            assert routed["model"] is not None, routed
            assert run["status"] in {"success", "validation_stop", "escalate", "wrong_answer", "wrong_terminal_state"}, run
            assert run["task_id"] != again["task_id"], "consecutive runs not isolated"
            assert run["status"] == again["status"], (run, again)
            print(json.dumps({"route": routed, "first_run_status": run["status"],
                              "second_run_status": again["status"], "isolated": True}, ensure_ascii=False))
        finally:
            if gateway is not None:
                gateway.terminate()
                try: gateway.wait(timeout=3)
                except subprocess.TimeoutExpired: gateway.kill()
            tool.terminate()
            try: tool.wait(timeout=3)
            except subprocess.TimeoutExpired: tool.kill()


if __name__ == "__main__":
    main()
