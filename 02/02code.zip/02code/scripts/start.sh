#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
[ -d data ] || mkdir -p data
(cd mock && go build -o ../data/vgrouter-mock .)
./data/vgrouter-mock &
tool_pid=$!
cleanup() { kill "$tool_pid" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
python3 scripts/wait.py http://127.0.0.1:8912/health
python3 -m vgrouter serve
