#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
python3 -m compileall -q vgrouter tests
python3 -m unittest discover -s tests -v
(cd mock && go test ./... && go vet ./... && go test -race ./...)
python3 -m vgrouter bench --out data/results
python3 scripts/smoke_http.py
printf '\n通过：Python 测试、Go 测试/竞态检测、静态检查和合成评测\n'
