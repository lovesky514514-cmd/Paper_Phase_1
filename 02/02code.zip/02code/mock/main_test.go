package main

import (
	"sync"
	"testing"
)

func TestOpaqueAndIdempotency(t *testing.T) {
	s := newState()
	c := call{TaskID: "a", StepID: "b", Effect: "opaque", Value: "x"}
	for i := 0; i < 2; i++ {
		if _, err := s.apply(c); err != nil {
			t.Fatal(err)
		}
	}
	if len(s.read(c)) != 2 {
		t.Fatal("opaque should append twice")
	}
	c.Effect, c.Key = "idempotent", "unique"
	s.apply(c)
	c.Value = "changed"
	val, _ := s.apply(c)
	if val != "x" {
		t.Fatal("idempotency key must preserve first result")
	}
}

func TestConcurrentOpaque(t *testing.T) {
	s := newState()
	c := call{TaskID: "a", StepID: "b", Effect: "opaque", Value: "v"}
	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, err := s.apply(c); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if len(s.read(c)) != 100 {
		t.Fatal("lost writes")
	}
}
