// 本机合成工具：提供可核对的外部状态，不代表真实订单或支付服务。
package main

import (
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"os"
	"sync"
)

type call struct {
	TaskID string `json:"task_id"`
	StepID string `json:"step_id"`
	Effect string `json:"effect"`
	Value  string `json:"value"`
	Key    string `json:"key"`
}

type state struct {
	mu         sync.Mutex
	values     map[string][]string
	idempotent map[string]string
}

func newState() *state {
	return &state{values: make(map[string][]string), idempotent: make(map[string]string)}
}

func locator(r call) string { return r.TaskID + "\x00" + r.StepID }

func (s *state) apply(c call) (string, error) {
	if c.TaskID == "" || c.StepID == "" || c.Value == "" || len(c.Value) > 256 {
		return "", errors.New("invalid synthetic call")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	switch c.Effect {
	case "read":
		return c.Value, nil
	case "reversible":
		s.values[locator(c)] = []string{c.Value}
	case "idempotent":
		if c.Key == "" {
			return "", errors.New("missing idempotency key")
		}
		if prior, ok := s.idempotent[c.Key]; ok {
			return prior, nil
		}
		s.values[locator(c)] = []string{c.Value}
		s.idempotent[c.Key] = c.Value
	case "opaque":
		s.values[locator(c)] = append(s.values[locator(c)], c.Value)
	default:
		return "", errors.New("unknown effect")
	}
	return c.Value, nil
}

func (s *state) read(c call) []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]string{}, s.values[locator(c)]...)
}

func writeJSON(w http.ResponseWriter, status int, value interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func decode(w http.ResponseWriter, r *http.Request, c *call) bool {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST only"})
		return false
	}
	r.Body = http.MaxBytesReader(w, r.Body, 2048)
	if err := json.NewDecoder(r.Body).Decode(c); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON"})
		return false
	}
	return true
}

func server(s *state) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "mode": "synthetic"})
	})
	mux.HandleFunc("/apply", func(w http.ResponseWriter, r *http.Request) {
		var c call
		if !decode(w, r, &c) {
			return
		}
		value, err := s.apply(c)
		if err != nil {
			writeJSON(w, 400, map[string]string{"error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]string{"value": value})
	})
	mux.HandleFunc("/read", func(w http.ResponseWriter, r *http.Request) {
		var c call
		if !decode(w, r, &c) {
			return
		}
		writeJSON(w, 200, map[string]interface{}{"values": s.read(c)})
	})
	return mux
}

func main() {
	address := "127.0.0.1:8912"
	if len(os.Args) != 1 {
		log.Fatal("no command arguments supported")
	}
	log.Printf("synthetic tool listening at %s", address)
	log.Fatal(http.ListenAndServe(address, server(newState())))
}
