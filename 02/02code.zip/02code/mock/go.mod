module vgrouter/mock

go 1.21
