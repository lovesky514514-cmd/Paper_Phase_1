# Agent × 后端网关 SCI 选题研究包（第二篇）

> **研究方向 2：面向工具调用 Agent 的风险约束、验证开销感知多模型动态路由网关**  
> 建议英文题目：**VGRouter: Verification-Cost- and Execution-Risk-Aware Dynamic Routing for Tool-Using LLM Agents**  
> 研究日期：**2026-10-20** ｜目的：本科生/小团队选题论证、实验开工与 SCI 期刊规划  
> 状态：**研究假设与拟实施计划，不是已经完成实验的论文，也不保证录用**

## 阅读结论（最重要的 8 条）

1. **主观点**：选择便宜模型不等于完成任务更便宜。Agent 的真正成本包括**模型调用、路由器、验证器、失败重做、工具调用、等待延迟及错误外部状态**；最终应优化“可信完成一次任务的总成本”，而非“每个请求的 Token 价”。
2. **拟创新点**：在 HTTP/MCP/API 代理网关层，以任务执行图、工具步骤可验证性、执行风险、剩余预算与实时后端状态为输入，作**带拒绝/升级机制的路由决策**；计算验证器成本和失败后的重复执行成本，而不是把验证当成免费的真值标签。
3. **必须规避的撞题**：2026 年的 **R2-Router** 已优化模型与长度预算，**MTRouter / ProgRouter / EvoRoute** 已涉及多轮/逐步决策，**RACER** 已给出风险控制，**PROTEUS / SLARouter** 已研究 SLA，**ORACLE** 已做 Agent 任务验证反馈与并发调度。不得声称自己“首次提出多模型 Agent 动态路由 / 风险路由 / 验证器路由”。
4. **真正值得验证的差异**：将**可检查的外部工具状态正确性**与**不同操作的错误后果**纳入网关层的任务级选择，验证阶段是一个**有成本、可能出错的决策动作**。主结果须体现在**最终任务完成与不安全工具状态**，而不止静态 QA 准确率。
5. **实验最低线**：至少三类任务（只读检索、可逆写入、有副作用的非幂等写入），至少 3–4 个模型，6–8 个基线，**包括路由/验证/重试开销的全成本**，分离出分布内、分布外、服务价格波动和并发压力结果。
6. **低资源路线**：先离线做可重放的多模型结果矩阵，再连接真实的本地 HTTP 服务/模拟 MCP 服务，最后对小样本进行真实在线推理。**离线 replay 无法证明真实线上延迟与并发性能**，要单独测。
7. **期刊**：以**订阅方式无需缴纳 APC**、期刊范围匹配、实际投稿到录用历史天数为筛选标准。最建议 **Journal of Network and Computer Applications** / **Future Generation Computer Systems**；若创新主要在 AI 决策算法，可考虑 **Expert Systems with Applications**。**快不等于容易、审稿初筛也不等于录用**。
8. **资源索引**：下方列出 **46 篇不重复的论文/正式学术出版物或预印本**，含链接、年份、关联意义、优先级；会议论文不是 SCI 期刊论文，但可作为先行工作与基线。

---

## 0. 五个 Agent × 网关课题的主观点与创新点（系列总览）

| 方向 | 一句话主观点 | 提议的核心创新假设（都需要查新和实验） |
|---|---|---|
| 1. Agent 故障感知与安全恢复网关 | 失败恢复必须避免二次业务损害 | 将工具副作用证据和依赖图用于安全重试/局部恢复；第一篇已展开 |
| **2. 多模型动态路由与成本优化（本篇）** | 每次推理最便宜，不等于任务总体最便宜 | **工具状态风险 + 验证开销 + 任务级 SLO + 剩余预算**联合建模下，是否能改善可信完成率/美元的 Pareto 前沿 |
| 3. MCP 工具调用安全验证网关 | 被发现的工具不能自动获得信任 | 跨调用权限演化和执行时证据契约，限制高风险组合调用 |
| 4. 多 Agent 调度与拥塞控制 | Agent 的瓶颈同时来自 GPU、工具服务与外部限流 | 任务依赖 DAG、服务配额、尾延迟联动调度，避免局部优化引发全局拥塞 |
| 5. Agent 调用链异常检测与根因定位 | 最后报错处未必是最初错误源 | 结合调用拓扑、状态变化和反事实证据定位最小故障传播子图 |

## 1. 选题定位：为什么不是普通的 LLM Router？

### 1.1 场景

一台 Agent 同时可以调用低成本模型 S、中档模型 M 和高可靠模型 L，需要完成：`查客户信息 → 判断权限 → 创建工单 → 执行 API 写操作 → 检查写入结果 → 关闭工单`。

- “查看文档格式”判断错了，可能只损失一次重试；“创建订单/更改额度”判断错了，可能造成**实际外部状态错误**。两种步骤不应该按同一“问题复杂度”选择模型。
- 小模型某一步答错，表面调用费用低，但若后续发现错误要重做 5 步，**全任务总开销可能更高**。
- 便宜模型输出可以用便宜校验器检查，却不应假定每一步都能自动获得完美真值；`check_cost` 和 `check_error` 必须显式记录。
- 可用模型动态变化（响应超时、速率限制、价目/上下文长度调整），离线固定路由规则可能失效。

**本论文不尝试训练新基础大模型**；研究贡献来自**路由目标定义、约束决策方法、可靠反馈与可复现实验平台**。如有条件可训练小型路由器、轻量失败预测器；不需要 8 卡训练集群。

### 1.2 科研问题（RQ）

| RQ | 具体问题 | 必须呈现的证据 |
|---|---|---|
| RQ1 | 将**工具状态验证**和步骤错误后果加入路由，是否改善“业务任务成功/费用”前沿？ | 同一任务集的真实终态、实际总价与 Pareto 曲线 |
| RQ2 | 将验证视为可选且有成本的动作，是否比“一律验证”或“从不验证”更划算？ | 验证率、验证误报/漏报、验证器费用、额外 P95 延迟 |
| RQ3 | 预算、失败风险上限、P95 SLO 同时存在时，能否稳定达到约束？ | 约束达标率、违反幅度、最坏分组风险、可信区间 |
| RQ4 | 新模型接入、价格变化、负载波动、任务转域时是否比静态策略更稳健？ | OOD、价格漂移、并发压测、在线自适应曲线 |
| RQ5 | 网关级路由能否跨不同 Agent 框架与工具服务复用？ | 接口适配、实际接入工作量、抽象层开销 |

### 1.3 推荐核心创新（研究假设，并非已证明）

**H1 — Effect-Aware Routing（工具影响风险感知）**：除了预估“模型答对的概率”，显式建模**调用后外部状态的正确性、错误严重度、恢复代价**；对高代价写操作更谨慎，对低代价可回退步骤更积极节省调用。

**H2 — Verification Is Not Free（验证开销联合决策）**：将 `verifier = skip / cheap deterministic check / state readback / strong judge / abstain` 纳入路由动作，不把验证器视为免费、完美或总是可用。

**H3 — Budget- & SLO-Constrained Utility（约束而非盲目加权）**：在任务总预算、延迟目标、最高危险状态发生率等约束下进行决策，并允许网关**拒绝自动执行/请求批准**；相比只设一个 `quality - λ cost` 的目标需通过实验验证增益。

**H4 — Honest Drift Handling（真实漂移）**：新模型、不稳定延迟、价格波动时重新校准风险和路由，若反馈/验证证据不足就退回保守选择；不宣称在任意分布变化下有无条件数学保证。

### 1.4 哪些“创新”已经被做过？（最危险的对比表）

| 先行工作 | 已有主要贡献 | 本项目需要额外证明 |
|---|---|---|
| RouteLLM / Hybrid LLM | 基于请求质量/偏好和成本的路由 | 不再停留在“一问选 S/L”，必须评估**多步骤外部状态** |
| R2-Router (ICML 2026) | 联合选择模型与生成长度 | 本项目不以输出长度联合优化作主创新；若纳入长度，要做对应基线 |
| MTRouter / ProgRouter / EvoRoute (2026) | 历史感知、多步骤进度与成本优化 | 避免仅增加“逐步切模型”；需要终态风险和有成本验证决策 |
| TRACE-Router / ORACLE (同一 arXiv ID 的不同版本信息) | 任务反馈、任务匹配验证器、并发调度 | **验证器代价/错误率**和**外部 API 状态错误后果**是必须证明的新增信息 |
| RACER (ICML 2026) | 分布无关路由风险校准、选择集合与弃权 | 不能笼统宣称首次提出风险控制；要区分**任务外部效果风险**与模型选错风险 |
| PROTEUS / SLARouter (2026) | 质量 SLA 及在线约束路由 | 不能称首次提出 SLA；本项目需报告**任务级联合质量-风险-时间约束** |
| RouteBalance / FLARE (2026) | 服务负载和长度感知的成本/时延优化 | 不能把“实时负载 + 成本”当核心新发现；主贡献要落在**Agent 工具状态与验证反馈** |
| SafeRoute / VeriRouter (2025–2026) | 安全 guard 选择 / 路由完整性可验证 | 安全判别与加密证明不是本课题同一命题；阐明边界 |

**特别勘误**：`arXiv:2607.22465` 的公开网页元数据仍可显示 **TRACE-ROUTER**，页面正文已出现 **ORACLE** 后续稿本；还存在使用同一 ID 的 ORACLE 仓库说明。本文按**同一文献系列/版本更新处理，不重复计数为两篇**；实际写综述时以投稿前下载的 PDF 版本、作者和日期核对。

---

## 2. 技术架构：让后端网关成为研究主体

```text
User Task / Agents (LangGraph / 自制 ReAct / 其他适配器)
                       │ 调用 LLM
                       ▼
┌──────────────────── VGRouter Gateway ──────────────────────┐
│ 1. Task-ID / Step-ID / Dependency Graph                    │
│ 2. Model Registry: price / capability / SLO / availability │
│ 3. Step Effect Classifier: read-only / reversible /        │
│    idempotent-write / opaque-nonidempotent-write           │
│ 4. Quality & Cost Estimator (轻量模型、可校准)             │
│ 5. Risk & Validator Planner (风险和可验证性、成本预测)      │
│ 6. Constrained Decision: (model, verify, escalate, stop)    │
│ 7. Outcome Ledger: terminal task + external tool state     │
│ 8. Drift Monitor / Conservative Fallback                   │
└─────────────────────────────────────────────────────────────┘
               │                             │
       LLM backends S/M/L           HTTP / MCP tool services
               │                             │
        latency & token log        real state transition & trace
               └─────────────► outcome evaluator
```

### 2.1 可采集的字段（为可重复实验证据服务）

`task_id, step_id, parent_ids, model_id, request_fingerprint, context_length, predicted_input_tokens, actual_output_tokens, latency_ms, model_price_at_call, api_tool_id, operation_class, reversibility, idempotency_key, verification_method, verifier_cost, verified_task_state, risk_class, route_decision, total_task_cost, ground_truth_status`。

**隐私要求**：不要保存明文 API token、真实客户姓名、私有文档与无关个人数据；通过 hash/脱敏采集业务上下文。

### 2.2 正式优化目标（不必一开始就上复杂 RL）

假设任务 $i$ 有步骤 $t=1,\dots,T_i$，每一步可选模型 $m_t$、验证动作 $v_t$ 和升级动作 $a_t$。可优化的**全任务**目标为：

$$\min_\pi\; \mathbb E\left[\sum_t \bigl(c_{\mathrm{LLM},t}+c_{\mathrm{tool},t}+c_{\mathrm{verify},t}+c_{\mathrm{router},t}\bigr)+c_{\mathrm{rework}} + \lambda\, L_{\mathrm{business}}\right].$$

同时约束：

$$\Pr(\text{unsafe terminal tool state}) \leq \epsilon,\quad
\Pr(\text{task success})\geq q_0,\quad
P95(\text{task latency})\leq D,\quad
C_{\text{task}}\leq B\;\text{(如业务强制硬预算)}.$$

重要：**P95 是流量总体的经验分位数约束**，不是单任务可直接计算的随机变量；实际算法可用安全裕量、经验分布估计、分组校准和离线评估近似处理。对于不可观测工具状态，保守拒绝是合理输出，**不得把“返回 200”视为业务成功证据**。

**费用核算必须说明包含项**：推理输入+输出 token、上下文重复传输、Router 预测、验证器调用/读回、重试、额外工具 API、重做、并行调用。如本地开源模型不能换算成 API 价格，应另报 GPU 秒/能源消耗，不能伪装为“实际付费价格”。

### 2.3 待尝试的具体算法：可校准的分段路由与选择性验证

1. 从离线矩阵预估各模型在任务步上的成功概率、Token 和延迟分布；对样本外进行校准检查（ECE/Brier score/可靠性图），必要时分场景校准。
2. 通过工具 Schema / 接口注解 / 受控工单类型判断步骤的**业务影响类别**。**LLM 自己说“这是只读调用”不足以成为认证证据**。
3. 为每个候选模型估算 `quality, total cost, P95 proxy, unsafe-state exposure, verifier need`，生成候选 `(model, verifier, escalation)`。
4. 用一个**受约束近似策略**筛选符合已知安全策略的动作；剩下的候选按预期任务成本和效用排序。不满足可证明条件时转强模型、人工或拒绝，不硬凑成功率。
5. 成功后回读有代表性的工具业务状态，记录验证方法、可信度与成本。存在延迟反馈时避免把“不知道”标成“成功”或“失败”。
6. 分布漂移时先启用保守策略并重新校准；在线学习的每次更改必须保存旧策略与固定回归集结果。

**算法难点**：多步任务中一步的模型选择会改变后续轨迹；如果只是拿静态问答样本贴上“风险分数”，这种数据不能证明 Agent 级泛化。

### 2.4 两个可执行方案

| 方案 | 工作量 | 适合谁 | 创新检验焦点 |
|---|---|---|---|
| **A：轻量 SCI 起步版（首推开工）** | 4–8 周做原型与先导试验，非投稿保证 | 一位偏后端的学弟 + 一人做实验与论文 | 固定 Agent 的三个步骤风险等级 + 3 个模型 + 选择性验证；集中证明计算验证成本后的真实改善 |
| B：完整系统研究版 | 追加 6–12 周或更久 | 有服务器与两人以上实验团队 | 上述 + 动态在线更新 + 并发 + QoS/SLO + 跨框架与新模型漂移，达到更完整的系统论文证据 |

> 工期只针对**研究开发的粗略计划**；SCI 审稿周期是独立的数月级不确定过程，不应把二者相加当作“到手时间保证”。

---

## 3. 实验方法：怎么避免写出一篇只有漂亮图的论文

### 3.1 实验分为三层

**Layer 0：离线路由矩阵（方法筛选）**
- RouterBench (2024)、LLMRouterBench (2026)：多模型结果矩阵用于筛路线，测成本-质量 Pareto；**没有真实工具状态，不能用它证明 H1**。
- 先保证静态基线与已有论文可复现，再新建 Agent 条件下的样本。划分训练/验证/测试时按**任务模板、工具类型与时间**切分，防止同一流程泄漏。

**Layer 1：有真实业务终态的工具 Agent（核心）**
- 推荐 `τ-bench / τ²-bench`，工具任务具有环境状态和可验证任务结果。亦可使用 ToolSandbox 的有状态工具交互，按许可证与可用性适配。
- 自建最小可复现服务：客户数据查询 → 库存模拟 → 工单创建 → 幂等与非幂等写入 → 事务状态查询；故障注入只作用在受控服务，**不调用真实支付/真实下单**。
- 每个任务保存数据库快照/关键状态 diff；如任务实际危险外部状态不明，计入“未验证”，而非默认为成功。

**Layer 2：系统负载/部署（投稿必备加分项）**
- 在 1、4、16、32 并发级别比较真实网关 P50/P95/P99、排队和吞吐；模拟价格调整、上游 429/503、输出长度变化、模型不可用。
- 区分“实际 API 在线测得的 P95”和“按日志回放估算的 P95”，两者不能混写。
- 本地模型部署可用 vLLM 或其它引擎，但务必记录硬件、版本、限流和计价，避免把网关优化归功于不同的硬件。

### 3.2 必须有的对照（推荐 10 组）

| 编号 | 对照基线 | 目的 |
|---|---|---|
| B0 | 始终用最强模型 | 质量上界对照（不是统计学绝对上界） |
| B1 | 始终用最便宜模型 | 最低单调用支出参考 |
| B2 | 固定规则分流（关键词/步骤类型） | 排除“规则足够好”的可能 |
| B3 | 随机/加权随机 | 系统完整性 sanity check |
| B4 | RouteLLM / RouterBench 原始路由基线 | 成熟请求级基线 |
| B5 | FrugalGPT / AutoMix 思路的置信度升级 | 与多调用/级联策略比较 |
| B6 | BEST-Route / R2-Router（在公平可运行条件下） | 和预算分配、推理计算优化对照 |
| B7 | MTRouter / ProgRouter / EvoRoute 或可复现近似 | 关键多步路由对手；不得仅用 B0–B4 替代 |
| B8 | ORACLE / TRACE 风格任务级反馈 | 检验验证器反馈确实有增益，注意版本冲突 |
| B9 | 本文方法去掉状态风险、去掉验证成本、去掉硬约束 | 完整消融，证明贡献不是调几个权重 |

**公平约束**：将路由器自身模型大小、校验次数、训练数据、可见先验、外部 API 价格与流量序列统一或明确控制；难以完全复现的强基线，应在表中标明“开源可复现/重新实现近似/仅文献对照”，不可假装跑过。

### 3.3 至少报告以下指标

| 指标 | 如何测 | 解释限制 |
|---|---|---|
| Task Success Rate (TSR) | 以最终业务状态和任务判定器为准 | 文本像对的不算完成 |
| Unsafe State Rate (USR) | 例如重复写入、错误权限操作、错误订单状态 | 低发生率需报置信区间 |
| Verified Success / $ | 可信业务成功任务数 / **完整的**推理和验证成本 | 不能省略 Router/Verifier 税 |
| Total Cost per Successful Task | 所有任务总成本 / 成功数 | 成功数为 0 时需处理，不可曲解 |
| P50/P95/P99 task latency | 从任务接入到完成/拒绝的实际时间 | 部署/并发/网络环境独立标注 |
| Verification Rate & Accuracy | 检查覆盖率、误拒/漏放、验证成本 | 验证器不一定是真实标签 |
| SLA Violation Rate | 质量、预算、尾延迟约束未达标比例 | 相对不同负载的可比性 |
| Model Selection Distribution | S/M/L 各步骤及风险等级使用比例 | 检查强模型过度集中 |
| Router Overhead | CPU/GPU ms、调用次数、内存占用 | 若 Router 太慢，会抵消节省 |
| Drift Robustness | 换模型、换数据域、服务波动时的性能曲线 | 不能由静态同分布实验推断 |

**统计**：至少 3–5 随机种子或独立采样、成对任务 bootstrap 95% CI、逐任务差异、超参数预注册；使用明确的开发集选择阈值，不在最终测试集反复调阈值。

### 3.4 六组强制消融

- 去除业务影响等级（所有工具步一视同仁）。
- 去除验证动作选择（总是不验 / 总是验 / 本文选择性验证）。
- 忽略验证成本（显示“免费验证器”会带来怎样的假节省）。
- 去除失败重做成本（只核算首遍推理）。
- 不进行分布漂移校准（新模型/价格变化后继续用原阈值）。
- 去除硬拒绝/停止动作（所有样本强制自动执行）并观察危险结果。

### 3.5 四个作图要求

1. **核心图 A**：X 轴真实“每可信完成任务的总成本”，Y 轴真实成功率，标出 unsafe-state 最大许可；展示 Pareto 前沿。
2. **核心图 B**：成本堆积柱（LLM + Router + Verifier + Rework + Tool），确保读者看到额外开销。
3. **核心图 C**：不同业务风险类别 × 路由模型/检查策略的热图。
4. **核心图 D**：并发级别 × P95 时延 / SLA 违反率的曲线；误差条和统计区间齐全。

---

## 4. 可做的交叉学科选题（7 组，含最低可实现路线）

| 交叉方向 | 可写的具体论文主观点 | 一项可验证的新贡献（提案） | 样例场景和指标 | 比较合适的期刊 |
|---|---|---|---|---|
| **运筹学 × 约束优化** | 路由本质是带不确定收益的多阶段资源分配 | 用机会约束/风险预算分配降低最坏组危险执行，同时保留总成功率 | 预算分配、Pareto、worst-group risk | ESWA / EAAI |
| **控制理论 × 在线反馈** | 多模型网关是带测量误差和延迟反馈的闭环系统 | 将验收反馈时延、观测噪声和模型漂移纳入自适应策略稳定性研究 | 在线策略振荡、超限频率、恢复时间 | FGCS / EAAI |
| **计算机网络 × 排队论** | 模型越大不一定任务越快，并发拥塞会反转选择 | 联合“步骤正确性+后端排队+ API 429/503”的任务级 SLO 调度 | P95/P99、成功数/秒、拥塞曲线 | JNCA / FGCS |
| **软件可靠性 × 故障注入** | Agent 的推理正确和外部状态正确是两件事 | 利用业务状态机测试验证路由器是否积累隐性错误 | 终态不一致率、误恢复、重做成本 | JSS / IST |
| **网络安全 × 零信任** | 对高权限工具步应采用不同路由与更强校验 | 针对工具权限、提示注入和验证缺失设计拒绝/人工升级策略 | 越权率、误拒率、验证费用 | JNCA / Computers & Electrical Engineering |
| **智能制造 × 工业系统** | 生产调度 Agent 的错误执行代价大于普通聊天 | 从数字孪生/仿真工具生成可回放状态标签、按错误后果选择模型 | 排程违约率、工单状态、能耗/误操作 | EAAI / ESWA |
| **绿色计算 × 碳约束** | 最低 API 美元成本与最低 GPU 能耗未必一致 | 以能耗/碳预算与任务达标率做多目标路由并计入验证与重算 | Joule/verified-task、P95、能耗-成功前沿 | FGCS / Computers & Electrical Engineering |

**跨学科实现优先级**：若学弟偏后端，优先 **网络排队 × 软件可靠性**；有算法基础则优先 **运筹约束优化**；如有产业合作/导师数据，可以考虑智能制造。医疗/金融真实敏感数据不建议本科团队直接采集；采用公开合成数据与明确用途、审核边界。

---

## 5. SCI 期刊推荐：快、免费、匹配度，分开评价

### 5.1 免费是什么意思

- **正确免费路线**：选择支持 **Subscription / non-OA** 的混合订阅期刊，通常**不收作者开放获取 APC**；论文一般由订阅者访问，和免费开放全文不同。Elsevier 的订阅发表与 self-archiving 说明详见 [官方解释](https://www.elsevier.support/publishing/answer/which-open-access-options-are-available)。
- **不能误判**：页面写着 `$3,000 APC` 通常是**选择 Gold OA** 的价格，并不是说所有作者都必须支付此费用。
- **仍需核实**：彩图、超页、特殊稿型/版面要求、机构政策是否另收费；个别期刊会改变出版模式。**不把“可能减免 OA 费”算作真正免费**。
- **SCI 录用前核对**：访问 [Clarivate Master Journal List](https://mjl.clarivate.com/) 以 **ISSN** 查询 **SCIE**，注意 **ESCI ≠ SCIE**；若学校看中科院分区，按毕业年份要求版本查，不在本文件中保证分区永久有效。

### 5.2 基于截至 2026-10-20 可获得的历史周期信息

> 四个口径分别是：**投稿至首次决定（包括初筛拒稿）**、**投稿至外审后决定**、**投稿至录用（含作者修改时间）**、**录用至线上发表**。下表使用出版商 Journal Insights 页面链接与公开转录数据；**不同日期的第三方网页出现不同值时，以投稿当天的出版商 Insights 为准**。数值是历史统计，不是审稿承诺，也不是录用概率。

| 期刊（均需投稿当日核验 SCIE） | 题目匹配 | 首次决定 | 外审后决定 | 投稿→录用 | 通常零 APC 的选择 | 具体建议 |
|---|---|---:|---:|---:|---|---|
| **Computers & Electrical Engineering** | 中：需工程系统、通信/部署证据 | 约 5 天* | 约 123 天* | **约 150 天*** | 订阅稿 | 审稿速度有吸引力，但“纯 Prompt 路由”易偏题 |
| **Expert Systems with Applications (ESWA)** | 高（若有实质决策算法） | **5 天** | **62 天** | **147 天** | 订阅稿 | 强烈要求 AI 方法、真实效益与扎实对照 |
| **Future Generation Computer Systems (FGCS)** | 很高（并发/系统） | **3 天** | **72 天** | **183 天** | 订阅稿 | 系统与后端特色优先；部署实验是关键 |
| **Journal of Network and Computer Applications (JNCA)** | **很高（网关/API）** | **11 天** | **88 天** | **187 天** | 订阅稿 | 首推；强调协议代理、网络/API 实测和端到端 SLA |
| **Engineering Applications of Artificial Intelligence (EAAI)** | 高（算法+应用） | **27 天** | **85 天** | **207 天** | 订阅稿 | 跨学科工业任务更占优势 |
| **Information and Software Technology (IST)** | 中（软件工程实证） | 约 7 天** | 约 85 天** | **约 202–233 天** | 订阅稿 | 若主创新是可靠的软件工程评测/方法才考虑 |
| **Journal of Systems and Software (JSS)** | 高（架构、软件质量） | 未以一致值核实 | 未以一致值核实 | **约 203–252 天** | 订阅稿 | 实证要求高，速度未必优先 |

\* *Computers & Electrical Engineering* 的 150 天数据来自网络期刊信息摘录，**独立复核难度高**，需用 [官方 Insights](https://www.sciencedirect.com/journal/computers-and-electrical-engineering/about/insights) 复查后再决定，不可视为保证。  
\** IST、JSS 的不同公开页面/抓取时间有数字差异，**不作唯一精确承诺**，列区间更诚实。部分站点外观与出版商相似却并非官方域名；须使用 `sciencedirect.com` 或 `elsevier.com` 最终确认。

可核对的 Insights 官方入口：
- [ESWA](https://www.sciencedirect.com/journal/expert-systems-with-applications/about/insights)
- [FGCS](https://www.sciencedirect.com/journal/future-generation-computer-systems/about/insights)
- [JNCA](https://www.sciencedirect.com/journal/journal-of-network-and-computer-applications/about/insights)
- [EAAI](https://www.sciencedirect.com/journal/engineering-applications-of-artificial-intelligence/about/insights)
- [IST](https://www.sciencedirect.com/journal/information-and-software-technology/about/insights)
- [JSS](https://www.sciencedirect.com/journal/journal-of-systems-and-software/about/insights)
- [Computers & Electrical Engineering](https://www.sciencedirect.com/journal/computers-and-electrical-engineering/about/insights)
- [Elsevier — 如何理解期刊处理速度](https://www.elsevier.support/publishing/answer/when-can-i-expect-a-decision-from-the-editor)

**公开交叉核对来源**（不是官方一手数据）：[ESWA](https://journalcompass.com/journals/expert-systems-with-applications-09574174.html)、[FGCS](https://journalcompass.com/journals/future-generation-computer-systems-the-international-journal-of-escien-0167739x.html)、[JNCA](https://journalcompass.com/journals/journal-of-network-and-computer-applications-10848045.html)、[EAAI](https://journalcompass.com/journals/engineering-applications-of-artificial-intelligence-09521976.html)、[JSS](https://journalcompass.com/journals/journal-of-systems-and-software-01641212.html)。

### 5.3 推荐投稿顺序不是一刀切

- **网络/网关实测为论文主体**：JNCA → FGCS →（若工程/通信交叉充分）Computers & Electrical Engineering。
- **有明显新算法、理论约束与 AI 泛化**：ESWA → EAAI → FGCS。
- **可复现软件工程方法、故障/业务终态验证**：JSS → IST；两刊不一定更快。
- **投稿范围不匹配就不要投**；投稿前检索最近两年该刊有关 `LLM routing`, `API gateway`, `multi-model inference`, `cloud scheduling` 的正式论文，确认有同类稿件且论文能讲清具体受众。

**特别注意**：所有推荐期刊都是**高竞争的正规期刊**；并非“容易发”。若只需要极快且真正零费用，必须接受匹配度、声誉和周期之间取舍，不能保证 1–2 个月 SCI 录用。

---

## 6. 论文草稿框架（8 节）

1. **Introduction**：以“最便宜推理不等于最便宜成功任务”引出 tool-effect / verification tax / SLO；列 3 项贡献，不夸大首创。
2. **Related Work**：静态 query router、在线/Agentic router、SLA & 风险控制、验证器和系统服务；专门写清与 2026 直接对手区别。
3. **Problem Definition**：任务 DAG/交互历史、可检查业务终态、成本组成、约束及边界假设。
4. **VGRouter Design**：模型池、风险标注、验证规划、决策器、回退/拒绝、日志与性能。
5. **Theoretical Analysis（选做）**：必要假设下成本界/风险界/简单策略性质；没有完备证明绝不写“guaranteed”。
6. **Experimental Setup**：任务、数据集、模型、成本、硬件、失效注入、基线、统计与消融。
7. **Results & Discussion**：成本-可信任务成功、错误业务状态、验证税、延迟/SLO、漂移、部署成本、失败案例。
8. **Threats to Validity & Conclusion**：模拟服务的外推限制、LLM judge 偏差、端到端成功定义、版本变化、实验伦理。

### 6.1 建议摘要占位稿（仅为结构示例，不能当实测结果投稿）

> Multi-model routing is commonly evaluated by per-query quality and inference expenditure. For tool-using agents, this can underestimate task-level re-execution cost and the consequences of incorrect external state transitions. We study a gateway-level routing problem in which model selection and verification actions are jointly optimized under budget, latency and unsafe-state constraints. We design [method], benchmark it on [stateful tool environments], and compare it with [reproducible baselines]. We report end-to-end verified task success, total execution expenditure, tail latency and unsafe-state outcomes. **[Results to be filled only after experiments.]**

---

## 7. 开工清单与 4 个 Go/No-Go 决策关卡

**第一阶段（基础）**
- [ ] 明确哪三种真实状态型任务最容易搭建（必须含只读和写入）。
- [ ] 把“正确终态”“拒绝自动执行”“错误外部状态”定义成可运行判定器，而不是文字描述。
- [ ] 固定至少 3 个模型版本、温度、上下文预算和价格表，建立可重放日志。
- [ ] 复现实用最强的 RouteLLM/规则/始终最强基线和工具任务中的失败成本。

**第二阶段（创新有效性）**
- [ ] 实施“任务风险 vs 只看问题难度”的对照；如收益全部来自人工写的规则，暂时不宣称算法创新。
- [ ] 测 `verify:none`, `verify:all`, `verify:selective` 三组的**完整账单**。
- [ ] 画出 TSR / USD 与 unsafe state 的前沿和 95% CI。

**第三阶段（系统性）**
- [ ] 压测 P95、不同并发和故障/漂移；将网关推理开销单列。
- [ ] 至少两种 Agent 框架或两个独立工具服务适配器。
- [ ] 做 6 组消融、负结果和跨任务切分，保留原始脚本与日志。

**第四阶段（是否投稿）**
- **Go**：有一项非平凡决策方法，相比紧邻 Agentic router，在**业务终态**及全成本上均有可重复、统计上可信改善，且约束违例没有恶化。
- **Pivot**：仅节约单步 token 但不改善终态；改研究方向为**基准与实证 / 系统负载 / 工具安全**，不包装 SCI 方法。
- **Stop**：实验优势只来自遗漏验证成本、使用测试集选阈值或不公平 baselines；需先重做数据与评估。
- **Journal check**：如期刊转为全 OA 收费、取消 SCIE、审稿时间显著增长，立即调整名单，不为所谓“快录用”支付未知费用。

---

## 8. 相似论文与关联文献（带可追溯链接，按优先级）

> **文献核查规则**：以下“2026”只代表资料检索至 **2026-10-20** 可查到的公开学术工作；一部分是 **arXiv 预印本**，尚不能宣称已被 SCI 期刊正式录用。ACL / ICML / NeurIPS 属于会议或会议论文集，**不是 SCI 期刊**。同一论文多个版本只计一次。优先级 P0=必须精读/对照，P1=相关技术，P2=背景/测评。

| # | 优先级 | 论文（点标题进入原文） | 年份 | 类型/状态 | 与本选题的关联 / 必须防止的重复 |
|---:|---|---|---|---|---|
| 01 | **P0** | [TRACE-Router / ORACLE: Task-Consistent and Adaptive Online Routing / Adaptive Verifier Calibration Feedback](https://arxiv.org/abs/2607.22465) | 2026 | 预印本版本更新 | 同一 arXiv ID 的版本/网页元数据存在标题差异；任务级选模、验证反馈与调度，是直接竞争对象 |
| 02 | **P0** | [ProgRouter: Online Progress-Guided Orchestration for Multi-Agent LLM Workflows under Quality-Cost Tradeoffs](https://arxiv.org/abs/2608.25992) | 2026 | 预印本/会议相关信息需核验 | 利用多步任务进度在线分派模型，不能把“按步骤动态选模”当原创 |
| 03 | **P0** | [MTRouter: Cost-Aware Multi-Turn LLM Routing with History–Model Joint Embeddings](https://aclanthology.org/2026.acl-long.2045/) | 2026 | ACL 2026 | 多轮历史和候选模型联合表示；应与状态/业务风险变量对比 |
| 04 | **P0** | [EvoRoute: Experience-Driven Self-Routing LLM Agent Systems](https://aclanthology.org/2026.acl-long.1771/) | 2026 | ACL 2026 | 利用经验演化选模，含能力/成本/时延三难题 |
| 05 | **P0** | [Budget-Aware Agentic Routing via Boundary-Guided Training](https://arxiv.org/abs/2602.21227) | 2026 | 预印本 | 严格每任务预算的序列路由；本研究不能只声称“加入预算” |
| 06 | **P0** | [R2-Router: A New Paradigm for LLM Routing with Reasoning](https://proceedings.mlr.press/v306/xue26h.html) | 2026 | ICML 2026 | 模型和输出长度预算联合优化，预算维度直接强基线 |
| 07 | **P0** | [RACER: Risk-Aware Calibrated Efficient Routing for Large Language Models](https://proceedings.mlr.press/v306/hao26c.html) | 2026 | ICML 2026 | 集合路由、弃权与统计风险界；注意与“工具状态风险”区别 |
| 08 | **P0** | [PROTEUS: SLA-Aware Routing via Lagrangian RL for Multi-LLM Serving Systems](https://arxiv.org/abs/2601.19402) | 2026 | 预印本/EuroMLSys 2026 | 运行时质量目标和受约束学习；必须比较 SLA 达标 |
| 09 | **P0** | [Cost-Optimal LLM Routing with Limited User Feedback under User Satisfaction Guarantees (SLARouter)](https://arxiv.org/abs/2606.19376) | 2026 | 预印本 | 稀疏反馈和 SLA 约束已有理论研究 |
| 10 | **P0** | [RouteBalance: Fused Model Routing and Load Balancing for Heterogeneous LLM Serving](https://arxiv.org/abs/2606.17949) | 2026 | 预印本 | 后端实际负载和模型质量联合调度，系统对照重点 |
| 11 | **P0** | [FLARE: Fine-Grained Length-Aware Routing for Resource-Efficient Heterogeneous LLM Serving](https://aclanthology.org/2026.acl-long.1018/) | 2026 | ACL 2026 | 推理长度预测与部署资源计价，核算延迟/成本参考 |
| 12 | **P0** | [LLMRouterBench: A Massive Benchmark and Unified Framework for LLM Routing](https://aclanthology.org/2026.findings-acl.1881/) | 2026 | Findings ACL 2026 | 超大多模型路由矩阵和统一重评；警惕新方法只小幅超过简单基线 |
| 13 | **P0** | [IPR: Intelligent Prompt Routing with User-Controlled Quality-Cost Trade-offs](https://aclanthology.org/2025.emnlp-industry.170/) | 2025 | EMNLP Industry 2025 | 工业级质量估计及成本权衡，作为成熟工程上限参考 |
| 14 | **P0** | [MixLLM: Dynamic Routing in Mixed Large Language Models](https://aclanthology.org/2025.naacl-long.545/) | 2025 | NAACL 2025 | 在线质量/成本/延迟综合选模，要求区别任务终态成本 |
| 15 | **P0** | [BEST-Route: Adaptive LLM Routing with Test-Time Optimal Compute](https://proceedings.mlr.press/v267/ding25d.html) | 2025 | ICML 2025 | 模型和候选次数的联合选择，注意额外生成/验证成本 |
| 16 | **P0** | [RouteLLM: Learning to Route LLMs with Preference Data](https://arxiv.org/abs/2406.18665) | 2024/2025 | 预印本/ICLR 2025 | 基于偏好选择强弱模型，必备基础 Router 基线 |
| 17 | **P0** | [RouterBench: A Benchmark for Multi-LLM Routing System](https://arxiv.org/abs/2403.12031) | 2024 | 预印本 | 标准化多模型推理结果及成本-质量路由评测 |
| 18 | **P0** | [FrugalGPT: How to Use Large Language Models While Reducing Cost and Improving Performance](https://arxiv.org/abs/2305.05176) | 2023/2024 | 预印本/TMLR 2024 | 级联与成本优化早期经典；无需把多模型省钱作为新贡献 |
| 19 | **P0** | [Hybrid LLM: Cost-Efficient and Quality-Aware Query Routing](https://proceedings.iclr.cc/paper_files/paper/2024/hash/b47d93c99fa22ac0b377578af0a1f63a-Abstract-Conference.html) | 2024 | ICLR 2024 | 质量要求变化下强弱模型动态切换经典基线 |
| 20 | **P0** | [A Unified Approach to Routing and Cascading for LLMs](https://arxiv.org/abs/2410.10347) | 2024 | 预印本 | 统一纯路由与级联，基线理论和近似最优对照 |
| 21 | **P1** | [X-Router: Decoupling Knowledge and Reasoning for Cost-Effective LLM Inference](https://aclanthology.org/2026.findings-acl.994/) | 2026 | Findings ACL 2026 | RAG/CoT 选择属于管道级路由；与工具 Agent 兼容可能有价值 |
| 22 | **P1** | [Vertical Routing: A Cost-Efficient Collaboration Routing Framework](https://aclanthology.org/2026.tacl-1.104/) | 2026 | TACL 2026 | 关键子任务分配强模型，尤其容易撞到“风险关键步骤分配” |
| 23 | **P1** | [How Robust Are Router-LLMs? Analysis of the Fragility of LLM Routing Capabilities](https://aclanthology.org/2026.eacl-long.351/) | 2026 | EACL 2026 | 异常分布、隐私、安全与伪善路由等风险评估参考 |
| 24 | **P1** | [VeriRouter: Towards Verifiable LLM Routing](https://arxiv.org/abs/2610.17431) | 2026 | 预印本（2026-10） | ZK 与服务证书保护路由完整性；不是业务状态正确性 |
| 25 | **P1** | [LLMs Can Predict Failure Risk, But Struggle to Predict Which Collaboration Protocol Pays Off: Cost-Aware Protocol Routing Across Reasoning Tasks](https://arxiv.org/abs/2608.14927) | 2026 | 预印本 | 说明失败概率并不直接等于升级后净收益，支持成本敏感设计 |
| 26 | **P1** | [Efficient Training-Free Online Routing for High-Volume Multi-LLM Serving](https://arxiv.org/abs/2509.02718) | 2025 | 预印本 | 小资源在线无需训练路由，适合低算力基线 |
| 27 | **P1** | [IRT-Router: Effective and Interpretable Multi-LLM Routing via Item Response Theory](https://aclanthology.org/2025.acl-long.761/) | 2025 | ACL 2025 | 心理测量 IRT 可解释建模 + 冷启动，是跨学科参考 |
| 28 | **P1** | [RouterDC: Query-Based Router by Dual Contrastive Learning for Assembling Large Language Models](https://arxiv.org/abs/2409.19886) | 2024 | 预印本/NeurIPS 2024 | 双对比路由编码与通用能力估计，模型性能基线 |
| 29 | **P1** | [GraphRouter: A Graph-based Router for LLM Selections](https://arxiv.org/abs/2410.03834) | 2024 | 预印本/ICLR 2025 | 已有任务-问题-模型异构图；任务 DAG 不能直接冒充第一次用图 |
| 30 | **P1** | [SelectLLM: Query-Aware Efficient Selection Algorithm for Large Language Models](https://aclanthology.org/2025.findings-acl.1072/) | 2025 | Findings ACL 2025 | 模型子集筛选与多模型组合，对照降低 latency |
| 31 | **P1** | [Router-R1: Teaching LLMs Multi-Round Routing and Aggregation via Reinforcement Learning](https://arxiv.org/abs/2506.09033) | 2025 | 预印本/NeurIPS 2025 | 强化学习多轮选择与聚合；本研究不必大规模 RL |
| 32 | **P1** | [AutoMix: Automatically Mixing Language Models](https://arxiv.org/abs/2310.12963) | 2023/2024 | 预印本/NeurIPS 2024 | 低成本模型输出校验与升级，验证成本需要公允对照 |
| 33 | **P1** | [Leveraging Uncertainty Estimation for Efficient LLM Routing](https://arxiv.org/abs/2502.11021) | 2025 | 预印本 | 不确定度与选模挂钩，可比校准质量 |
| 34 | **P1** | [Learning to Route LLMs with Confidence Tokens](https://proceedings.mlr.press/v267/chuang25b.html) | 2025 | ICML 2025 | 通过置信度决定升级与拒绝，校验信号设计参考 |
| 35 | **P1** | [Lookahead Routing for Large Language Models](https://papers.neurips.cc/paper_files/paper/2025/hash/552456ddb6f4b2956b2933ab83f56df0-Abstract-Conference.html) | 2025 | NeurIPS 2025 | 先预测输出信息后路由，审视 Router 税与预估误差 |
| 36 | **P1** | [SafeRoute: Adaptive Model Selection for Efficient and Accurate Safety Guardrails in Large Language Models](https://aclanthology.org/2025.findings-acl.105/) | 2025 | Findings ACL 2025 | 安全过滤器的模型路由，与危险工具步的检验不同 |
| 37 | **P1** | [Select-then-Route: Taxonomy Guided Routing for LLMs](https://aclanthology.org/2025.emnlp-industry.28/) | 2025 | EMNLP Industry 2025 | 任务分类到小模型池+置信度级联，对照分类器方案 |
| 38 | **P1** | [Cost-Effective Online Multi-LLM Selection with Versatile Reward Models (C2MAB-V)](https://arxiv.org/abs/2405.16587) | 2024 | 预印本 | Bandit 与多样收益建模，补充在线学习对照 |
| 39 | **P1** | [LLM-Blender: Ensembling Large Language Models with Pairwise Ranking and Generative Fusion](https://aclanthology.org/2023.acl-long.792/) | 2023 | ACL 2023 | 多模型生成、排序、融合成本对照，别只报告推理模型的价格 |
| 40 | **P1** | [Adaptive Load Balancing for Multi-Tier LLM Inference with Dynamic Model Routing](https://ieeexplore.ieee.org/document/11476301/) | 2026 | IEEE SoutheastCon 2026 | 边缘/云异构推理的在线负载分配与服务目标参考 |
| 41 | **P1** | [Multi-LLM Prototype: Open-source Software for Adaptive Orchestration, Conflict Resolution, and Cost-Aware Routing Across Heterogeneous Large Language Models](https://doi.org/10.1016/j.softx.2026.102782) | 2026 | SoftwareX 2026 | 软件平台层已有开源原型，单纯做前后端平台创新不足 |
| 42 | **P2** | [τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains](https://arxiv.org/abs/2406.12045) | 2024 | 预印本/会议后续版本另核验 | 必须以工具业务终态评估任务完成 |
| 43 | **P2** | [τ²-Bench: Evaluating Conversational Agents in a Dual-Control Environment](https://arxiv.org/abs/2506.07982) | 2025 | 预印本/会议版本另核验 | 共享状态工具任务评估、前后状态对照 |
| 44 | **P2** | [ToolSandbox: A Stateful, Conversational, Interactive Evaluation Benchmark for LLM Tool Use Capabilities](https://arxiv.org/abs/2408.04682) | 2024 | 预印本 | 提供有状态工具交互、受控验证难点 |
| 45 | **P2** | [AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents](https://arxiv.org/abs/2406.13352) | 2024 | 预印本/NeurIPS 2024 | 安全/攻击干扰下的网关策略稳健性 |
| 46 | **P2** | [ReAct: Synergizing Reasoning and Acting in Language Models](https://arxiv.org/abs/2210.03629) | 2022 | 预印本/ICLR 2023 | Agent 推理-行动闭环基本框架 |

**合计 46 篇**：P0 **20**、P1 **21**、P2 **5**。文献不是“全为 SCI”，恰恰因为选题查新必须覆盖最接近的会议和预印本。P0 中可直接作为算法复现实验的工作，以可获得仓库和许可证为准。请按 **2026-10-20** 的下载版本保存纸面备份，因 arXiv 标题、作者和论文版本可能变化。

### 8.1 先读哪 10 篇？（节约时间顺序）

- **打基础**：FrugalGPT → RouterBench → RouteLLM。
- **明确 2026 创新边界**：LLMRouterBench → R2-Router → MTRouter → ProgRouter → ORACLE/TRACE → RACER → RouteBalance。
- **最后补强网关主题**：τ-bench、ToolSandbox，并查验业务状态校验数据是否可获得。

### 8.2 文献到方法的引用地图

| 论文相关工作段落 | 重点引文 | 不该重复的说法 |
|---|---|---|
| 一问一选（query-level） | FrugalGPT, RouterBench, RouteLLM, Hybrid LLM, RouterDC | 首次用小模型节省 Token |
| Agentic 长轨迹 | MTRouter, ProgRouter, EvoRoute, ORACLE/TRACE, Budget-Aware Agentic Routing | 首次按多步进度动态切模型 |
| 风险/约束 | RACER, PROTEUS, SLARouter, SafeRoute | 首次引入风险上限/SLA/弃权 |
| 成本与资源 | R2-Router, FLARE, RouteBalance, BEST-Route | 首次计入输出长度/负载 |
| 多模型验证 | ORACLE, AutoMix, LLM-Blender, Self-REF | 首次提出验证/升级 |
| 有状态任务评估 | τ-bench, τ²-bench, ToolSandbox, AgentDojo | 文本质量即任务成功 |

---

## 9. 最终立项建议

**综合优先级：第 2 篇的整体创新压力比第 1 篇还高，但从工程开发角度更容易搭起来。** 如果学弟主要是 Agent + 网关后端，推荐选 **“外部工具业务风险 + 验证器真实开销”** 的狭窄问题，先在受控工具状态基准上证明“总成本/可信完成率”的改变，再决定投哪本期刊。**不能仅凭做出漂亮的路由控制台就承诺 SCI**。

### 可以直接发给学弟的研究任务

> 搭一个兼容至少 3 种 LLM 的轻量代理网关，建立带数据库终态的三种工具任务（只读、幂等写入、非幂等写入），先复现固定模型/RouteLLM/简单级联，再加入工具业务风险和选择性验证决策。每次实验必须记录完整成本、P95、最终任务成功以及错误外部状态。优先得到**负结果也有价值**的基线对照，尚不需要训练大模型。

**配套原始出处**：
- 出版商发布流程解释：[Elsevier 决策时长口径](https://www.elsevier.support/publishing/answer/when-can-i-expect-a-decision-from-the-editor)。
- 出版商订阅发表政策：[Elsevier Open Access Options](https://www.elsevier.support/publishing/answer/which-open-access-options-are-available)。
- SCIE 核对：[Clarivate Master Journal List](https://mjl.clarivate.com/)。
- 原始论文来源：上表 46 个 DOI / arXiv / PMLR / ACL 链接。

> **审稿诚信提醒**：本文的架构、方程、算法和可能的创新点均为**提案**。不虚构已有实现、不填充不存在的提升百分比、不将预印本标成 SCI 正式文章、不将录用时间当保证。已发工作如出现在后续投稿前，需要重新更新 Related Work。
