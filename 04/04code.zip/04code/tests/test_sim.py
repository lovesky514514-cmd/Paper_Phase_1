"""Observable scheduling behavior, not implementation-specific helper calls."""
import unittest
from sim.model import Job, Node, Trace
from sim.engine import Simulator, Settings


class FlowGateTest(unittest.TestCase):
    def test_chain_never_runs_child_first(self):
        trace = Trace((Job("j", "a", 0, 200, (
            Node("first", "tool", 10, 1),
            Node("second", "llm", 5, 1, ("first",)),
        )),))
        result = Simulator(Settings(), "flowgate").run(trace)
        self.assertEqual(result.jobs["j"].status, "success")
        self.assertLessEqual(result.jobs["j"].finishes["first"], result.jobs["j"].starts["second"])

class TraceContractTest(unittest.TestCase):
    def test_rejects_cycle_and_missing_parent(self):
        for parents in (("child",), ("absent",)):
            trace = Trace((Job("bad", "a", 0, 100, (
                Node("child", "tool", 1, 1, parents),
            )),))
            with self.subTest(parents=parents), self.assertRaises(ValueError):
                trace.validate()

    def test_rejects_duplicate_job_and_node_identifiers(self):
        job = Job("same", "a", 0, 100, (Node("n", "tool", 1, 1),))
        with self.assertRaises(ValueError):
            Trace((job, job)).validate()
        with self.assertRaises(ValueError):
            Trace((Job("a", "a", 0, 100, (Node("n", "tool", 1, 1),
                                            Node("n", "llm", 1, 1))),)).validate()

    def test_impossible_resource_demand_is_rejected(self):
        trace = Trace((Job("x", "a", 0, 100, (Node("n", "tool", 5, 10),)),))
        with self.assertRaises(ValueError):
            Simulator(Settings(bucket=9)).run(trace)

    def test_missing_and_invalid_settings_fail_fast(self):
        with self.assertRaises(ValueError):
            Simulator(Settings(tenant_weights={"a": 0}))
        with self.assertRaises(ValueError):
            Simulator(Settings(fault_rate=.9))
        with self.assertRaises(ValueError):
            Simulator(Settings(), "nope")


class LifecycleTest(unittest.TestCase):
    def test_same_seed_returns_identical_events_and_metrics(self):
        from sim.workload import generate
        trace = generate(seed=21, jobs=12, arrival="burst")
        a = Simulator(Settings(fault_rate=.15, fault_seed=21)).run(trace)
        b = Simulator(Settings(fault_rate=.15, fault_seed=21)).run(trace)
        self.assertEqual(a.events, b.events)
        self.assertEqual(a.summary(), b.summary())

    def test_failed_tool_can_not_unlock_downstream_node(self):
        trace = Trace((Job("bad", "a", 0, 100, (
            Node("parent", "tool", 5, 1, retry_safe=False),
            Node("child", "tool", 5, 1, ("parent",)),
        )),))
        # Every accepted node is forced to return ambiguous responses.
        # Search for a stable fault seed, instead of depending on an implementation hash.
        found = False
        for seed in range(100):
            run = Simulator(Settings(fault_rate=.5, fault_seed=seed)).run(trace)
            if run.jobs["bad"].reason == "unsafe_retry":
                self.assertNotIn("child", run.jobs["bad"].starts)
                found = True
                break
        self.assertTrue(found)

    def test_deadlines_count_unfinished_tasks_as_failures(self):
        trace = Trace((Job("late", "a", 0, 6, (Node("slow", "llm", 50, 1),)),))
        result = Simulator(Settings()).run(trace)
        self.assertEqual(result.jobs["late"].status, "timeout")
        summary = result.summary()
        self.assertEqual(summary["completion_ratio"], 0)
        self.assertEqual(summary["failed_or_timed_out"], 1)
        self.assertEqual(summary["p95_all_jobs_ms"], 6)
        self.assertEqual(result.jobs["late"].finishes["slow"], 50)
        self.assertIn("late_finish", [e["kind"] for e in result.events])

    def test_reservation_never_exceeds_slots(self):
        from sim.workload import generate
        trace = generate(seed=7, jobs=40, arrival="burst")
        for policy in ("fcfs", "flowgate"):
            result = Simulator(Settings(slots=2), policy).run(trace)
            for resource in ("tool", "llm"):
                active = 0
                # Finish events are emitted before dispatch at an equal timestamp.
                ordered = [e for e in result.events if e.get("resource") == resource
                           and e["kind"] in {"dispatch", "finish", "lost_response", "http_5xx"}]
                for event in ordered:
                    active += 1 if event["kind"] == "dispatch" else -1
                    self.assertLessEqual(active, 2, f"{policy} exceeded {resource} slots")
                    self.assertGreaterEqual(active, 0)

    def test_retry_budget_is_bounded(self):
        from sim.workload import generate
        trace = generate(seed=19, jobs=30)
        result = Simulator(Settings(max_retries=1, fault_rate=.5)).run(trace)
        for state in result.jobs.values():
            for attempts in state.attempts.values():
                self.assertLessEqual(attempts, 2)

    def test_weighted_shares_do_not_leak_between_runs(self):
        trace = Trace((Job("a", "a", 0, 100, (Node("one", "tool", 2, 1),)),
                       Job("b", "b", 0, 100, (Node("one", "tool", 2, 1),))))
        a = Simulator(Settings(tenant_weights={"a": 4, "b": 1})).run(trace)
        b = Simulator(Settings()).run(trace)
        self.assertNotEqual(a.shares, b.shares)
        self.assertEqual(a.summary()["success"], b.summary()["success"])


class ExperimentTest(unittest.TestCase):
    def test_bootstrap_identical_policy_difference_is_zero(self):
        from benchmarks.stats import paired_bootstrap_ci
        self.assertEqual(paired_bootstrap_ci([1., 2., 3.], [1., 2., 3.]), [0, 0])

    def test_all_policies_use_matched_seeds(self):
        from benchmarks.run_eval import evaluate
        result = evaluate(2, 8, "mixed", "steady", .2)
        policies = set(r["policy"] for r in result["runs"])
        self.assertEqual(len(policies), 9)
        self.assertTrue(all({r["seed"] for r in result["runs"] if r["policy"] == p}
                            == {17, 18} for p in policies))
        self.assertIsNone(result["event_logs"])

    def test_explicit_event_log_capture(self):
        from benchmarks.run_eval import evaluate
        result = evaluate(1, 2, "chain", "steady", 0, save_events=True)
        self.assertEqual(len(result["event_logs"]), 9)
        self.assertTrue(result["event_logs"][0]["events"])
