# 第四篇 SCI 研究专题：多 Agent 任务调度与拥塞控制网关

> **文档日期：2026-10-20**  
> **适用对象：Agent / 后端网关方向本科生及小团队**  
> **性质：选题论证 + 研究设计 + 文献地图 + SCI 选刊建议；不是已完成实验或保证录用的论文**  
> **选刊硬约束：优先 SCIE 收录、可选无 APC 订阅发表（非必须开放获取）、相对较短的审稿周期。**  
> **文献数：40 篇可追溯论文（其中部分为预印本）+ 1 本经典方法书，按研究关系分组。**

---

## 0. 一页结论：第四篇能不能做？

**建议做，但不要以“多 Agent 任务调度”或“给请求加优先级队列”作为创新。** 2025—2026 年，Autellix、Kairos、Maestro、Chimera、H-MAS、Dyserve、Vesta 等研究已经把工作流级排队、异构集群、任务时延与状态迁移研究得很深入。[R1–R9]

**建议的主创新：** 当多个 Agent 在同一个网关共享 LLM、工具 API、并发槽和限额时，由网关基于**任务依赖图（DAG）+ 关键路径剩余工作量 + 多租户服务债务 + 实际拥塞反馈**联合执行**准入控制、发令牌、调度、动态退避与公平性保护**，直接优化**正确且按时完成的任务比例**，而非单条模型请求的平均速度。

**拟定题目（推荐）：**

- 中文：**面向多智能体工作流的依赖感知公平拥塞控制网关**
- 英文：**DAG-FlowGate: Dependency-Aware Fair Congestion Control for Multi-Agent Workflows**
- 备选：*Workflow-Criticality and Tenant-Fairness Aware Admission Control for Tool-Using LLM Agents*

**三条必须回答的研究问题：**

1. 在突发流量与共享 API 配额下，DAG 关键路径感知调度能否显著提升端到端按时完成率，而不是简单牺牲其他租户？
2. 引入服务债务和最低服务保障，能否减少低优先级/长任务的饥饿，且不明显损害系统有效吞吐？
3. 使用实时拥塞反馈动态控制准入窗口和令牌速率，在估计偏差与工具调用重试下能否保持队列稳定、避免雪崩？

**一句话科研判据：** 不是把 FCFS 改成 PriorityQueue，而是证明“在依赖关系、突发流量、公平性与真实 API 限额同时存在时，提出的方法比有代表性的调度/限流基线更好”，并提供严格适用条件下的稳定性分析或完整的反例与局限报告。

**推荐路线：** 先做无需 GPU 的离散事件模拟器和网关原型；若性能前沿确实改善，再接入 Ray / LiteLLM / vLLM 等现成组件，并用真实工具链回放。**只做模拟和几张漂亮图通常不够支撑高质量 SCI。**

---

## 1. 五个方向的主观点与创新点总览（延续前几篇）

| 编号 | 方向 | 一句话主观点 | 可能成立的主创新（都需实验验证） |
|---|---|---|---|
| 1 | Agent 故障感知与自动恢复网关 | 任务失败后最省事的重试不一定最安全 | 不侵入 Agent 的语义级故障分类、幂等感知局部恢复与副作用保护 |
| 2 | 多模型动态路由与成本优化 | 最便宜的模型调用不等于最低任务总成本 | 联合估算验证费用、工具执行风险与恢复开销的动态路由 |
| 3 | MCP 工具调用安全验证网关 | 工具可访问不等于操作已被授权 | 跨工具权限传播检查、时效权限验证与执行前授权边界 |
| **4** | **多 Agent 任务调度与拥塞控制** | **局部最快的 Agent 请求不一定让整个工作流更快** | **依赖感知调度 + 拥塞反馈准入 + 多租户公平服务保障** |
| 5 | Agent 调用链异常检测与根因定位 | 一次错误可能由上游状态污染而非最后一次 API 失败造成 | 跨 Agent 因果图、异常定位与根因优先级估计 |

**第四篇与第二篇的严格区分：** 第二篇重点是“调用哪个模型”；第四篇重点是“共享资源紧张时，哪些工作流、哪些节点何时获得执行权、是否应准入/等待/退避”。第四篇不需要更换底层模型。

---

## 2. 研究问题与工程场景

### 2.1 为什么传统限流策略可能不适用

想象三个用户同时提交任务：

- 用户 A 的 Agent 任务有 `检索 → 分析 → 调用工具 → 汇总` 四个节点，30 秒内必须完成；
- 用户 B 提交 10 个彼此独立的批处理子 Agent，吞吐高但不紧急；
- 用户 C 的 Agent 访问一个每分钟只有固定调用额度的外部 API，并在 `429` 后自动重试。

网关内部可能同时有三种瓶颈：**LLM Token 预算、外部 API 请求速率、工作流并发槽位**。简单 FCFS、逐 Agent 轮询和静态限流会忽略：

1. 一个请求在关键路径还是非关键路径上；
2. 后继任务能否继续；
3. 任务剩余截止时间；
4. 当前租户已经得到多少服务；
5. 工具限额、`Retry-After`、重试放大和失败率；
6. 一个 Agent 的调用成本并非只由单个 Token 数决定。

因此，应在**应用/网关层**研究面向 Agent 工作流的负载治理。**这里的“拥塞”主要指应用层 API 配额与共享执行队列，不等同于 TCP 的端到端网络拥塞控制。** 经典网络控制研究可借鉴其反馈机制与排队理论，但不能照搬公式或直接宣称网络层性质。

### 2.2 输入/输出边界

**输入：** 工作流 DAG、就绪节点、租户标识、节点估计工作量（Token/时间/工具配额）、全链路 deadline、任务风险/重试策略、资源队列状态。  
**控制：** admission、token bucket/窗口、优先级、具体后端/工具实例选择、退避时间、租户共享份额。  
**输出：** 完整执行日志、最终任务状态、延迟分解、SLO 达成、资源占用与公平性统计。

**禁止混淆的边界：** 该网关可以限制、观测、排序 API 调用；不能神奇地中断第三方正在运行的黑箱模型，也不保证外部工具执行的原子性。在无法回滚工具的场景，必须把“已开始执行”的操作与“待发起”的操作分开。

---

## 3. 现有工作与“撞题风险”核查

| 已有研究 | 已解决/覆盖的问题 | 第四篇不能再当作新创新 | 仍可认真研究的差异化空间 |
|---|---|---|---|
| Autellix (2025) [R1] | 把 Agent 程序视为一级调度对象，改善程序级排队 | “首次实现程序级 Agent 调度” | 网关外部工具限额、多租户公平保底、退避反馈 |
| Kairos (2025) [R2] | 多 Agent 工作流优先级与内存感知调度 | “首次使用工作流特征排优先级” | 工具配额与拥塞闭环、服务债务、突发公平 |
| Maestro (2026) [R3] | 跨集群工作流、GPU 预算、避免阻塞 | “首次进行全局工作流分配” | 低成本网关执行面、非 GPU 瓶颈联合限制 |
| Chimera (2026) [R4] | 异构模型 + 延迟/性能预测调度 | “模型与负载联合调度” | 不依赖新模型质量预测的 API 级控制与隔离 |
| H-MAS (ACL 2026) [R5] | 多租户 QoS 的分层自适应调度 | “首次闭环动态切换排队策略” | 严格 DAG 关键性与服务债务联合机制 |
| LLM-as-Scheduler (ACL 2026) [R6] | 根据请求选工作流复杂度 | “Agent 工作流动态决策本身是新” | 不改变工作流，仅治理混合资源与配额 |
| Dyserve (2026) [R7] | 编译期物理计划 + 动态负载调整 | “第一次根据负载优化 Agent DAG” | 多租户公平约束、非模型工具拥塞反馈 |
| Vesta (2026-10) [R8] | Cache locality + 队列 + 迁移调度 | “首次排队感知 Agent 服务” | 高层 API 速率配额、可解释的租户公平 |
| Cortex (2025 workshop) [R9] | Agent 阶段隔离与资源池 | “首次分阶段隔离” | 混合工作流饥饿、公平准入与工具瓶颈 |
| FairServe (2024 预印本) [R11] | 多租户 LLM 公平限流/计数 | “首次公平分配 Token 服务” | 工作流端到端公平 + DAG 依赖、多维资源 |
| FairInference (2026) [R12] | Token 级延迟公平性 | “首次多租户延迟隔离” | 网关层可行的任务级而非 GPU Token 级公平 |
| FastServe / Llumnix [R13,R14] | 反馈队列、抢占、动态迁移 | “首次使用抢占式请求调度” | 无法抢占工具的实际约束下的准入控制 |

**结论：** 这不是未经研究的空白领域。论文应定位为**面向混合瓶颈的有限约束改进**，而不是“通用多智能体最优调度框架”。只有在预设工作负载下获得统计显著增益且基线公平，才谈得上投稿竞争力。

### 3.1 四个可独立检验的研究假设

- **H1（关键路径）：** 对具有真实分支依赖、deadline 和重尾时延的 Agent DAG，请求级调度通常弱于正确设计的 DAG 级调度；比较相同总到达率与预算。
- **H2（反馈）：** 在配额突然下降、`429` 与批量重试时，带反压的动态准入可以比静态 Token Bucket 降低无效重试数与尾延迟。
- **H3（公平）：** 在重载下，使用最低份额和服务债务可降低租户饥饿率；但可能牺牲部分高优先级任务的 SLO，应画 Pareto 曲线，而非只报收益。
- **H4（稳健）：** 即使节点耗时估计存在 20%—50% 的偏差，调度增益也不应完全消失；这一百分比是**拟设实验扰动**，不是已测结果。

---

## 4. 建议的主方法 DAG-FlowGate

### 4.1 系统结构

```text
多租户请求（A / B / C...）
          │
   Workflow DAG 解析器
          │
  就绪节点提取 + deadline 推导
          │
┌──────────── 应用层 Agent 网关 ────────────┐
│  (1) 资源与拥塞观测器                    │
│      队长、实际吞吐、429、retry-after     │
│      tokens/sec、工具并发槽位            │
│  (2) 工作流估计器                        │
│      剩余关键路径、成本区间、关键节点     │
│  (3) 租户服务债务与公平约束              │
│      分配份额、历史服务、最小保障         │
│  (4) 两层调度器                          │
│      A. 工作流准入与速率反馈             │
│      B. 就绪节点选取与资源预约           │
│  (5) 审计 / 回放 / 可观测性             │
└────────────────────────────────────────┘
        │              │             │
      LLM API      外部工具 API     检索/数据库
        │              │             │
        └────── 结果 / 429 / 超时 ────────┘
                       │
               反馈至拥塞观测器
```

### 4.2 形式化建模

每项工作流 `j` 表示为有向无环图 `G_j = (V_j, E_j)`；节点 `v` 有资源向量：

`d_v = (预计 LLM tokens, 预计工具 API 次数, 预计执行时长)`。

**核心指标：**

`Goodput = #（成功且按时完成的工作流） / 观察时间`。

注意：**成功**需要事先固定判定标准（例如工具最终状态满足约束），不是收到 HTTP 200 就算成功。

可研究的多目标优化：

```text
maximize    成功且按时完成的工作流数 / 时间
            - λ1 * 预算超额处罚
            - λ2 * 租户公平性损失
            - λ3 * 限流失败与无效重试损失

subject to  各资源实时预算、工具并发槽位、租户最低份额、
            前驱节点完成后才能执行、已发出工具调用不可随意取消
```

其中 `λ1/λ2/λ3` 均应通过预注册的验证集选择；**不要把不同量纲指标任意加权再宣布最优**。主结果仍需分别展示 SLO/公平/成本的 Pareto 曲线。

#### 关键路径剩余估计

对 DAG 内每个节点定义：

`R(v) = estimated_duration(v) + max_{u in successors(v)} R(u)`，若没有后继，`R(v)=estimated_duration(v)`。

工作流松弛时间：

`Slack(j,t) = deadline(j) - t - max_{v in ready(j)} R(v)`。

松弛时间越少，理论上越紧迫；但它**不意味着任务一定应插队**，还要受租户保障和配额约束，且估计可能偏差。

#### 租户服务债务

用 `target_share_i` 表示租户 i 应得到的份额，`observed_service_i` 为窗口内实际服务，定义：

`Debt_i(t) = max(0, target_share_i * total_service(t) - observed_service_i(t))`。

为了避免频繁提交超多小请求来操纵调度，服务量应按约定的资源单位计量，**不能只按请求数量计算**；LLM Token 与工具调用需分别计量或归一化，并分析权重敏感性。

#### 拥塞反馈准入

维持每资源准入窗口 `W_r`：

- 队长和工具响应稳定、无明显配额警告时，缓慢增加；
- 收到 `429`、明确 `Retry-After` 或触发 P95 延迟阈值时，缩减并设置冷却；
- 用抖动退避避免同步重试；
- 对长时间等待但有最低份额权利的租户保留有限服务机会。

这是一种**待验证的工程控制结构**，不等同于直接证明 AIMD 在所有 Agent DAG 下稳定。

### 4.3 两层调度伪代码

```python
# 研究伪代码，不是已测试的完整实现

def on_tick(workflows, resources, telemetry, policy):
    update_resource_windows(telemetry, policy)   # API 429 / Retry-After / 队列积压
    update_tenant_service_debts(telemetry, policy)

    ready = []
    for job in workflows:
        if job.completed or job.cancelled:
            continue
        for node in job.ready_nodes():  # DAG 前驱必须已完成
            if not node.dispatched:
                urgency = estimate_critical_path_slack(job, node)
                debt = policy.tenant_debt(job.tenant)
                aging = policy.waiting_age(node)
                ready.append((job, node, urgency, debt, aging))

    # 先做可行性检查，不允许把不可预约的工具调用当作已开始
    feasible = [item for item in ready
                if within_budget(item, resources)
                and rate_window_available(item, resources)
                and workflow_admitted(item[0], policy)]

    # 仅对可行节点进行带公平约束的优先级选择
    selected = choose_nodes_with_fairness_floor(feasible, policy)
    for job, node, *_ in selected:
        if atomic_reserve_then_dispatch(node, resources):
            record_dispatch(job, node)

    # 失败或 429 后不会无条件同步重试
    return selected
```

**工程关键：** `atomic_reserve_then_dispatch` 要通过真实后端的原子令牌扣减或事务约束实现；否则多副本网关会出现双重占额。并非任何第三方工具都支持取消、精确计量、幂等性，因此只能保证**网关自身准入逻辑**，不保证外部执行的严格 exactly-once。

### 4.4 创新阶梯：保证可以小成本启动

| 层级 | 内容 | 本科生工作量 | 论文贡献边界 |
|---|---|---|---|
| **MVP v0** | DAG 模拟器 + FCFS、EDF、DRF、静态限流对照 | 低 | 实验平台，不是论文创新 |
| **v1（建议起点）** | DAG 关键路径 + 租户服务债务 + 工具拥塞反馈 | 中 | 可能构成网关控制算法贡献 |
| v2 | 带偏差区间的耗时估计 + 在线自适应调参 | 中高 | 证明稳健性，而非堆组件 |
| v3 | 控制理论/随机网络优化性质 + 多实例网关实验 | 高 | 可增强系统论文竞争力 |

**强烈不建议**一开始叠加强化学习、多智能体博弈、区块链、联邦学习以及各种“自适应模块”；会导致难以复现和无法明确每个模块带来的收益。

---

## 5. 交叉学科研究方向：8 个可做项目

| 跨学科 | 具体研究题目 | 可执行的实验 | 主创新候选 | 与第四篇的关联 |
|---|---|---|---|---|
| **排队论 × 计算机网络** | DAG 服务网络的突发抑制与排队稳定性 | M/G/1 近似 + 多资源离散事件模拟，比较 BBR/AIMD 式窗口思想与令牌桶 | 延迟反馈下的工作流级 admission | **最推荐**：系统理论支撑强 |
| **运筹学 × 多目标优化** | Deadline 与公平约束下的工作流调度 | EDF、关键路径、DRF、最小最大公平性对照；多目标 Pareto | 把任务完成率和租户公平均衡化 | **最推荐**：算法结果直观 |
| **控制理论 × 云计算** | 具有滞后观测的工具 API 拥塞控制 | 制造反馈延时/噪声和配额突降，测超调、稳态波动、恢复时长 | 稳健闭环控制器及可分析稳定条件 | 适合愿意写数学推导的人 |
| **可靠性工程 × 任务执行** | 重试放大下的级联拥塞防护 | 注入 429、超时、重试风暴，对照静态指数退避 | 感知“失败成本”的 admission 与防雪崩 | 可与第一篇配套，但保持算法独立 |
| **经济学 × 机制设计** | 多租户不可操纵的公平资源分配 | 以拆分请求、虚报 deadline 测策略抗操纵性 | 资源计量与服务债务防作弊 | 切勿声称已证明 strategy-proof |
| **绿色计算 × 能耗优化** | 面向峰谷电价与能耗限制的 Agent 排队控制 | 将批处理任务安排到低碳时窗，保持紧急任务 SLO | 碳预算与 SLO 共同约束的调度 | 需要真实/可靠电价碳强度数据 |
| **工业工程 × 生产调度** | 工厂多设备巡检 Agent 的共享工具限额治理 | 数字孪生：设备队列、工单 DAG、紧急/普通工单 | 双资源瓶颈的 deadline-aware scheduling | 必须用标准调度基准对照 |
| **公共服务 × 公平性评估** | 高并发公共查询 Agent 的服务公平性 | 合成不同需求群体的队列，测超时与服务饥饿 | 受保护任务的服务下限 | 可做模拟，避免使用真实敏感记录 |

### 5.1 给学弟的最优两条路线

**路线 A：科研风险较低 / 最推荐**  
网络拥塞控制 × 运筹学。论文只研究“在 API 配额可变的多租户 DAG 系统中，采用在线排队反馈+关键路径与公平预算的调度控制”。更容易建立强基线、写出数学问题、验证性能边界。

**路线 B：新颖但风险较高**  
控制理论 × 可靠性工程。专门研究 `429 → 重试 → 额外请求 → 再次 429` 的正反馈雪崩，通过流量准入和恢复配额实现阻尼控制。需要证明不是常规 Circuit Breaker + Retry-After 的换名。

---

## 6. 实验方案（SCI 审稿人真正会检查的内容）

### 6.1 数据集与工作负载

**A. 合成但可解释的 DAG（必须做）**

- **拓扑：** 链式、并行扇出、汇合、菱形、深层迭代式 DAG（有迭代时需展开为有界 DAG）；
- **并行度：** 2 / 4 / 8 / 16 个同时就绪分支（实验因素，不是实测数据）；
- **任务规模：** 10 / 50 / 200 / 1000 个工作流并发到达；
- **到达过程：** 稳定 Poisson、突发 On-Off、重尾服务时间、配额突然降低；
- **租户：** 普通批处理、交互紧急、重度 API 用户、恶意/误配置重试者；
- **错误注入：** 429、超时、5xx、延迟抖动、不可重试副作用节点；
- **公平约束：** 多租户份额 1:1、1:2、1:4，deadline 和预算随机但有固定种子。

**B. 真实 Agent 任务回放（至少一种）**

- [τ-bench（工具使用对话）](https://arxiv.org/abs/2406.12045)：适合构造工具调用依赖和状态有效性检查；
- [ToolBench / ToolLLM](https://arxiv.org/abs/2307.16789)：适合工具 API 类型与调用路径分析，原始工具端点可变化，优先本地 mock；
- [SWE-bench](https://arxiv.org/abs/2310.06770)：适合长时工作流，但成本较高；
- [AgentBench](https://arxiv.org/abs/2308.03688)：适合通用任务分布，不是直接的负载痕迹；
- [AutoGen](https://arxiv.org/abs/2308.08155) / [MetaGPT](https://arxiv.org/abs/2308.00352)：可生成多 Agent 拓扑，但不要将框架示例当做无偏“真实生产 Trace”。

**注意**：这些基准大多是能力/任务数据集，**不是现成的高并发 Agent 网关轨迹**。必须清楚注明哪些时延、并发和租户行为是人工合成；严禁把合成 trace 描述成真实生产数据。

**C. 真实部署（至少一轮）**

- 单机：FastAPI/Go 网关 + Redis 原子限额 + 3 类 HTTP Mock 工具 + 1 个真实小模型或可控制延迟的模型 API；
- 压力工具：Locust / k6；追踪：OpenTelemetry；
- 可选：Ray 的任务模型；若有 GPU 可用 vLLM/SGLang，但**不强制购置 GPU**；
- 必须从 `end_to_end latency`、应用层网关排队时间、真正模型推理时间、工具时延分别报告。

### 6.2 对照组——不能故意选弱基线

| 组别 | 算法/策略 | 目的 |
|---|---|---|
| B0 | FCFS + 常规 Token Bucket | 最基础工程基线 |
| B1 | EDF (Earliest Deadline First) + Token Bucket | deadline 约束基线 |
| B2 | SRPT / 估计最短剩余处理时间 | 吞吐/平均时延基线 |
| B3 | DRF 近似 / Weighted Fair Queueing | 资源公平基线 |
| B4 | 关键路径优先 DAG 调度 | 验证关键路径是否本身足够 |
| B5 | 静态优先级 + 标准 Retry-After/指数退避 | 网络/工具拥塞基线 |
| B6 | **可复现的 Autellix / Kairos 原算法实现**（条件许可） | 直接竞争基线，应忠于方法而非简化成 FCFS |
| B7 | DAG + 公平，无反馈 | 主方法去掉拥塞反馈的消融 |
| B8 | DAG + 反馈，无公平 | 主方法去掉公平约束的消融 |
| B9 | DAG-FlowGate（完整方法） | 主方案 |

**实验公平性：** 各组共享同一任务到达序列、同一后端容量、相同 retry budget、相同超时和任务成功判定。不能让主方法获得额外资源或知道未来任务，而基线看不到。

### 6.3 指标：必须一起看

**主指标**

1. Deadline-aware task Goodput（每秒成功且按时完成的工作流数）；
2. End-to-end P50/P95/P99 latency（工作流级）；
3. Task completion ratio（包括超时失败，不只统计被放行任务）；
4. API `429` rate 与 Retry Amplification Factor（每个逻辑工具调用最终触发的实际尝试次数）；
5. 租户 fairness：Jain 指数、最差租户成功率、P99 轮候、最长饥饿时间。

**辅助指标**：吞吐、Token 利用率、外部 API 配额利用率、丢弃/拒绝比率、排队长度/内存、调度额外 CPU 时间、部署成本。

**禁止的指标陷阱：** 只展示均值、只统计被接受请求、只展示某一类租户、没有 tail latency、没有任务正确性、只用几百个固定请求。

### 6.4 工作负载矩阵

| 轴 | 水平 | 用意 |
|---|---|---|
| 负载强度 | 0.3/0.6/0.9/1.1/1.5 × 标定系统容量 | 同时观察轻载、临界和过载 |
| 突发程度 | 平稳/中突发/强突发 | 逼出队列震荡 |
| 工具瓶颈 | 无/单工具/多工具 | 证明“网关层”差异 |
| DAG 结构 | 串行/扇出/汇合/深层 | 观察关键路径作用 |
| 租户比例 | 均匀/头部占 80%/轮换突发 | 验证公平和饥饿 |
| 估计误差 | 0/±20/±50% | 验证鲁棒性 |
| 配额突变 | 不变/下降 30%/下降 60% | 验证拥塞反馈 |
| 失败条件 | 0/5/15% 工具尝试失败 | 统计退避与恢复 |

以上均为**拟定实验条件**；不可写成论文结果。

### 6.5 统计学要求

- 每个随机负载条件至少 **10 个独立随机种子**（初步建议，按置信区间充分性调整）；
- 同一 trace 上配对比较，报告 95% bootstrap CI；
- 预注册主要指标与优先比较关系，避免择优展示；
- 所有含真实模型的实验至少报告模型版本、价格/费用、温度、Token 限制和任务正确性判定；
- 给出完整的随机种子、配置、Trace 生成器与原始日志，便于复现。

### 6.6 消融实验

A1：去掉 DAG，仅保留请求级队列；  
A2：去掉服务债务，仅做 deadline；  
A3：去掉拥塞反馈，窗口固定；  
A4：真实排队反馈换成延迟反馈；  
A5：节点成本使用真实值（Oracle 上界）与估计值；  
A6：不允许预留预算 / 错误计量多个资源；  
A7：关闭 `Retry-After` 支持；  
A8：只做模拟、不做真实代理部署（用于揭示模拟与部署差距）。

### 6.7 什么结果算“站得住”

不要提前保证“提升 30%”。正式立项的**主观 go/no-go 门槛**可设为：在至少 3 类不同工作负载下，针对竞争性合理基线，有可重复的 SLO Goodput 改善，且最差租户的延迟/完成率不明显恶化；这些阈值应在正式评价集之前定好。若改进仅来自某一个手工挑选的高峰负载，应如实报告适用范围或转向负结果论文。

---

## 7. 适合学弟的技术栈、工程结构与算力预算

**推荐语言组合：** Go（网关并发、限流、队列）+ Python（仿真、统计分析、原型算法）+ Redis（多副本配额）+ OpenTelemetry（追踪）。不需要重写推理引擎、也不需要训练大模型。

```text
dag-flowgate/
├── README.md
├── configs/
│   ├── workload_synthetic.yaml
│   ├── quota_shift.yaml
│   └── tenant_policy.yaml
├── docs/
│   ├── PROBLEM_DEFINITION.md
│   ├── BASELINE_FAIRNESS.md
│   └── REPRODUCIBILITY.md
├── sim/
│   ├── workload_generator.py
│   ├── dag_model.py
│   ├── resource_queue.py
│   └── replay.py
├── policy/
│   ├── fcfs.py
│   ├── edf.py
│   ├── drf.py
│   ├── critical_path.py
│   └── dag_flowgate.py
├── gateway/
│   ├── cmd/server/                 # Go 服务
│   ├── internal/admission/
│   ├── internal/quotas/
│   ├── internal/dispatch/
│   └── internal/telemetry/
├── tools/mock_server/
├── benchmarks/
│   ├── traces/
│   ├── injection/
│   └── results/
├── analysis/
│   ├── metrics.py
│   ├── stats.py
│   └── figures.py
└── paper/
    ├── outline.md
    └── related_work.md
```

**算力建议：**

- 阶段 1–3：普通 PC + Python 事件模拟即可，主要成本是时间；
- 阶段 4：本地 HTTP 模拟工具 + 少量实际 API 请求；记账并限额；
- 阶段 5：若可借到 GPU，只用来证明真实推理队列的现象一致；没有 GPU 也可做，但期刊适配和性能声明必须更保守。

**可发布开源部分：** synthetic workload generator、算法实现、对照组、固定种子、mock 工具、绘图脚本与运行环境。真实 API 密钥、私人业务流量、含机密数据的追踪不上传。

---

## 8. 12 周执行路线：什么时候值得动笔

| 周次 | 核心任务 | 必须交付 | Go/No-Go |
|---|---|---|---|
| 第1周 | 精读 Autellix、Kairos、Maestro、H-MAS、FairServe、DRF | 6 篇结构化笔记、Related Work 差异表 | 能否说出不重复的研究问题 |
| 第2周 | 固定 DAG / 资源 / 成功定义，生成 trace | 问题定义 v1，追踪 schema | 测试集不可先泄漏给算法 |
| 第3周 | FCFS、EDF、DRF、关键路径等基线 | 可复现基线 + 单元测试 | 各基线与预期行为一致 |
| 第4周 | v1 关键路径 + 租户服务债务 | 早期性能表和负例 | 至少不在典型负载明显退化 |
| 第5周 | 工具拥塞反馈 + Retry-After | API 突变实验 | 不会出现无限重试 |
| 第6周 | 消融与公平/尾延迟测试 | Pareto 曲线 | 明确哪个模块有贡献 |
| 第7周 | 预测误差和压力测试 | 稳健性报告 | 错误估计下仍有可解释行为 |
| 第8周 | Go 网关或 HTTP 真实执行面 | tracing + 端到端日志 | 证据不止模拟器 |
| 第9周 | 与可实现的代表性研究复现对照 | 独立复现说明 | 禁止把弱替代品冒充 SOTA |
| 第10周 | 统计分析、图表、成本核算 | 完整原始数据与绘图脚本 | 结论与误差区间一致 |
| 第11周 | 写摘要、方法、局限与讨论 | 英文初稿 | 自己能解释每个图 |
| 第12周 | 补实验、内审、期刊匹配 | 投前检查单 + Manuscript | 不合格则延后投，勿强投 |

**时间是建议研究进度，不是 SCI 审稿或录用预测**。尤其是数据记录、对照算法忠实程度和统计显著性往往比敲代码耗时更多。

---

## 9. SCI 期刊：优先“免费 + 相对快 + 范围匹配”

### 9.1 先澄清“免费”的含义

- **免费订阅发表：** 作者选择 Subscription / traditional publishing，通常无需支付 Article Processing Charge (APC)，但论文可能在付费墙后面，不等于读者可免费阅读。
- **免费开放获取（Diamond OA）：** 作者和读者都不付费；严格合适且稳定 SCIE 收录的选项较少，本专题**不将尚未核实 SCIE 的所谓“免费快刊”列为正式候选**。
- **不是保证零成本：** 个别期刊可能收超页费、彩印费或特殊费用；投稿前需要以 `Guide for Authors` 核查。下面“免费路线”指**通常无 APC 的订阅模式**。

### 9.2 优先候选：截至 2026-10-20 查询到的公开统计

**重点：** 表内时长是历史投稿至录用统计（主要来自期刊信息聚合页对出版商指标的转述），只覆盖最终录用稿件，不保证当前新投稿的速度；“编辑首次决定”包括很快的初筛/拒稿，**绝非审稿完成或录用**。

| 优先级 | 期刊与 ISSN | 研究契合 | 历史投稿→录用（约） | 外审后首次决定（约） | 无 APC 途径 | 风险及建议 |
|---|---|---|---|---|---|---|
| **A** | **Computer Communications** (0140-3664) | 应用层配额、拥塞与调度算法非常契合 | **177 天** | **80 天** | 选择订阅发表 | **建议首选**，务必把“拥塞反馈”做扎实 |
| **A** | **Future Generation Computer Systems** (0167-739X) | 云资源、工作流、弹性调度、规模测试非常契合 | **183 天** | **72 天** | 选择订阅发表 | **高匹配但竞争强**，需要系统/可扩展性证据 |
| **A-** | **Journal of Network and Computer Applications** (1084-8045) | 网关、API、网络服务、任务协同契合 | **187 天** | **88 天** | 选择订阅发表 | 应用需真实，不能只是理论仿真 |
| **B+** | **Computer Networks** (1389-1286) | 网络控制思想、测量和流量治理契合 | **样本中位数 183 天**（仅 15 篇的小样本，非官方口径） | 未可靠核实 | 通常订阅方式无 APC，投稿前再核查 | 需突出网络/协议层可迁移的系统贡献 |
| **B** | **Computers & Electrical Engineering** (0045-7906) | 边缘/IoT/网络与计算系统调度 | **169 天** | **71 天** | 选择订阅发表 | 范围弱于前三；且有第三方预警提示，务必核实单位政策 |
| **B** | **Journal of Systems and Software** (0164-1212) | 网关工程、软件质量、可观测性、部署评估 | **本次未获得一致可靠的最新录用时长** | 未可靠核实 | 选择订阅发表 | 如果论文有充分软件工程方法论才推荐 |
| **C** | **Journal of Parallel and Distributed Computing** (0743-7315) | 跨资源调度/分布式理论 | **约 323 天** | **162 天** | 选择订阅发表 | 太慢，不符合“快”优先条件，仅备用 |

**上述数字来自不同时间截面的公开记录：**

1. [Computer Communications 期刊数据与投稿周期](https://journalcompass.com/journals/computer-communications-01403664.html)；[出版商 Elsevier Journal Finder](https://journalfinder.elsevier.com/)（订阅版通常 no publishing charge）；
2. [FGCS 周期和政策](https://journalcompass.com/journals/future-generation-computer-systems-the-international-journal-of-escien-0167739x.html)；
3. [JNCA 周期和政策](https://journalcompass.com/journals/journal-of-network-and-computer-applications-10848045.html)；
4. [Computer Networks 小样本收录/录用日期回算](https://www.crushsci.com/journal/935)（不要与官网均值比较）；
5. [Computers & Electrical Engineering 周期/预警提示](https://journalcompass.com/journals/computers-electrical-engineering-00457906.html)；
6. [JSS 期刊信息与范围](https://journalcompass.com/journals/journal-of-systems-and-software-01641212.html)；
7. [Journal of Parallel and Distributed Computing 周期](https://journalcompass.com/journals/journal-of-parallel-and-distributed-computing-07437315.html)。

**严重提醒**：未能通过本轮页面直接独立确认每一本期刊的 2026 年当日 Clarivate SCIE 状态；以上均是 SCIE **候选**，正式投稿前必须逐本到 [Clarivate Master Journal List](https://mjl.clarivate.com/) 核实是否是 **Science Citation Index Expanded (SCIE)**，并检查期刊范围、分区和院校预警名单。**不能只凭 Scopus 或 Web of Science Core Collection 就说是 SCIE。**

### 9.3 与投稿策略配套的“范围决定优先级”

- **论文主打拥塞反馈/公平算法、API 队列：** Computer Communications > JNCA ≈ Computer Networks。
- **论文主打云上微服务/工作流系统、规模与部署：** FGCS > JNCA > JPDC。
- **论文主打架构工程与可靠性测试：** JSS（需要软件工程层面的普适贡献）> FGCS。
- **论文仅有数学模拟、缺真实系统：** 以上期刊均存在不低的桌拒风险；先补部署/完整实验，再选刊。
- **论文仅有应用界面、基本优先级和简单压力测试：** 暂不建议贸然投以上 SCI。

### 9.4 免费投稿的逐项核验清单

1. 用**完整期刊名 + ISSN**在 Clarivate MJL 核实 SCIE；记录检索日期和截图；
2. 在出版商期刊页面进入 `Journal Insights`，区分 *Submission to first decision*、*Submission to decision after review*、*Submission to acceptance*；
3. 在 `Article publishing options` 查找 **Subscription — No publication fee charged to authors**；
4. 查看作者指南有无强制 OA、submission fee、页面费或彩图费；
5. 阅读最近一年该刊 5–10 篇相似稿件，核对其 received/accepted 日期，而不是只盯期刊页面均值；
6. 检查学校/单位科研考核版本对中科院分区、预警和 online first 的要求；
7. 如希望论文对所有人免费，另查 green OA / accepted manuscript 合规自存档政策，别把“订阅免 APC”写成“开放获取免费”。

**投稿顺序建议（假设实验比较偏重网关拥塞控制）：** Computer Communications → FGCS → JNCA。不是质量排名，而是按**范围匹配 × 可选免 APC × 历史周期**的折衷排序。

---

## 10. 关联论文与相关工作地图（40 篇：都带题名、年份、来源链接、用途）

**阅读状态说明：** 这里只列**经网络检索定位到的真实条目**，并没有逐篇阅读全文。将它们列入“关联文献”不代表全部支持所提方法，也不代表都是同行评审正式发表。`[P]` 为目前使用预印本链接/尚需核实正式发表版本；`[C]` 为已确认的正式会议或论文集入口；`[J]` 为期刊论文。最终投稿须用 Crossref、DBLP、会议官网核对正式版本、作者、出版年、卷页与 DOI。

### A. 直接竞争：多 Agent / Agentic 工作流调度（强制精读）

| 编号 | 论文（年份） | 状态 | 与本研究关系 | 链接 |
|---|---|---|---|---|
| **R1** | **Autellix: An Efficient Serving Engine for LLM Agents as General Programs** (2025) | [P] | Agent 程序级调度最直接基线 | https://arxiv.org/abs/2502.13965 |
| **R2** | **Kairos: Low-latency Multi-Agent Serving with Shared LLMs and Excessive Loads in the Public Cloud** (2025) | [P] | 工作流排队与多 Agent 共享后端 | https://arxiv.org/abs/2508.06948 |
| **R3** | **Maestro: Workload-Aware Cross-Cluster Scheduling for LLM-Based Multi-Agent Systems** (2026) | **[C] ICDCS 2026** | 跨集群/层级调度最强竞争之一 | https://arxiv.org/abs/2606.12950 |
| **R4** | **Chimera: Latency- and Performance-Aware Multi-agent Serving for Heterogeneous LLMs** (2026) | [P] | 异构模型调度与拥塞 | https://arxiv.org/abs/2603.22206 |
| **R5** | **H-MAS: Hierarchical Multi-Agent Scheduling for Multi-Tenant LLM Serving** (2026) | **[C] Findings of ACL 2026** | 多租户闭环 QoS，严禁重名式创新 | https://aclanthology.org/2026.findings-acl.1946/ |
| **R6** | **LLM-as-Scheduler: Agentic Workflow Dynamic Scheduling** (2026) | **[C] ACL 2026** | 动态选择工作流复杂度 | https://aclanthology.org/2026.acl-long.581/ |
| **R7** | **Serving Agentic Workflows with a Physical-Plan Compiler and Adaptive Runtime** / Dyserve (2026) | [P] | 工作流物理计划与实时压力选择 | https://arxiv.org/abs/2607.02942 |
| **R8** | **Vesta: Queueing-Aware LLM Scheduling for Real-World Workloads** (2026-10) | [P] | 排队反馈、KV 缓存、迁移；最新研究 | https://arxiv.org/abs/2610.14686 |
| **R9** | **Cortex: Workflow-Aware Resource Pooling and Scheduling for Agentic Serving** (2025) | [C] SAA Workshop at SOSP 2025 | 阶段隔离，需防止方法重复 | https://research.google/pubs/cortex-workflow-aware-resource-pooling-and-scheduling-for-agentic-serving/ |
| **R10** | **Continuum: Efficient and Robust Multi-Turn LLM Agent Scheduling with KV Cache Time-to-Live** (2025/2026 修订) | [P] | 工具等待状态与 KV 保留时长 | https://arxiv.org/abs/2511.02230 |

### B. 多租户公平与推理服务（强制精读中 3–5 篇）

| 编号 | 论文（年份） | 状态 | 与本研究关系 | 链接 |
|---|---|---|---|---|
| **R11** | **Ensuring Fair LLM Serving Amid Diverse Applications** / FairServe (2024) | [P] | 应用感知公平限流与服务计数 | https://arxiv.org/abs/2411.15997 |
| **R12** | **Token Latency Fairness: Performance Isolation for Multi-Tenant LLM Serving** (2026) | [P] | 任务级公平与 Token 级公平的边界 | https://arxiv.org/abs/2609.18112 |
| **R13** | **Fast Distributed Inference Serving for Large Language Models** / FastServe (2023) | [P] | 抢占与多级反馈队列基线 | https://arxiv.org/abs/2305.05920 |
| **R14** | **Llumnix: Dynamic Scheduling for Large Language Model Serving** (2024) | [P] | 动态迁移与尾延迟隔离 | https://arxiv.org/abs/2406.03243 |
| **R15** | **Orca: A Distributed Serving System for Transformer-Based Generative Models** (2022) | **[C] OSDI 2022** | iteration-level scheduling 经典基线 | https://www.usenix.org/conference/osdi22/presentation/yu |
| **R16** | **Efficient Memory Management for Large Language Model Serving with PagedAttention** / vLLM (2023) | **[C] SOSP 2023** | KV 缓存/持续批处理实现基础 | https://doi.org/10.1145/3600006.3613165 |
| **R17** | **DistServe: Disaggregating Prefill and Decoding for Goodput-optimized Large Language Model Serving** (2024) | **[C] OSDI 2024** | Goodput / TTFT / TPOT 评价 | https://www.usenix.org/conference/osdi24/presentation/zhong-yinmin |
| **R18** | **Taming Throughput-Latency Tradeoff in LLM Inference with Sarathi-Serve** (2024) | **[C] OSDI 2024** | 延迟与吞吐权衡 | https://www.usenix.org/conference/osdi24/presentation/agrawal |
| **R19** | **Splitwise: Efficient Generative LLM Inference Using Phase Splitting** (2024) | **[C] ISCA 2024** | 推理不同阶段的分资源预算 | https://www.microsoft.com/en-us/research/publication/splitwise-efficient-generative-llm-inference-using-phase-splitting/ |
| **R20** | **SGLang: Efficient Execution of Structured Language Model Programs** (2023/2024) | [P] | Agent 脚本执行、RadixAttention 后端 | https://arxiv.org/abs/2312.07104 |

### C. 性能仿真、集群调度、多模型/多适配器服务

| 编号 | 论文（年份） | 状态 | 与本研究关系 | 链接 |
|---|---|---|---|---|
| **R21** | **Helix: Distributed Serving of Large Language Models via Max-Flow on Heterogeneous GPUs** (2024) | [P] | 多资源容量图和调度数学建模 | https://arxiv.org/abs/2406.01566 |
| **R22** | **Preble: Efficient Distributed Prompt Scheduling for LLM Serving** (2024) | [P] | 提示复用与负载均衡 | https://arxiv.org/abs/2407.00023 |
| **R23** | **Vidur: A Large-Scale Simulation Framework For LLM Inference** (2024) | [P] | 仿真校准与误差评估方法 | https://arxiv.org/abs/2405.05465 |
| **R24** | **Optimizing Long-context LLM Serving via Fine-grained Sequence Parallelism** / Tetris (2025) | [P] | 根据负载改变执行并行度 | https://arxiv.org/abs/2511.06247 |
| **R25** | **Punica: Multi-Tenant LoRA Serving** (2023) | [P] | 共享资源、多租户不同适配器 | https://arxiv.org/abs/2310.18547 |
| **R26** | **S-LoRA: Serving Thousands of Concurrent LoRA Adapters** (2023) | [P] | LoRA 适配器资源共享 | https://arxiv.org/abs/2311.03285 |
| **R27** | **PLoRA: An NDP-Enhanced Pooled-Memory System for Cost-Efficient Multi-LoRA Serving** (2026) | [P] | 显存/池化资源交叉方向 | https://arxiv.org/abs/2608.05483 |
| **R28** | **Ray: A Distributed Framework for Emerging AI Applications** (2018) | **[C] OSDI 2018** | 执行底座、actor 与 DAG 分布式任务 | https://www.usenix.org/conference/osdi18/presentation/moritz |
| **R29** | **Gandiva: Introspective Cluster Scheduling for Deep Learning** (2018) | **[C] OSDI 2018** | 作业迁移与资源调度经典研究 | https://www.usenix.org/conference/osdi18/presentation/xiao |

### D. Agent 基准与多智能体交互（用于实际工作流）

| 编号 | 论文（年份） | 状态 | 与本研究关系 | 链接 |
|---|---|---|---|---|
| **R30** | **AgentBench: Evaluating LLMs as Agents** (2023) | [P] | Agent 交互任务基准 | https://arxiv.org/abs/2308.03688 |
| **R31** | **τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains** (2024) | [P] | 工具执行状态与成功性测量 | https://arxiv.org/abs/2406.12045 |
| **R32** | **ToolLLM: Facilitating Large Language Models to Master 16000+ Real-world APIs** (2023) | [P] | ToolBench、API 调用关系 | https://arxiv.org/abs/2307.16789 |
| **R33** | **SWE-bench: Can Language Models Resolve Real-World GitHub Issues?** (2023) | [P] | 长任务 Agent 工作负载 | https://arxiv.org/abs/2310.06770 |
| **R34** | **AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent Conversation** (2023) | [P] | 产生多 Agent 拓扑和执行日志 | https://arxiv.org/abs/2308.08155 |
| **R35** | **MetaGPT: Meta Programming for A Multi-Agent Collaborative Framework** (2023) | [P] | 角色协作工作流生成 | https://arxiv.org/abs/2308.00352 |

### E. 跨学科理论：资源公平、网络拥塞与排队稳定性

| 编号 | 论文（年份） | 状态 | 与本研究关系 | 链接 |
|---|---|---|---|---|
| **R36** | **Dominant Resource Fairness: Fair Allocation of Multiple Resource Types** (2011) | **[C] NSDI 2011** | 多资源公平分配理论 | https://www.usenix.org/conference/nsdi11/dominant-resource-fairness-fair-allocation-multiple-resource-types |
| **R37** | **Data Center TCP (DCTCP)** (2010) | **[C] SIGCOMM 2010** | 拥塞反馈与突发队列控制思想 | https://www.microsoft.com/en-us/research/publication/data-center-tcp-dctcp/ |
| **R38** | **Stability Properties of Constrained Queueing Systems and Scheduling Policies for Maximum Throughput in Multihop Radio Networks** (1992) | **[J] IEEE TAC** | MaxWeight/稳定性理论基础 | https://doi.org/10.1109/9.182479 |
| **R39** | **The Power of Two Choices in Randomized Load Balancing** (1996) | **博士论文** | 两选择负载均衡，服务端副本分配 | https://www2.eecs.berkeley.edu/Pubs/TechRpts/1996/7979.html |
| **R40** | **Multi-agent Large Language Models as Evolutionary Optimizers for Scheduling Optimization** (2025) | **[J] Computers & Industrial Engineering** | 交叉：LLM 作为调度优化器；与网关调度要区别 | https://doi.org/10.1016/j.cie.2025.111197 |

**额外推荐方法书（不计入 40 篇）：** Michael J. Neely, *Stochastic Network Optimization with Application to Communication and Queueing Systems* (2010), https://link.springer.com/book/10.1007/978-3-031-79995-2 。如需要 Lyapunov drift-plus-penalty 证明，应从这里学习；不能直接拿书中定理套到异步有环/未知服务时间的 Agent 工作流。

### 10.1 文献完整性说明与不足

- 此清单为 **40 条真实可追踪研究文献**，但 **R39 是博士学位论文而非期刊/会议论文**。因此若严格计算“期刊或会议研究论文”，上表为 **39 篇研究论文 + 1 篇学位论文**，满足“不少于 30 篇关联论文”。
- [P] 只表示此文件链接到 arXiv/预印本版本，**不能自动推出它没有正式出版**；最终投稿请按最新正式版本改写参考文献。
- [R10] 的 arXiv 号首发于 2025，后续版本/传播发生在 2026；年份应按选用版本单独核查。
- [R36–R39] 是基础理论并非 Agent 文献，作用是提供模型、准则或证明工具，不能声称与主题一模一样。
- 不应把尚未实验验证的 DAG-FlowGate 方案写成已经打败以上论文，也不要使用“首次”“绝对最优”这种未经系统性检索与形式证明的措辞。

---

## 11. 和第一、二、三、五篇的关系：避免自我重复投稿

四篇分别有明确的因变量和实验对象：

| 研究 | 输入 | 独立核心决策 | 主指标 |
|---|---|---|---|
| 第一篇 故障恢复 | 失败调用链 | 恢复、重试、回滚还是升级 | 正确恢复率/副作用/恢复耗时 |
| 第二篇 多模型路由 | 一次模型调用需求 | 用哪个模型、何时验证 | 完成任务成本/质量/验证费 |
| 第三篇 MCP 安全 | 工具操作和权限上下文 | 是否授权与执行 | 越权阻止率/误拦率/开销 |
| **第四篇 调度/拥塞** | 并发 DAG、租户和配额 | 谁先跑、何时允许跑、何时退避 | **deadline-aware Goodput/公平/P99** |
| 第五篇 异常溯源 | 分布式追踪和历史调用 | 最可能的故障源头是什么 | 根因定位准确率/检测耗时 |

**共享代码是可以的，共享相同主创新、同一组结果拆成多篇投稿则有重复发表风险。** 每篇须独立提出研究问题、严格可区分的数据/实验和实质贡献，且如实披露既有相关投稿。

---

## 12. 最终建议与风险评估

### 12.1 论文可能成立的三个创新声明（都必须经过验证）

1. **DAG-Dependency-aware Admission：** 在混合模型/工具瓶颈和全局 deadline 下，依据剩余关键路径与资源可行性进行任务准入，降低上游抢占导致的无效拥塞。
2. **Fairness Debt Scheduling：** 在工作流级引入服务债务约束，限制高提交量租户占满共享资源，同时避免小/慢租户长期无法完成任务。
3. **Rate-Feedback Control：** 使用工具响应与队列拥塞信号调整多资源准入窗口，削弱 `429—重试—再次拥塞` 的放大环路。

**这里最重要的是“组合后是否出现了单项方法不能解决的新性质”，而不是把三项常见算法堆起来。** 若仅仅三种算法分别有效，但组合没有研究价值，创新声明应主动收窄到一个真正可证明的核心点。

### 12.2 技术与投稿风险（研究规划中的主观判断）

| 风险 | 级别 | 控制方式 |
|---|---|---|
| 2025–2026 直接相关竞争论文密集 | **高** | 先完成差异表和最强可复现基线 |
| 没有服务器，缺少真实高并发 Trace | 中高 | 合成负载 + 真实 HTTP 回放 + 公开实验边界 |
| 依赖图估计误差导致算法失效 | 中高 | 估计偏差敏感性与坏案例 |
| 租户公平和高优先级 SLO 冲突 | 中高 | Pareto 曲线，不隐瞒 tradeoff |
| 期刊费用与周期变动 | 中 | 投稿当日二次核对官网和 MJL |
| 只做模拟，系统论文实验不足 | 高 | 真实网关部署与错误注入必做 |

**个人选题判断：** 第四篇具备写出完整 SCI 系统论文的可能，但比第一篇（故障恢复）更依赖强基线与充分系统评测。最稳妥的推进方法是把题目从“通用多 Agent 调度”缩到“**共享外部 API 配额下的多租户 Agent DAG 拥塞控制**”，先完成 v1 并拿出可信对照图，再扩展 GPU 资源调度。

### 12.3 立项前 7 个自问

1. 是否能用一句话说明它与 Autellix、Kairos、H-MAS 的不同？
2. 任务成功是否有外部可验证标准，而不是模型自评？
3. Baseline 是否包括 deadline、公平和拥塞反馈三类方法？
4. 是否有至少一种真实执行/回放实验而非纯玩具模拟？
5. 报告的收益是否是全流量结果而非被接受流量的幸存者偏差？
6. 是否承认 fairness / latency / cost 之间的损失与交换？
7. 投前是否独立核实了 SCIE、订阅免费发表、实际投稿时的费用政策？

满足这些后，第四篇才值得正式投递。

---

## 13. 公开资料与查证入口

- Clarivate Master Journal List（核实 **SCIE** 而不是泛 Web of Science）：https://mjl.clarivate.com/
- Elsevier Journal Finder（出版商投稿与收费方式）：https://journalfinder.elsevier.com/
- Elsevier 官方期刊页面（投稿前逐本查询 `Journal Insights`）：
  - Computer Communications: https://www.sciencedirect.com/journal/computer-communications
  - Future Generation Computer Systems: https://www.sciencedirect.com/journal/future-generation-computer-systems
  - Journal of Network and Computer Applications: https://www.sciencedirect.com/journal/journal-of-network-and-computer-applications
  - Computer Networks: https://www.sciencedirect.com/journal/computer-networks
  - Journal of Systems and Software: https://www.sciencedirect.com/journal/journal-of-systems-and-software
  - Computers & Electrical Engineering: https://www.sciencedirect.com/journal/computers-and-electrical-engineering
- ACL 2026 论文正式页面：
  - H-MAS: https://aclanthology.org/2026.findings-acl.1946/
  - LLM-as-Scheduler: https://aclanthology.org/2026.acl-long.581/
- USENIX 论文原页：
  - Orca: https://www.usenix.org/conference/osdi22/presentation/yu
  - DistServe: https://www.usenix.org/conference/osdi24/presentation/zhong-yinmin
  - Sarathi-Serve: https://www.usenix.org/conference/osdi24/presentation/agrawal
  - Ray: https://www.usenix.org/conference/osdi18/presentation/moritz
- 期刊历史信息聚合（**不能替代官网**）：
  - https://journalcompass.com/
  - https://www.crushsci.com/journal/935

---

## 14. 建议的最终研究摘要（**拟议，不是成果**）

> **拟议摘要中文草案**  
> 大语言模型驱动的多智能体系统通常通过具有依赖关系的多阶段工作流完成任务。在多租户场景下，这些工作流需要共享模型推理服务、外部工具接口与有限 API 配额。现有请求级调度和固定限流方案可能忽略工作流关键路径、租户长期公平性以及工具调用失败引起的重试放大。为研究这些问题，本文拟设计 DAG-FlowGate，一种部署于 Agent 网关边界的依赖感知公平拥塞控制方法。该方法联合估计工作流剩余关键路径、租户服务债务和实时资源拥塞信号，并通过分层准入控制及节点调度优化按时成功完成的任务数量。拟采用真实工具交互任务回放、可控 DAG 负载、工具配额突变与多租户混合流量进行评价，对比 FCFS、EDF、DRF、关键路径策略及代表性 Agent 服务调度研究，重点测量任务级 Goodput、尾延迟、租户饥饿与重试放大。最终性能收益、适用条件与局限将由实验确定。  
> **关键词：** LLM Agents; Multi-Agent Systems; Workflow Scheduling; Congestion Control; API Gateway; Resource Fairness; Queueing Theory.

**特别说明：** 这段是写论文前的立项目标表述，绝对不能未经测试就把“拟采用”“拟设计”改成“已实现”“显著超越”。

---

*文档完成。适合作为第四篇研究立项报告初稿，正式投稿前仍需全文阅读直接竞争论文、复核索引状态与期刊政策、完成独立实验。*
