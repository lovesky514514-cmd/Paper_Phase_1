module example.org/dagflowgate04

go 1.22
