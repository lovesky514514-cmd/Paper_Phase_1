"""Immutable DAG input and validation. Durations and limits use milliseconds."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Node:
    id: str
    resource: str
    duration_ms: int
    units: int
    dependencies: tuple[str, ...] = ()
    retry_safe: bool = True
    estimated_ms: int | None = None

    def estimate(self) -> int:
        return self.duration_ms if self.estimated_ms is None else self.estimated_ms


@dataclass(frozen=True)
class Job:
    id: str
    tenant: str
    arrival_ms: int
    deadline_ms: int
    nodes: tuple[Node, ...]
    priority: int = 0


@dataclass(frozen=True)
class Trace:
    jobs: tuple[Job, ...]

    def validate(self) -> None:
        seen_jobs: set[str] = set()
        for job in self.jobs:
            if not job.id or job.id in seen_jobs or not job.tenant:
                raise ValueError("empty/duplicate job ID or empty tenant")
            seen_jobs.add(job.id)
            if job.arrival_ms < 0 or job.deadline_ms <= job.arrival_ms or not job.nodes:
                raise ValueError(f"invalid arrival/deadline/nodes for {job.id}")
            nodes = {node.id: node for node in job.nodes}
            if len(nodes) != len(job.nodes) or not all(nodes):
                raise ValueError(f"duplicate/empty node ID in {job.id}")
            for node in job.nodes:
                if (node.resource not in {"llm", "tool"} or node.duration_ms <= 0
                        or node.units <= 0 or node.estimate() <= 0):
                    raise ValueError(f"invalid resource/demand in {job.id}/{node.id}")
                if node.id in node.dependencies or len(node.dependencies) != len(set(node.dependencies)):
                    raise ValueError("self/duplicate dependency")
                if any(parent not in nodes for parent in node.dependencies):
                    raise ValueError(f"missing dependency for {node.id}")
            visiting: set[str] = set()
            visited: set[str] = set()

            def visit(node_id: str) -> None:
                if node_id in visiting:
                    raise ValueError(f"cycle in {job.id}")
                if node_id in visited:
                    return
                visiting.add(node_id)
                for parent in nodes[node_id].dependencies:
                    visit(parent)
                visiting.remove(node_id)
                visited.add(node_id)

            for node in job.nodes:
                visit(node.id)
