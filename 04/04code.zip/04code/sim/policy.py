"""Comparable ready-node ranking rules; all policies see the same evidence."""
from collections.abc import Mapping
from .model import Job, Node

POLICIES = ("fcfs", "edf", "srpt", "wfq", "critical", "static", "dag_fair", "dag_feedback", "flowgate")


def remaining_path(job: Job, completed: set[str]) -> dict[str, int]:
    """Longest estimated suffix per node, excluding already completed nodes."""
    successors: dict[str, list[str]] = {n.id: [] for n in job.nodes}
    for node in job.nodes:
        for parent in node.dependencies:
            successors[parent].append(node.id)
    memo: dict[str, int] = {}
    node_by_id = {n.id: n for n in job.nodes}

    def path(node_id: str) -> int:
        if node_id in memo:
            return memo[node_id]
        if node_id in completed:
            return 0
        value = node_by_id[node_id].estimate() + max((path(c) for c in successors[node_id]), default=0)
        memo[node_id] = value
        return value

    return {node.id: path(node.id) for node in job.nodes}


def rank(policy: str, job: Job, node: Node, now: int, path: Mapping[str, int],
         served: Mapping[str, float], shares: Mapping[str, float]) -> tuple:
    """Smaller tuples dispatch earlier. Service counts reserved resource units."""
    debt_order = served.get(job.tenant, 0.0) / shares[job.tenant]
    slack = job.deadline_ms - now - path[node.id]
    if policy == "fcfs":
        return (job.arrival_ms, job.id, node.id)
    if policy == "edf":
        return (job.deadline_ms, job.arrival_ms, job.id, node.id)
    if policy == "srpt":
        return (sum(n.estimate() for n in job.nodes if n.id not in path or path[n.id] > 0), job.id, node.id)
    if policy == "wfq":
        return (debt_order, job.arrival_ms, job.id, node.id)
    if policy == "critical" or policy == "dag_feedback":
        return (slack, job.arrival_ms, job.id, node.id)
    if policy == "static":
        return (-job.priority, job.arrival_ms, job.id, node.id)
    # Fairness floor: least-served weighted tenant first, then critical path.
    return (debt_order, slack, job.arrival_ms, job.id, node.id)
