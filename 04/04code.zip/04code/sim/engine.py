"""Deterministic, single-threaded discrete-event simulator with explicit limits."""
from dataclasses import dataclass, field
import hashlib
import math
from .model import Job, Node, Trace
from .policy import POLICIES, rank, remaining_path


@dataclass(frozen=True)
class Settings:
    slots: int = 3
    bucket: float = 9.0
    local_rate: float = 0.34  # resource units per millisecond
    external_rate: float = 0.27  # service-side quota, unknown to policy
    shift_ms: int | None = 350
    shifted_fraction: float = 0.55
    max_retries: int = 2
    retry_after_ms: int = 18
    cooldown_ms: int = 28
    max_time_ms: int = 50_000
    fault_rate: float = 0.0  # Fraction of accepted requests returning ambiguous 5xx/timeouts.
    fault_seed: int = 0
    tenant_weights: dict[str, float] = field(default_factory=dict)

    def validate(self) -> None:
        if (self.slots < 1 or self.bucket <= 0 or self.local_rate <= 0
                or self.external_rate <= 0 or not 0 < self.shifted_fraction <= 1
                or self.max_retries < 0 or self.retry_after_ms < 1
                or self.cooldown_ms < 1 or self.max_time_ms < 1
                or not 0 <= self.fault_rate <= .5
                or any(not math.isfinite(v) or v <= 0 for v in self.tenant_weights.values())):
            raise ValueError("invalid simulator limits")


@dataclass
class JobOutcome:
    status: str = "pending"
    starts: dict[str, int] = field(default_factory=dict)
    finishes: dict[str, int] = field(default_factory=dict)
    attempts: dict[str, int] = field(default_factory=dict)
    ready_since: dict[str, int] = field(default_factory=dict)
    completed: set[str] = field(default_factory=set)
    active: set[str] = field(default_factory=set)
    backoff: dict[str, int] = field(default_factory=dict)
    finished_at: int | None = None
    reason: str = ""


@dataclass
class RunResult:
    policy: str
    jobs: dict[str, JobOutcome]
    events: list[dict]
    service: dict[str, float]
    horizon_ms: int
    shares: dict[str, float]

    def summary(self) -> dict:
        import math
        finished = [j for j in self.jobs.values() if j.status == "success"]
        total = len(self.jobs)
        on_time = len(finished)
        latencies = sorted(j.finished_at - next(e["time_ms"] for e in self.events
                            if e["kind"] == "arrival" and e["job"] == job_id)
                           for job_id, j in self.jobs.items() if j.status == "success")
        def percentile(values: list[int], p: float) -> int | None:
            if not values:
                return None
            return values[math.ceil(p * len(values)) - 1]
        attempts = sum(1 for e in self.events if e["kind"] in {"dispatch", "rate_limited"})
        logical_calls = len({(e["job"], e["node"]) for e in self.events
                             if e["kind"] in {"dispatch", "rate_limited"}})
        waits = sorted((state.starts[node] if node in state.starts else state.finished_at)
                       - when for state in self.jobs.values()
                       for node, when in state.ready_since.items()
                       if node in state.starts or state.finished_at is not None)
        shares = [v / self.shares[k] for k, v in self.service.items()]
        fairness = (sum(shares) ** 2 / (len(shares) * sum(x * x for x in shares))) if any(shares) else 0
        by_tenant: dict[str, dict[str, int]] = {}
        for e in self.events:
            if e["kind"] == "arrival":
                by_tenant.setdefault(e["tenant"], {"total": 0, "success": 0})["total"] += 1
            if e["kind"] == "complete_job":
                by_tenant[e["tenant"]]["success"] += 1
        arrival_times = {e["job"]: e["time_ms"] for e in self.events if e["kind"] == "arrival"}
        end_to_end = sorted(j.finished_at - arrival_times[jid] for jid, j in self.jobs.items()
                            if j.finished_at is not None)
        return {
            "policy": self.policy, "tasks": total, "success": on_time,
            "completion_ratio": round(on_time / total, 6) if total else 0,
            "goodput_per_second": round(on_time / (self.horizon_ms / 1000), 6),
            "p50_ms": percentile(latencies, 0.5),
            "p95_ms": percentile(latencies, 0.95),
            "p99_ms": percentile(latencies, 0.99),
            "p95_all_jobs_ms": percentile(end_to_end, .95),
            "failed_or_timed_out": total - on_time,
            "simulated_5xx": sum(e["kind"] == "http_5xx" for e in self.events),
            "simulated_timeouts": sum(e["kind"] == "lost_response" for e in self.events),
            "rate_429": sum(e["kind"] == "rate_limited" for e in self.events),
            "retry_amplification": round(attempts / logical_calls, 6) if logical_calls else 0,
            "p99_ready_to_start_or_stop_ms": percentile(waits, .99),
            "fairness_jain_service": round(fairness, 6),
            "tenants": by_tenant,
            "worst_tenant_completion": round(min((v["success"] / v["total"]
                                                   for v in by_tenant.values()), default=0), 6),
            "stopped_unsafe": sum(j.reason == "unsafe_retry" for j in self.jobs.values()),
        }


class Simulator:
    def __init__(self, settings: Settings, policy: str = "flowgate") -> None:
        settings.validate()
        if policy not in POLICIES:
            raise ValueError(f"unknown policy {policy}")
        self.settings = settings
        self.policy = policy

    def run(self, trace: Trace) -> RunResult:
        trace.validate()
        s = self.settings
        jobs = {job.id: JobOutcome() for job in trace.jobs}
        served = {job.tenant: 0.0 for job in trace.jobs}
        # Fixed equal shares for the default lab; configurable weights are next stage.
        shares = {tenant: s.tenant_weights.get(tenant, 1.0) for tenant in served}
        local = {r: s.bucket for r in ("tool", "llm")}
        external = {r: s.bucket for r in local}
        active: dict[str, list[tuple[int, str, str, str]]] = {r: [] for r in local}
        window = {r: s.slots for r in local}
        cooldown = {r: 0 for r in local}
        adaptive_rate = {r: s.local_rate for r in local}
        recovered = {r: 0 for r in local}
        events: list[dict] = []
        horizon = max((job.deadline_ms for job in trace.jobs), default=1)
        if horizon > s.max_time_ms:
            raise ValueError("trace horizon exceeds max_time_ms")
        arrival = sorted(trace.jobs, key=lambda j: (j.arrival_ms, j.id))
        arriving = 0
        nodes = {job.id: {node.id: node for node in job.nodes} for job in trace.jobs}

        def terminal(job: Job, when: int, reason: str) -> None:
            state = jobs[job.id]
            if state.status not in {"pending", "running"}:
                return
            state.status = "failed" if reason != "deadline" else "timeout"
            state.finished_at = when
            state.reason = reason
            events.append({"kind": "stop", "job": job.id, "tenant": job.tenant,
                           "time_ms": when, "reason": reason})

        # Impossible jobs fail input validation, rather than silently expiring.
        if any(node.units > s.bucket for job in trace.jobs for node in job.nodes):
            raise ValueError("node unit demand exceeds bucket capacity")
        for t in range(horizon + 1):
            while arriving < len(arrival) and arrival[arriving].arrival_ms <= t:
                j = arrival[arriving]
                events.append({"kind": "arrival", "job": j.id, "tenant": j.tenant, "time_ms": t})
                arriving += 1
            # Finished external calls cannot be cancelled, even after a task deadline.
            for resource, in_flight in active.items():
                keep = []
                for finish, job_id, node_id, outcome in in_flight:
                    if finish > t:
                        keep.append((finish, job_id, node_id, outcome))
                        continue
                    state = jobs[job_id]
                    state.active.remove(node_id)
                    if outcome != "ok":
                        events.append({"kind": outcome, "job": job_id,
                                       "node": node_id, "time_ms": t})
                        node = nodes[job_id][node_id]
                        if state.status in {"pending", "running"}:
                            if not node.retry_safe:
                                job = next(j for j in trace.jobs if j.id == job_id)
                                terminal(job, t, "unsafe_retry")
                            elif state.attempts[node_id] > s.max_retries:
                                job = next(j for j in trace.jobs if j.id == job_id)
                                terminal(job, t, "retry_budget")
                            else:
                                state.backoff[node_id] = t + s.retry_after_ms * (2 ** state.attempts[node_id])
                        continue
                    state.finishes[node_id] = finish
                    state.completed.add(node_id)
                    events.append({"kind": "finish", "job": job_id, "node": node_id,
                                   "resource": resource, "time_ms": t})
                    if state.status in {"pending", "running"} and len(state.completed) == len(nodes[job_id]):
                        state.status = "success"
                        state.finished_at = t
                        tenant = next(j.tenant for j in trace.jobs if j.id == job_id)
                        events.append({"kind": "complete_job", "job": job_id,
                                       "tenant": tenant, "time_ms": t})
                active[resource] = keep
                if self.policy in {"flowgate", "dag_feedback"} and cooldown[resource] <= t:
                    recovered[resource] += len(in_flight) - len(keep)
                    adaptive_rate[resource] = min(s.local_rate, adaptive_rate[resource] + .004 * (len(in_flight) - len(keep)))
                    if recovered[resource] >= 5 and window[resource] < s.slots:
                        window[resource] += 1  # additive recovery
                        recovered[resource] = 0
            for job in trace.jobs:
                if job.arrival_ms <= t and t >= job.deadline_ms:
                    terminal(job, t, "deadline")
            for resource in local:
                refill_rate = adaptive_rate[resource] if self.policy in {"flowgate", "dag_feedback"} else s.local_rate
                local[resource] = min(s.bucket, local[resource] + refill_rate)
                ext_rate = s.external_rate
                if s.shift_ms is not None and t >= s.shift_ms:
                    ext_rate *= s.shifted_fraction
                external[resource] = min(s.bucket, external[resource] + ext_rate)
            ready = []
            for job in trace.jobs:
                if job.arrival_ms > t or jobs[job.id].status not in {"pending", "running"}:
                    continue
                state = jobs[job.id]
                path = remaining_path(job, state.completed)
                for node in job.nodes:
                    if node.id in state.completed or node.id in state.active:
                        continue
                    if any(p not in state.completed for p in node.dependencies):
                        continue
                    state.ready_since.setdefault(node.id, t)
                    if t < state.backoff.get(node.id, 0):
                        continue
                    ready.append((rank(self.policy, job, node, t, path, served, shares), job, node))
            # One atomic simulation loop owns all resource reservations.
            for _, job, node in sorted(ready, key=lambda row: row[0]):
                state = jobs[job.id]
                r = node.resource
                if (state.status not in {"pending", "running"} or node.id in state.active
                        or len(active[r]) >= window[r] or local[r] < node.units
                        ):
                    continue
                local[r] -= node.units
                count = state.attempts.get(node.id, 0) + 1
                state.attempts[node.id] = count
                if external[r] < node.units:
                    events.append({"kind": "rate_limited", "job": job.id, "node": node.id,
                                   "resource": r, "time_ms": t, "retry_after_ms": s.retry_after_ms})
                    if self.policy in {"flowgate", "dag_feedback"}:
                        window[r] = max(1, window[r] // 2)
                        cooldown[r] = t + s.cooldown_ms
                        recovered[r] = 0
                        adaptive_rate[r] = max(.04, adaptive_rate[r] * .65)
                    if not node.retry_safe:
                        terminal(job, t, "unsafe_retry")
                    elif count > s.max_retries:
                        terminal(job, t, "retry_budget")
                    else:
                        # Stable, deterministic bounded jitter avoids lockstep retries.
                        digest = hashlib.sha256(f"{job.id}/{node.id}/{count}".encode()).digest()
                        jitter = digest[0] % 7
                        state.backoff[node.id] = t + max(s.retry_after_ms, 2 ** count * 5) + jitter
                    continue
                external[r] -= node.units
                state.status = "running"
                state.starts.setdefault(node.id, t)  # preserve first accepted start across retries
                state.active.add(node.id)
                served[job.tenant] += node.units
                digest = hashlib.sha256(
                    f"{s.fault_seed}/{job.id}/{node.id}/{count}".encode()
                ).digest()
                probe = int.from_bytes(digest[:4], "big") / (2 ** 32)
                outcome = "ok"
                if probe < s.fault_rate / 2:
                    outcome = "http_5xx"
                elif probe < s.fault_rate:
                    outcome = "lost_response"
                active[r].append((t + node.duration_ms, job.id, node.id, outcome))
                events.append({"kind": "dispatch", "job": job.id, "node": node.id,
                               "resource": r, "time_ms": t, "units": node.units})
        for job in trace.jobs:
            if jobs[job.id].status in {"pending", "running"}:
                terminal(job, horizon, "deadline")
        # Calls dispatched before a deadline cannot be cancelled retroactively.
        # Record post-horizon effects without changing the task's failed outcome.
        for resource, in_flight in active.items():
            for finish, job_id, node_id, outcome in in_flight:
                state = jobs[job_id]
                state.active.discard(node_id)
                if outcome == "ok":
                    state.finishes[node_id] = finish
                    state.completed.add(node_id)
                events.append({"kind": "late_finish" if outcome == "ok" else "late_unknown",
                               "job": job_id, "node": node_id, "resource": resource,
                               "time_ms": finish, "outcome": outcome})
        return RunResult(self.policy, jobs, events, served, max(horizon, 1), shares)
