"""Deterministic synthetic Agent DAGs. No real user or production trace data."""
import random
from .model import Job, Node, Trace


def generate(seed: int = 7, jobs: int = 60, pattern: str = "mixed",
             arrival: str = "steady", estimate_error: float = 0.0) -> Trace:
    if jobs < 1 or estimate_error < 0 or estimate_error > 0.9:
        raise ValueError("invalid jobs or estimation error")
    if pattern not in {"mixed", "chain", "fanout", "diamond"}:
        raise ValueError("unknown DAG pattern")
    if arrival not in {"steady", "burst"}:
        raise ValueError("unknown arrival pattern")
    rng = random.Random(seed)
    output: list[Job] = []
    t = 0
    kinds = ("chain", "fanout", "diamond")
    for i in range(jobs):
        t += int(rng.expovariate(1 / 11)) if arrival == "steady" else (60 if i % 20 == 0 else 0)
        kind = kinds[i % len(kinds)] if pattern == "mixed" else pattern
        tenant = ("interactive", "batch", "heavy")[i % 3]
        def new_node(name: str, resource: str, deps: tuple[str, ...]) -> Node:
            duration = rng.randint(5, 18) if resource == "tool" else rng.randint(9, 28)
            units = rng.randint(1, 3)
            estimated = max(1, round(duration * (1 + rng.uniform(-estimate_error, estimate_error))))
            return Node(name, resource, duration, units, deps,
                        retry_safe=(name != "write"), estimated_ms=estimated)
        head = new_node("read", "tool", ())
        if kind == "chain":
            nodes = (head, new_node("model", "llm", ("read",)), new_node("write", "tool", ("model",)))
        elif kind == "fanout":
            nodes = (head, new_node("left", "llm", ("read",)),
                     new_node("right", "llm", ("read",)),
                     new_node("write", "tool", ("left", "right")))
        else:
            nodes = (head, new_node("left", "llm", ("read",)),
                     new_node("right", "tool", ("read",)),
                     new_node("merge", "llm", ("left", "right")),
                     new_node("write", "tool", ("merge",)))
        # The deadline is assigned independently of scheduling policy.
        deadline = t + int(sum(n.duration_ms for n in nodes) * rng.uniform(1.7, 3.4))
        output.append(Job(f"job-{i:04d}", tenant, t, deadline, nodes,
                          priority=2 if tenant == "interactive" else 0))
    trace = Trace(tuple(output))
    trace.validate()
    return trace
