"""Run matched synthetic traces; results are not real-world performance claims."""
import argparse
import json
from pathlib import Path
from statistics import mean
from sim.engine import Settings, Simulator
from sim.policy import POLICIES
from sim.workload import generate
from .stats import paired_bootstrap_ci


def evaluate(seeds: int, jobs: int, pattern: str, arrival: str, error: float,
             fault_rate: float = 0.0, weights: dict[str, float] | None = None,
             save_events: bool = False) -> dict:
    if not 1 <= seeds <= 100 or not 1 <= jobs <= 2000:
        raise ValueError("seeds must be 1..100 and jobs 1..2000")
    runs = []
    event_rows: list[dict] = []
    for seed in range(seeds):
        trace = generate(seed=seed + 17, jobs=jobs, pattern=pattern,
                         arrival=arrival, estimate_error=error)
        for policy in POLICIES:
            result = Simulator(Settings(fault_rate=fault_rate, fault_seed=seed + 17,
                                        tenant_weights=weights or {}), policy).run(trace)
            row = result.summary()
            row["seed"] = seed + 17
            runs.append(row)
            if save_events:
                event_rows.append({"seed": seed + 17, "policy": policy, "events": result.events})
    aggregated = {}
    for policy in POLICIES:
        samples = [r for r in runs if r["policy"] == policy]
        aggregated[policy] = {
            "goodput_mean": round(mean(r["goodput_per_second"] for r in samples), 6),
            "completion_mean": round(mean(r["completion_ratio"] for r in samples), 6),
            "rate_429_mean": round(mean(r["rate_429"] for r in samples), 6),
            "worst_tenant_completion_mean": round(mean(r["worst_tenant_completion"] for r in samples), 6),
        }
    # Paired bootstrap: comparisons use identical trace seeds, not independent means.
    baseline = [r["goodput_per_second"] for r in runs if r["policy"] == "fcfs"]
    ci = {policy: paired_bootstrap_ci(
        [r["goodput_per_second"] for r in runs if r["policy"] == policy], baseline
    ) for policy in POLICIES if policy != "fcfs"}
    return {
        "provenance": "synthetic_discrete_event_simulation",
        "settings": {"seeds": seeds, "jobs": jobs, "pattern": pattern,
                     "arrival": arrival, "estimate_error": error,
                     "fault_rate": fault_rate, "tenant_weights": weights or {}},
        "note": "WFQ is a lightweight proxy, not a paper-faithful DRF reproduction.",
        "aggregated": aggregated, "runs": runs, "paired_goodput_delta_ci95_vs_fcfs": ci,
        "event_logs": event_rows if save_events else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="04 DAG-FlowGate synthetic evaluation")
    parser.add_argument("--jobs", type=int, default=60)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--pattern", choices=("mixed", "chain", "fanout", "diamond"), default="mixed")
    parser.add_argument("--arrival", choices=("steady", "burst"), default="steady")
    parser.add_argument("--estimate-error", type=float, default=0.2)
    parser.add_argument("--fault-rate", type=float, default=0.0)
    parser.add_argument("--tenant-weights", default="", help="example: interactive:2,batch:1,heavy:1")
    parser.add_argument("--save-events", action="store_true")
    parser.add_argument("--output", default="results/last_run.json")
    args = parser.parse_args()
    try:
        weights = dict((name.strip(), float(value)) for name, value in
                       (pair.split(":", 1) for pair in args.tenant_weights.split(",") if pair))
    except (ValueError, TypeError) as exc:
        parser.error(f"invalid --tenant-weights: {exc}")
    report = evaluate(args.seeds, args.jobs, args.pattern, args.arrival,
                      args.estimate_error, args.fault_rate, weights, args.save_events)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Synthetic {args.jobs} jobs × {args.seeds} seeds × {len(POLICIES)} policies")
    for policy, r in report["aggregated"].items():
        print(f"  {policy:14} goodput={r['goodput_mean']:7.3f}/s  completion={r['completion_mean']:.3f}  429={r['rate_429_mean']:.1f}")
    print(f"JSON: {output}")


if __name__ == "__main__":
    main()
