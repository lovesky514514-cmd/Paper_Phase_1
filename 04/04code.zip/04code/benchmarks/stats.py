"""Small paired bootstrap for early research; no claim of population coverage."""
import random
from statistics import mean


def paired_bootstrap_ci(values: list[float], baseline: list[float],
                        replicates: int = 1000, seed: int = 619) -> list[float] | None:
    if len(values) != len(baseline) or not values or replicates < 20:
        raise ValueError("paired arrays must have matching non-empty lengths")
    if len(values) < 2:
        return None
    differences = [a - b for a, b in zip(values, baseline)]
    rng = random.Random(seed)
    sampled = sorted(mean(differences[rng.randrange(len(differences))]
                          for _ in differences) for _ in range(replicates))
    return [round(sampled[int((replicates - 1) * .025)], 6),
            round(sampled[int((replicates - 1) * .975)], 6)]
