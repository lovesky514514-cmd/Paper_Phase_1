package gateway

import (
	"testing"
	"time"
)

func TestRejectCycle(t *testing.T) {
	w := Workflow{ID: "job", Tenant: "a", DeadlineMS: 1000, Nodes: []Node{
		{ID: "a", Resource: "tool", DurationMS: 1, Units: 1, Dependencies: []string{"b"}},
		{ID: "b", Resource: "tool", DurationMS: 1, Units: 1, Dependencies: []string{"a"}},
	}}
	if err := w.Validate(); err == nil {
		t.Fatal("cycle was accepted")
	}
}
func TestRejectOversizedDemand(t *testing.T) {
	w := Workflow{ID: "x", Tenant: "a", DeadlineMS: 1000, Nodes: []Node{{ID: "a", Resource: "tool", DurationMS: 3, Units: 10}}}
	if w.Validate() == nil {
		t.Fatal("oversized demand was accepted")
	}
}

func TestRejectURLShapedIdentifier(t *testing.T) {
	w := Workflow{ID: "../admin", Tenant: "a", DeadlineMS: 100, Nodes: []Node{{ID: "n", Resource: "tool", DurationMS: 1, Units: 1}}}
	if w.Validate() == nil {
		t.Fatal("unsafe workflow ID accepted")
	}
}

func TestRetryAfterSeconds(t *testing.T) {
	if got := retryAfterDuration("1"); got != time.Second {
		t.Fatalf("retry-after: %v", got)
	}
	if got := retryAfterDuration("unknown"); got != 20*time.Millisecond {
		t.Fatalf("fallback: %v", got)
	}
}

func TestRejectInvalidTenantWeight(t *testing.T) {
	s := NewScheduler("http://127.0.0.1:8944/mock")
	if err := s.SetTenantWeights(map[string]float64{"a": 0}); err == nil {
		t.Fatal("accepted zero weight")
	}
}
