package gateway

import (
	"errors"
	"fmt"
	"regexp"
)

// Node names a bounded synthetic operation. Parents must finish before dispatch.
type Node struct {
	ID           string   `json:"id"`
	Resource     string   `json:"resource"`
	DurationMS   int      `json:"duration_ms"`
	Units        int      `json:"units"`
	Dependencies []string `json:"dependencies,omitempty"`
	RetrySafe    bool     `json:"retry_safe"`
}

// Workflow is a DAG submitted as one atomic admission request.
type Workflow struct {
	ID         string `json:"id"`
	Tenant     string `json:"tenant"`
	DeadlineMS int    `json:"deadline_ms"`
	Nodes      []Node `json:"nodes"`
}

var safeID = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,80}$`)

func (w Workflow) Validate() error {
	if !safeID.MatchString(w.ID) || !safeID.MatchString(w.Tenant) || w.DeadlineMS < 1 || w.DeadlineMS > 120000 || len(w.Nodes) == 0 || len(w.Nodes) > 80 {
		return errors.New("invalid workflow ID, tenant, deadline, or node count")
	}
	nodes := make(map[string]Node, len(w.Nodes))
	for _, n := range w.Nodes {
		if !safeID.MatchString(n.ID) || n.Units < 1 || n.Units > 9 || n.DurationMS < 1 || n.DurationMS > 5000 || (n.Resource != "tool" && n.Resource != "llm") {
			return fmt.Errorf("invalid node %q", n.ID)
		}
		if _, exists := nodes[n.ID]; exists {
			return fmt.Errorf("duplicate node %q", n.ID)
		}
		nodes[n.ID] = n
	}
	visits := map[string]uint8{}
	var visit func(string) error
	visit = func(id string) error {
		if visits[id] == 1 {
			return errors.New("dependency cycle")
		}
		if visits[id] == 2 {
			return nil
		}
		n, ok := nodes[id]
		if !ok {
			return fmt.Errorf("missing parent %q", id)
		}
		visits[id] = 1
		parents := map[string]bool{}
		for _, dep := range n.Dependencies {
			if parents[dep] {
				return errors.New("duplicate dependency")
			}
			parents[dep] = true
			if err := visit(dep); err != nil {
				return err
			}
		}
		visits[id] = 2
		return nil
	}
	for id := range nodes {
		if err := visit(id); err != nil {
			return err
		}
	}
	return nil
}
