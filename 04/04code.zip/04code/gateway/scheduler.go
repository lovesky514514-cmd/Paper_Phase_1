package gateway

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Snapshot is a copy, never exposing mutable maps to HTTP handlers.
type Snapshot struct {
	ID        string         `json:"id"`
	Tenant    string         `json:"tenant"`
	Status    string         `json:"status"`
	Reason    string         `json:"reason,omitempty"`
	Completed []string       `json:"completed"`
	Started   []string       `json:"started"`
	Attempts  map[string]int `json:"attempts"`
}

type task struct {
	flow      Workflow
	created   time.Time
	status    string
	reason    string
	completed map[string]bool
	running   map[string]bool
	started   map[string]bool
	attempts  map[string]int
	after     map[string]time.Time
}

type quota struct {
	tokens          float64
	inFlight        int
	window          int
	successSince429 int
	cooldownUntil   time.Time
}

// Scheduler's mutex serializes admission, quota reservations, and job transitions.
// One Scheduler is only single-process safe; production replicas need shared atomic quotas.
type Scheduler struct {
	mu         sync.Mutex
	jobs       map[string]*task
	service    map[string]float64
	weights    map[string]float64
	resources  map[string]*quota
	lastRefill time.Time
	client     *http.Client
	mockURL    string
	closed     bool
}

func NewScheduler(mockURL string) *Scheduler {
	return &Scheduler{
		jobs: map[string]*task{}, service: map[string]float64{}, weights: map[string]float64{},
		resources:  map[string]*quota{"llm": {tokens: 9, window: 3}, "tool": {tokens: 9, window: 3}},
		lastRefill: time.Now(), client: &http.Client{Timeout: 8 * time.Second}, mockURL: mockURL,
	}
}

// SetTenantWeights configures positive normalized shares. Call before Start.
func (s *Scheduler) SetTenantWeights(weights map[string]float64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for tenant, weight := range weights {
		if tenant == "" || math.IsNaN(weight) || math.IsInf(weight, 0) || weight <= 0 || weight > 1000 {
			return fmt.Errorf("invalid tenant weight")
		}
	}
	s.weights = make(map[string]float64, len(weights))
	for tenant, weight := range weights {
		s.weights[tenant] = weight
	}
	return nil
}

func (s *Scheduler) Submit(flow Workflow) error {
	if err := flow.Validate(); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return fmt.Errorf("scheduler closed")
	}
	if _, exists := s.jobs[flow.ID]; exists {
		return fmt.Errorf("duplicate workflow ID")
	}
	s.jobs[flow.ID] = &task{flow: flow, created: time.Now(), status: "queued",
		completed: map[string]bool{}, running: map[string]bool{}, started: map[string]bool{},
		attempts: map[string]int{}, after: map[string]time.Time{}}
	s.service[flow.Tenant] += 0 // register tenant for weighted fair ordering
	return nil
}

func (s *Scheduler) Get(id string) (Snapshot, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	task, ok := s.jobs[id]
	if !ok {
		return Snapshot{}, false
	}
	completed := make([]string, 0, len(task.completed))
	for k := range task.completed {
		completed = append(completed, k)
	}
	sort.Strings(completed)
	started := make([]string, 0, len(task.started))
	for k := range task.started {
		started = append(started, k)
	}
	sort.Strings(started)
	attempts := make(map[string]int, len(task.attempts))
	for k, v := range task.attempts {
		attempts[k] = v
	}
	return Snapshot{ID: id, Tenant: task.flow.Tenant, Status: task.status, Reason: task.reason,
		Completed: completed, Started: started, Attempts: attempts}, true
}

type candidate struct {
	job   *task
	node  Node
	score float64
	slack time.Duration
}

// Start runs the scheduling loop until ctx is cancelled. In-flight calls finish naturally.
func (s *Scheduler) Start(ctx context.Context) {
	ticker := time.NewTicker(3 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			s.mu.Lock()
			s.closed = true
			s.mu.Unlock()
			return
		case now := <-ticker.C:
			s.tick(now)
		}
	}
}

func (s *Scheduler) tick(now time.Time) {
	s.mu.Lock()
	elapsed := now.Sub(s.lastRefill).Seconds() * 1000
	if elapsed < 0 {
		elapsed = 0
	}
	s.lastRefill = now
	for _, q := range s.resources {
		q.tokens = min(9, q.tokens+.34*elapsed)
	}
	candidates := make([]candidate, 0)
	for _, t := range s.jobs {
		if t.status == "done" || t.status == "failed" || t.status == "timeout" {
			continue
		}
		if now.Sub(t.created) >= time.Duration(t.flow.DeadlineMS)*time.Millisecond {
			t.status = "timeout"
			t.reason = "deadline"
			continue
		}
		for _, n := range t.flow.Nodes {
			if t.completed[n.ID] || t.running[n.ID] || now.Before(t.after[n.ID]) {
				continue
			}
			ready := true
			for _, parent := range n.Dependencies {
				if !t.completed[parent] {
					ready = false
					break
				}
			}
			if !ready {
				continue
			}
			remaining := longestSuffix(t.flow, n.ID, t.completed)
			slack := t.created.Add(time.Duration(t.flow.DeadlineMS)*time.Millisecond).Sub(now) - remaining
			candidates = append(candidates, candidate{job: t, node: n, score: s.service[t.flow.Tenant] / s.tenantWeight(t.flow.Tenant), slack: slack})
		}
	}
	sort.Slice(candidates, func(i, j int) bool {
		a, b := candidates[i], candidates[j]
		if a.score != b.score {
			return a.score < b.score
		}
		if a.slack != b.slack {
			return a.slack < b.slack
		}
		if a.job.flow.ID != b.job.flow.ID {
			return a.job.flow.ID < b.job.flow.ID
		}
		return a.node.ID < b.node.ID
	})
	for _, c := range candidates {
		t, n := c.job, c.node
		q := s.resources[n.Resource]
		if q.inFlight >= q.window || q.tokens < float64(n.Units) || now.Before(q.cooldownUntil) {
			continue
		}
		if t.status == "done" || t.status == "failed" || t.status == "timeout" {
			continue
		}
		q.tokens -= float64(n.Units)
		q.inFlight++
		t.running[n.ID] = true
		t.started[n.ID] = true
		t.attempts[n.ID]++
		t.status = "running"
		s.service[t.flow.Tenant] += float64(n.Units)
		go s.dispatch(t.flow.ID, n)
	}
	s.mu.Unlock()
}

// The longest suffix is a conservative (non-parallel) estimate for a ready node.
func longestSuffix(w Workflow, id string, completed map[string]bool) time.Duration {
	byID := map[string]Node{}
	children := map[string][]string{}
	for _, n := range w.Nodes {
		byID[n.ID] = n
		for _, p := range n.Dependencies {
			children[p] = append(children[p], n.ID)
		}
	}
	memo := map[string]time.Duration{}
	var visit func(string) time.Duration
	visit = func(k string) time.Duration {
		if completed[k] {
			return 0
		}
		if v, ok := memo[k]; ok {
			return v
		}
		var longest time.Duration
		for _, c := range children[k] {
			if val := visit(c); val > longest {
				longest = val
			}
		}
		memo[k] = time.Duration(byID[k].DurationMS)*time.Millisecond + longest
		return memo[k]
	}
	return visit(id)
}

func (s *Scheduler) tenantWeight(tenant string) float64 {
	if weight := s.weights[tenant]; weight > 0 {
		return weight
	}
	return 1
}

func retryAfterDuration(header string) time.Duration {
	header = strings.TrimSpace(header)
	if seconds, err := strconv.Atoi(header); err == nil && seconds >= 0 && seconds <= 5 {
		return time.Duration(seconds) * time.Second
	}
	if when, err := http.ParseTime(header); err == nil {
		delta := time.Until(when)
		if delta >= 0 && delta <= 5*time.Second {
			return delta
		}
	}
	return 20 * time.Millisecond
}

func (s *Scheduler) dispatch(jobID string, n Node) {
	body, _ := json.Marshal(map[string]any{"job": jobID, "node": n.ID, "resource": n.Resource,
		"duration_ms": n.DurationMS, "units": n.Units})
	req, err := http.NewRequest(http.MethodPost, s.mockURL, bytes.NewReader(body))
	status := 0
	retryAfter := 20 * time.Millisecond
	if err == nil {
		req.Header.Set("Content-Type", "application/json")
		resp, e := s.client.Do(req)
		if e == nil {
			status = resp.StatusCode
			retryAfter = retryAfterDuration(resp.Header.Get("Retry-After"))
			resp.Body.Close()
		}
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	t := s.jobs[jobID]
	q := s.resources[n.Resource]
	q.inFlight--
	delete(t.running, n.ID)
	if status == 429 {
		q.window = max(1, q.window/2)
		q.cooldownUntil = time.Now().Add(retryAfter)
		q.successSince429 = 0
		if t.status == "timeout" {
			return
		}
		// A mock 429 is an explicit pre-execution refusal. Unsafe writes stay stopped.
		if !n.RetrySafe {
			t.status = "failed"
			t.reason = "unsafe_retry"
			return
		}
		if t.attempts[n.ID] > 2 {
			t.status = "failed"
			t.reason = "retry_budget"
			return
		}
		t.after[n.ID] = time.Now().Add(time.Duration(1<<t.attempts[n.ID]) * max(retryAfter, 10*time.Millisecond))
		return
	}
	if status != 200 {
		// Timeout/500 can be ambiguous for non-idempotent tools. Never blind retry.
		if t.status != "timeout" {
			t.status = "failed"
			t.reason = "unverified_tool_result"
		}
		return
	}
	t.completed[n.ID] = true
	if t.status == "timeout" {
		return
	} // Already issued call may complete late.
	q.successSince429++
	if q.successSince429 >= 5 && q.window < 3 {
		q.window++
		q.successSince429 = 0
	}
	if len(t.completed) == len(t.flow.Nodes) {
		t.status = "done"
	}
}
