package gateway

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func sendFlow(t *testing.T, address string, w Workflow) int {
	t.Helper()
	data, err := json.Marshal(w)
	if err != nil {
		t.Fatal(err)
	}
	r, err := http.Post(address+"/workflows", "application/json", bytes.NewReader(data))
	if err != nil {
		t.Fatal(err)
	}
	defer r.Body.Close()
	return r.StatusCode
}

func awaitStatus(t *testing.T, s *Scheduler, id, expected string) Snapshot {
	t.Helper()
	until := time.Now().Add(1800 * time.Millisecond)
	for time.Now().Before(until) {
		snap, ok := s.Get(id)
		if ok && snap.Status == expected {
			return snap
		}
		if ok && (snap.Status == "failed" || snap.Status == "timeout" || snap.Status == "done") {
			t.Fatalf("unexpected terminal state %s: %s", snap.Status, snap.Reason)
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatalf("timeout waiting for %s", expected)
	return Snapshot{}
}

func TestHTTPWorkflowDependencyAndDuplicate(t *testing.T) {
	s := NewScheduler("")
	server := httptest.NewServer(Handler(s, 0))
	defer server.Close()
	s.mockURL = server.URL + "/mock"
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go s.Start(ctx)
	w := Workflow{ID: "a", Tenant: "tenant", DeadlineMS: 500, Nodes: []Node{
		{ID: "read", Resource: "tool", DurationMS: 10, Units: 1, RetrySafe: true},
		{ID: "write", Resource: "tool", DurationMS: 10, Units: 1, Dependencies: []string{"read"}, RetrySafe: false},
	}}
	if got := sendFlow(t, server.URL, w); got != 202 {
		t.Fatalf("submit %d", got)
	}
	if got := sendFlow(t, server.URL, w); got != 409 {
		t.Fatalf("duplicate %d", got)
	}
	snap := awaitStatus(t, s, "a", "done")
	if len(snap.Completed) != 2 || snap.Attempts["read"] != 1 || snap.Attempts["write"] != 1 {
		t.Fatalf("bad DAG completion: %+v", snap)
	}
}

func TestUnsafeWriteIsNeverRetriedOn429(t *testing.T) {
	s := NewScheduler("")
	server := httptest.NewServer(Handler(s, 1))
	defer server.Close()
	s.mockURL = server.URL + "/mock"
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go s.Start(ctx)
	w := Workflow{ID: "unsafe", Tenant: "t", DeadlineMS: 500, Nodes: []Node{{ID: "write", Resource: "tool", DurationMS: 4, Units: 1, RetrySafe: false}}}
	if got := sendFlow(t, server.URL, w); got != 202 {
		t.Fatalf("submit %d", got)
	}
	snap := awaitStatus(t, s, "unsafe", "failed")
	if snap.Reason != "unsafe_retry" || snap.Attempts["write"] != 1 {
		t.Fatalf("unexpected retries: %+v", snap)
	}
}
