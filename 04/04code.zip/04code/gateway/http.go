package gateway

import (
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"sync/atomic"
	"time"
)

// Handler deliberately exposes only a local synthetic tool, never an arbitrary proxy.
func Handler(s *Scheduler, mock429Every uint64) http.Handler {
	mux := http.NewServeMux()
	var mockCalls atomic.Uint64
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, _ *http.Request) {
		jsonReply(w, http.StatusOK, map[string]string{"status": "ok"})
	})
	mux.HandleFunc("POST /workflows", func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 256<<10)
		dec := json.NewDecoder(r.Body)
		dec.DisallowUnknownFields()
		var flow Workflow
		if err := dec.Decode(&flow); err != nil {
			http.Error(w, "invalid JSON", 400)
			return
		}
		var extra any
		if err := dec.Decode(&extra); err != io.EOF {
			http.Error(w, "unexpected trailing JSON", 400)
			return
		}
		if err := flow.Validate(); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		if err := s.Submit(flow); err != nil {
			http.Error(w, err.Error(), 409)
			return
		}
		jsonReply(w, http.StatusAccepted, map[string]string{"id": flow.ID, "status": "queued"})
	})
	mux.HandleFunc("GET /workflows/{id}", func(w http.ResponseWriter, r *http.Request) {
		id := strings.TrimSpace(r.PathValue("id"))
		snap, ok := s.Get(id)
		if !ok {
			http.Error(w, "not found", 404)
			return
		}
		jsonReply(w, http.StatusOK, snap)
	})
	mux.HandleFunc("POST /mock", func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 4096)
		var call struct {
			DurationMS int `json:"duration_ms"`
			Units      int `json:"units"`
		}
		if err := json.NewDecoder(r.Body).Decode(&call); err != nil || call.DurationMS < 1 || call.DurationMS > 5000 || call.Units < 1 || call.Units > 9 {
			http.Error(w, "invalid mock call", 400)
			return
		}
		if mock429Every > 0 && mockCalls.Add(1)%mock429Every == 0 {
			w.Header().Set("Retry-After", "1")
			http.Error(w, "synthetic 429", 429)
			return
		}
		time.Sleep(time.Duration(call.DurationMS) * time.Millisecond)
		jsonReply(w, 200, map[string]string{"status": "synthetic_ok"})
	})
	return mux
}

func jsonReply(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}
