// flowgate runs a strictly local research demonstrator. No live LLM or API keys.
package main

import (
	"context"
	"example.org/dagflowgate04/gateway"
	"flag"
	"log"
	"net"
	"net/http"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

func main() {
	addr := flag.String("listen", "127.0.0.1:8944", "local address")
	weights := flag.String("weights", "", "tenant shares: interactive:2,batch:1")
	inject := flag.Uint64("mock-429-every", 0, "synthetic HTTP 429 every N calls (0 disables)")
	flag.Parse()
	host, _, err := net.SplitHostPort(*addr)
	if err != nil || !(host == "localhost" || (net.ParseIP(host) != nil && net.ParseIP(host).IsLoopback())) {
		log.Fatal("--listen must use a loopback IP or localhost")
	}
	parsed := map[string]float64{}
	if *weights != "" {
		for _, entry := range strings.Split(*weights, ",") {
			parts := strings.Split(entry, ":")
			if len(parts) != 2 {
				log.Fatal("invalid --weights entry")
			}
			weight, parseErr := strconv.ParseFloat(parts[1], 64)
			if parseErr != nil {
				log.Fatal("invalid --weights value")
			}
			parsed[parts[0]] = weight
		}
	}
	// Bind the mock and gateway to the same loopback address, not an arbitrary target.
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	s := gateway.NewScheduler("http://" + *addr + "/mock")
	if err := s.SetTenantWeights(parsed); err != nil {
		log.Fatal(err)
	}
	srv := &http.Server{Addr: *addr, Handler: gateway.Handler(s, *inject), ReadHeaderTimeout: 3 * time.Second}
	go s.Start(ctx)
	go func() {
		<-ctx.Done()
		shut, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = srv.Shutdown(shut)
	}()
	log.Printf("DAG-FlowGate local gateway: http://%s/health", *addr)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}
