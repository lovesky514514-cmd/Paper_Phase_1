# 排错与修复

1. **命令找不到**：安装 Python 3.11+ 和 Go 1.22+；终端重新打开，运行 `python --version`、`go version`。
2. **`No module named sim`**：必须在解压后的 `04code` 根目录运行 `python -m benchmarks.run_eval`；不要进入 `benchmarks` 目录直接执行文件。
3. **端口 8944 被占用**：关闭上一次 Go 演示窗口，或终止占用端口的本地测试进程；演示客户端固定用 8944。
4. **实验任务大量失败**：先检查 `--fault-rate`、arrival、截止时间与远端配额下降；在本实验中它是预设负载失败，不意味着程序崩溃。
5. **429 多**：默认本地与远端配额存在故意不一致；换不同策略比较，不要在论文里删掉 429。
6. **Go 测试失败**：执行 `go test -race ./...`（Windows 竞态检测可能需要 C 工具链，通常使用 `go test ./...`）；查看用例名称与 `gateway/` 中同名文件。
7. **Windows 中文乱码**：脚本核心输出使用 ASCII；Markdown 按 UTF-8 保存并以 UTF-8 编辑器打开。
8. **不安全写入停止**：这是预设安全策略；只有外部工具有可靠幂等/执行前拒绝证据，才能明确标记 `retry_safe=true`。

详细到每份源码见 [DEBUG_INDEX.md](DEBUG_INDEX.md)。遇到严重缺陷，先写最小复现测试，再更改模块代码，最后执行 `scripts/check.sh` 或 `scripts/check_windows.bat`。
