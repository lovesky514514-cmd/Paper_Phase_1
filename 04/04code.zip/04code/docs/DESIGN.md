# 架构与实现边界

本包按 `04.md` 的两层想法分开：

1. **Python 仿真层**：`sim/model.py` 校验 DAG；`workload.py` 产生固定种子合成轨迹；`policy.py` 排序就绪节点；`engine.py` 原子扣本地令牌和并发槽、模拟远程服务配额、执行/重试/停止，并导出事件。`benchmarks/` 在相同工作负载上比较策略。
2. **Go 执行层**：`gateway/model.go` 检查提交；`scheduler.go` 在同一 mutex 内预约本地令牌/并发、维护完成依赖和租户份额；`http.go` 只与本地合成 Mock 交互。`cmd/flowgate` 暴露 HTTP。

两边**没有共享业务内存**，Python 用于实验控制，Go 用于验证真正并发 HTTP 请求可运行；Go 不是 Python 离散事件求解的逐行移植。

## 核心约束

- DAG 不可有循环、自依赖、缺失前驱或重复节点。
- 前驱未完成时不调度下游。HTTP 200 也不等于真实业务成功：这里的成功只针对 Mock 的预先定义状态。
- 同一实例内，令牌和并发槽的占用在互斥区完成。**多实例或真实外部配额不在此保证之内。**
- 429 对安全可重试节点实行有限退避，对不能确认重试安全的写入停止。超时/5xx 的副作用可能已发生，不能假设可撤销。
- 超出 deadline 的已发出调用无法被普遍取消：计入失败，同时保留完成事件；不再发起后续节点。
- Go 仅监听回环地址，不提供任意远端代理；不处理真实密钥或真实客户数据。

## HTTP 示例

```bash
go run ./cmd/flowgate --listen 127.0.0.1:8944 --weights interactive:2,batch:1
python3 scripts/demo.py
```

`POST /workflows` 接受 JSON `{id,tenant,deadline_ms,nodes:[{id,resource,duration_ms,units,dependencies,retry_safe}]}`；`GET /workflows/{id}` 查询状态；`GET /health` 健康检查。资源仅 `llm` 或 `tool`，操作均为合成请求。

## 后续替换接口

真实网关需要把 Mock 替换为**身份明确的后端适配器**，再加持久化执行账本、跨副本分布式配额、真实服务回读、流式追踪和超时歧义处理；替换前不能用于真实不可逆工具链。
