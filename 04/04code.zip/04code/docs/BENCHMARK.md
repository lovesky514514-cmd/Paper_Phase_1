# 合成实验协议

## 运行

```bash
python3 -m benchmarks.run_eval --jobs 60 --seeds 10 --pattern mixed --arrival steady --estimate-error 0.2
python3 -m benchmarks.run_eval --jobs 60 --seeds 10 --arrival burst --fault-rate 0.15 --tenant-weights interactive:2,batch:1,heavy:1 --save-events
```

九组：`fcfs`、`edf`、`srpt`、`wfq`（资源公平**近似代理，不是严格 DRF**）、`critical`、`static`、`dag_fair`（无反馈消融）、`dag_feedback`（无公平消融）、`flowgate`。这些是本地算法实现，不是任何具体论文的忠实复现。`critical` 表示 DAG 关键路径优先。

**固定条件**：每一组使用完全相同的生成 DAG、租户、到达、截止时间、初始配额与随机故障函数；观测窗口固定到轨迹最大截止时间。每个独立种子都分别评估九组策略。

**故障**：本地名义令牌率与模拟远端真实配额存在偏差；固定时刻远端配额下降；`--fault-rate` 对已接受的请求独立注入 5xx / 返回丢失的合成异常。对不安全写入不盲目重试。模型估计值可扰动，但各策略只能使用估计值。

**结果**：`results/last_run.json` 含每策略/每种子的原始摘要、均值、相对 FCFS 的配对 bootstrap 95% 区间；需要逐事件日志时加 `--save-events`。运行 1–3 个种子适合烟测，严肃比较至少先运行 10 个种子；应另作多负载预注册、效应量与真实部署交叉验证。

**不能滥用指标**：`p95_ms` 仅统计成功任务并另报 `p95_all_jobs_ms`（包含失败与超时）；公平指数以提供服务的归一化权重计算，并不是“每个租户按时成功率”的替代物。`units` 是合成配额，不是生产 Token 实测。Go 演示里 `/mock` 模拟服务时延，并非真实模型推理延迟。

## 尚缺实验

- Autellix / Kairos / 真实 DRF 或其他强基线的可信复现。
- Poisson 之外的生产 trace、真实多租户 quotas、外部服务容量协作。
- 至少一轮真实 Agent/LLM 和外部 HTTP 工具业务状态验证。
- 多副本 Redis 原子限额、P95/P99 实测 CPU/内存和吞吐压测。

对照不能把本地近似基线冒充已复现相关论文。
