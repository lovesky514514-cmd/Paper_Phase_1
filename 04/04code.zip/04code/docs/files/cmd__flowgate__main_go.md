# 排错：`cmd/flowgate/main.go`

**职责**：Go executable and local-only address validation。

**常见问题**：Port in use or server will not start。

**快速检查**：

```text
go run ./cmd/flowgate
```

**修复方法**：Use 127.0.0.1 and port 8944; stop prior instance; verify Go installed.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
