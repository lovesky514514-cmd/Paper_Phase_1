# 排错：`.gitignore`

**职责**：Ignore caches, build outputs and ephemeral reports。

**常见问题**：Dirty repository or missing generated report。

**快速检查**：

```text
git status --short
```

**修复方法**：Confirm results/sample_run.json remains versioned and caches excluded.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
