# 排错：`gateway/scheduler.go`

**职责**：Go single-process fair dispatcher, atomic reservations and retry gate。

**常见问题**：A workflow stays queued, returns timeout, or races under load。

**快速检查**：

```text
go test -race ./gateway -v
```

**修复方法**：Inspect slots, token refill, deadline, cooldown and parent completion; reproduce race.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
