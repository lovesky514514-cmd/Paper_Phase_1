# 排错：`scripts/start.sh`

**职责**：Linux/macOS ephemeral build, start and cleanup。

**常见问题**：Go compiler missing or background process remains。

**快速检查**：

```text
sh scripts/start.sh
```

**修复方法**：Inspect temporary binary permissions and child PID; verify listening port.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
