# 排错：`scripts/check.sh`

**职责**：Linux/macOS reproducible test entrypoint。

**常见问题**：One of Python/Go/race/vet checks fails。

**快速检查**：

```text
sh scripts/check.sh
```

**修复方法**：Run the failing listed command alone, fix its root cause, rerun all.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
