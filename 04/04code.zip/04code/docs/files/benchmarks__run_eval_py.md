# 排错：`benchmarks/run_eval.py`

**职责**：Matched-seed policy comparison CLI and JSON output。

**常见问题**：Import errors, invalid CLI weights or misleading means。

**快速检查**：

```text
python -m benchmarks.run_eval --jobs 12 --seeds 2
```

**修复方法**：Run from 04code root; preserve seeds and failure rows for fair comparison.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
