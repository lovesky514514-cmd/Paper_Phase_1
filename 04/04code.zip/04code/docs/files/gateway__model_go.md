# 排错：`gateway/model.go`

**职责**：Go HTTP workflow model and cycle/resource checks。

**常见问题**：400 due to an invalid node or non-loopback ID。

**快速检查**：

```text
go test ./gateway -run "TestReject" -v
```

**修复方法**：Align JSON fields and DAG IDs; reject invalid input rather than repairing it silently.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
