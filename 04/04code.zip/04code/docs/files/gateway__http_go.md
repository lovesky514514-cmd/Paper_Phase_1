# 排错：`gateway/http.go`

**职责**：Bounded local HTTP surface and synthetic tool handler。

**常见问题**：404/400/429 from local mock。

**快速检查**：

```text
go test ./gateway -run TestHTTP -v
```

**修复方法**：Confirm method/path/body shape and 429 injection; never add an open proxy.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
