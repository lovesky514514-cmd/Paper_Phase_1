# 排错：`sim/model.py`

**职责**：DAG input schema and graph validation。

**常见问题**：Duplicate IDs, missing parents or a cycle rejected。

**快速检查**：

```text
python -m unittest discover -s tests -k TraceContractTest
```

**修复方法**：Check immutable Node/Job fields and dependency names; add failing DAG case.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
