# 排错：`sim/policy.py`

**职责**：Ready-node ordering and estimated critical paths。

**常见问题**：Unexpected deadline preference or fairness starvation。

**快速检查**：

```text
python -m benchmarks.run_eval --jobs 20 --seeds 2
```

**修复方法**：Check rank tuple ordering and all estimator inputs; compare on same trace.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
