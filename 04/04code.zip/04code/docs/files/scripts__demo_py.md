# 排错：`scripts/demo.py`

**职责**：Stdlib HTTP client for the Go live demonstration。

**常见问题**：Connection refused, HTTP 409, or demo terminal timeout。

**快速检查**：

```text
python scripts/demo.py --wait
```

**修复方法**：Start server first; ensure each request has a fresh ID; read GET status.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
