# 排错：`tests/test_sim.py`

**职责**：Project file used by this research prototype。

**常见问题**：The file is missing or does not match the README。

**快速检查**：

```text
sh scripts/check.sh
```

**修复方法**：Restore the versioned file and rerun self-check.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
