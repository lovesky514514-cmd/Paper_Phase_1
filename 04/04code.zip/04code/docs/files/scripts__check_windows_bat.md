# 排错：`scripts/check_windows.bat`

**职责**：Windows one-click Go/Python self-check。

**常见问题**：PATH or tests fail。

**快速检查**：

```text
scripts\check_windows.bat
```

**修复方法**：Run cmd from project root, check Go/Python versions and failing test.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
