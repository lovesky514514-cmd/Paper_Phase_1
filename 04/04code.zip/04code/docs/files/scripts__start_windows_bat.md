# 排错：`scripts/start_windows.bat`

**职责**：Windows one-click local server and demo。

**常见问题**：Window closes immediately or py/go not found。

**快速检查**：

```text
scripts\start_windows.bat
```

**修复方法**：Run from terminal to see logs, verify PATH and close duplicate servers.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
