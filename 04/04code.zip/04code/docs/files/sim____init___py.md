# 排错：`sim/__init__.py`

**职责**：Declare an importable Python package。

**常见问题**：ModuleNotFoundError or unexpected import path。

**快速检查**：

```text
python -m unittest discover -s tests -q
```

**修复方法**：Run from project root, keep package __init__.py, never import by changing sys.path dynamically.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
