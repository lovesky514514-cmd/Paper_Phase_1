# 排错：`sim/engine.py`

**职责**：Discrete-event resource reservations, execution and recovery。

**常见问题**：Capacity oversubscription, retry amplification or completion drift。

**快速检查**：

```text
python -m unittest discover -s tests -k LifecycleTest
```

**修复方法**：Reproduce on one fixed seed; inspect dispatch/finish timestamps before changing reservation.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
