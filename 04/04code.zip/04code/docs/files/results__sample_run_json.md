# 排错：`results/sample_run.json`

**职责**：随包提供的一次合成实验样例，不是生产指标或论文证明。

**常见问题**：与最新源码实验结果不同，或 JSON 无法读取。

**检查**：在根目录运行 `python -m json.tool results/sample_run.json`。

**修复**：执行 `python -m benchmarks.run_eval --jobs 60 --seeds 3 --output results/sample_run.json` 重建，同步更新 `docs/QUALITY.md` 里对应的示例数据。不要手工篡改原始结果。
