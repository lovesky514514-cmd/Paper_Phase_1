# 排错：`go.mod`

**职责**：Go module name and minimum language version。

**常见问题**：Go dependency/module error。

**快速检查**：

```text
go env GOMOD && go test ./...
```

**修复方法**：Keep Go 1.22+, do not add remote dependencies without need.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
