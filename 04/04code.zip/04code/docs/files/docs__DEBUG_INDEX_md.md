# 排错：`docs/DEBUG_INDEX.md`

**职责**：Research context and documentation; not executable program code。

**常见问题**：Terminology, examples or claims do not match the shipped implementation。

**快速检查**：

```text
Open this file and compare the referenced executable command with README.md
```

**修复方法**：Confirm against executable code and test output, then update the document; preserve original research source unchanged.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
