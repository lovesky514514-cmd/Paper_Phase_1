# 排错：`sim/workload.py`

**职责**：Seeded synthetic DAG and arrival generator。

**常见问题**：A generator produces an invalid DAG or inconsistent seeds。

**快速检查**：

```text
python -m unittest discover -s tests -k LifecycleTest
```

**修复方法**：Confirm seed/pattern/arrival/error and run Trace.validate before benchmarking.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
