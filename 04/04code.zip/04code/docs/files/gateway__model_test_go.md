# 排错：`gateway/model_test.go`

**职责**：Unit tests for workflow contracts。

**常见问题**：Validation regression。

**快速检查**：

```text
go test ./gateway -run TestReject -v
```

**修复方法**：Compare rejected fields to a known-good workflow fixture.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
