# 排错：`benchmarks/stats.py`

**职责**：Paired bootstrap CI for Goodput deltas。

**常见问题**：Nonmatching policy arrays or intervals suspiciously precise。

**快速检查**：

```text
python -m unittest discover -s tests -k ExperimentTest
```

**修复方法**：Pair rows by seed; increase replicates/seeds, never treat few-seed CI as final evidence.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
