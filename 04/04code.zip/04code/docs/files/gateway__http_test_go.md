# 排错：`gateway/http_test.go`

**职责**：HTTP lifecycle and unsafe retry tests。

**常见问题**：Flaky HTTP lifecycle or retry counter mismatch。

**快速检查**：

```text
go test -race ./gateway -run TestHTTP -count=5
```

**修复方法**：Shorten to one DAG, verify mock server and cleanup, then check locks.

**回归确认**：从仓库根目录执行 `scripts/check_windows.bat`（Windows）或 `sh scripts/check.sh`（Linux/macOS）。不要直接修改生成的运行结果来隐藏失败。
