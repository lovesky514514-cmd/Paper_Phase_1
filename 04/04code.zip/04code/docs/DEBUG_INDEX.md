# 逐文件排错索引

`docs/files/` 下面按相对路径命名，每个代码/脚本/说明文件一页，覆盖：用途、常见故障、排查命令、修复路线。通用诊断见 [troubleshooting.md](troubleshooting.md)。

注意：生成型 `docs/files/*.md` 自身是排错索引的内容，不再为索引页递归生成帮助页；结果 JSON 和 `__pycache__` 属于运行产物，不是源码文件。

## 文件索引

- [`.gitignore`](files/_gitignore.md)
- [`GLOSSARY.md`](files/GLOSSARY_md.md)
- [`README.md`](files/README_md.md)
- [`benchmarks/__init__.py`](files/benchmarks____init___py.md)
- [`benchmarks/run_eval.py`](files/benchmarks__run_eval_py.md)
- [`benchmarks/stats.py`](files/benchmarks__stats_py.md)
- [`cmd/flowgate/main.go`](files/cmd__flowgate__main_go.md)
- [`docs/BENCHMARK.md`](files/docs__BENCHMARK_md.md)
- [`docs/CODE_STANDARDS.md`](files/docs__CODE_STANDARDS_md.md)
- [`docs/DEBUG_INDEX.md`](files/docs__DEBUG_INDEX_md.md)
- [`docs/DESIGN.md`](files/docs__DESIGN_md.md)
- [`docs/QUALITY.md`](files/docs__QUALITY_md.md)
- [`docs/troubleshooting.md`](files/docs__troubleshooting_md.md)
- [`gateway/http.go`](files/gateway__http_go.md)
- [`gateway/http_test.go`](files/gateway__http_test_go.md)
- [`gateway/model.go`](files/gateway__model_go.md)
- [`gateway/model_test.go`](files/gateway__model_test_go.md)
- [`gateway/scheduler.go`](files/gateway__scheduler_go.md)
- [`go.mod`](files/go_mod.md)
- [`research/04_original.md`](files/research__04_original_md.md)
- [`scripts/check.sh`](files/scripts__check_sh.md)
- [`scripts/check_windows.bat`](files/scripts__check_windows_bat.md)
- [`scripts/demo.py`](files/scripts__demo_py.md)
- [`scripts/start.sh`](files/scripts__start_sh.md)
- [`scripts/start_windows.bat`](files/scripts__start_windows_bat.md)
- [`sim/__init__.py`](files/sim____init___py.md)
- [`sim/engine.py`](files/sim__engine_py.md)
- [`sim/model.py`](files/sim__model_py.md)
- [`sim/policy.py`](files/sim__policy_py.md)
- [`sim/workload.py`](files/sim__workload_py.md)
- [`tests/test_sim.py`](files/tests__test_sim_py.md)
- [`results/sample_run.json`](files/results__sample_run_json.md)
