# 代码约定

参考用户提供的 Skill：`codebase-design`、`domain-modeling`、`tdd`、`code-review`。只保留能解释模块职责的抽象，避免为未来可能存在的功能叠加空接口。

- Python 负责可重复实验和统计；Go 负责真实 HTTP 分发与原子单进程资源预约。
- 用明确名词 `Workflow / Node / quota / ready / retry_safe`，拒绝“万能 Manager”。
- 函数先说明安全前提，再编写操作；不要记录敏感 HTTP 负载。
- 在输入边界校验 DAG、时限、节点配额；绝不把异常当成成功。
- 测试通过公开接口检验行为；严重缺陷先建失败复现再修复。
- 无需包外第三方依赖；实验产物必须带种子、参数与来源标签。
