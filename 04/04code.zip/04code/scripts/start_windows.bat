@echo off
setlocal
cd /d "%~dp0.."
where go >nul 2>&1 || (echo [ERROR] Install Go 1.22+ & pause & exit /b 1)
where py >nul 2>&1
if %errorlevel%==0 (set "PYCMD=py -3") else (set "PYCMD=python")
start "DAG-FlowGate local server" cmd /k "go run ./cmd/flowgate"
%PYCMD% scripts\demo.py --wait
if errorlevel 1 (echo [FAIL] See docs\troubleshooting.md) else (echo [PASS] Server demo finished.)
pause
