@echo off
setlocal
cd /d "%~dp0.."
where go >nul 2>&1 || (echo [ERROR] Install Go 1.22+ & pause & exit /b 1)
where py >nul 2>&1
if %errorlevel%==0 (set "PYCMD=py -3") else (set "PYCMD=python")
%PYCMD% --version || (echo [ERROR] Install Python 3.11+ & pause & exit /b 1)
go test ./... || goto fail
go vet ./... || goto fail
%PYCMD% -m unittest discover -s tests -v || goto fail
%PYCMD% -m benchmarks.run_eval --jobs 12 --seeds 2 --output results/check.json || goto fail
echo [PASS] Self-check complete.
pause
exit /b 0
:fail
echo [FAIL] Please see docsiles and docs	roubleshooting.md
pause
exit /b 1
