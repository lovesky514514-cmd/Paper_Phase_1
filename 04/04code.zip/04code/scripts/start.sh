#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
workdir="$(mktemp -d)"
server_pid=""
cleanup() {
  if [ -n "$server_pid" ]; then
    kill "$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
  fi
  rm -rf "$workdir"
}
trap cleanup EXIT INT TERM
go build -o "$workdir/flowgate" ./cmd/flowgate
"$workdir/flowgate" &
server_pid=$!
python3 scripts/demo.py --wait
printf '本地网关演示通过，进程已停止。\n'
