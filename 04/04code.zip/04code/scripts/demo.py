"""A small client proving the Go dispatcher executes an actual HTTP DAG."""
import argparse
import json
import time
import uuid
from urllib import request, error

BASE = "http://127.0.0.1:8944"


def fetch(method: str, path: str, payload: dict | None = None) -> dict:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = request.Request(BASE + path, data=data, method=method,
                          headers={"Content-Type": "application/json"})
    with request.urlopen(req, timeout=4) as reply:
        return json.load(reply)


def main() -> None:
    parser = argparse.ArgumentParser(description="Go HTTP scheduler smoke test")
    parser.add_argument("--wait", action="store_true", help="wait for local server to start")
    args = parser.parse_args()
    for attempt in range(60 if args.wait else 1):
        try:
            fetch("GET", "/health")
            break
        except (OSError, error.HTTPError):
            if attempt == (59 if args.wait else 0):
                raise SystemExit("无法连接网关；先执行 go run ./cmd/flowgate")
            time.sleep(.1)
    job_id = "demo-" + uuid.uuid4().hex[:10]
    payload = {
        "id": job_id, "tenant": "interactive", "deadline_ms": 3000,
        "nodes": [
            {"id": "read", "resource": "tool", "duration_ms": 15,
             "units": 1, "retry_safe": True},
            {"id": "reason", "resource": "llm", "duration_ms": 25,
             "units": 2, "dependencies": ["read"], "retry_safe": True},
            {"id": "write", "resource": "tool", "duration_ms": 15,
             "units": 1, "dependencies": ["reason"], "retry_safe": False},
        ],
    }
    print("Submit:", fetch("POST", "/workflows", payload))
    for _ in range(300):
        state = fetch("GET", "/workflows/" + job_id)
        if state["status"] in {"done", "failed", "timeout"}:
            print("Result:", json.dumps(state, ensure_ascii=False))
            if state["status"] != "done" or state["completed"] != ["read", "reason", "write"]:
                raise SystemExit("demo did not complete successfully")
            print("PASS: Go HTTP DAG completed")
            return
        time.sleep(.02)
    raise SystemExit("workflow did not finish before client timeout")


if __name__ == "__main__":
    main()
