#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 -m compileall -q sim benchmarks scripts tests
go test -race ./...
go vet ./...
python3 -m unittest discover -s tests -v
python3 -m benchmarks.run_eval --jobs 12 --seeds 2 --output results/check.json
printf '\n自检完成：Python、Go、合成实验均已执行。\n'
