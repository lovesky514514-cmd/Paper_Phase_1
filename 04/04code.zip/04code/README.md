# 04code · DAG-FlowGate

多 Agent 工作流的**依赖感知调度 + 多租户公平 + 429 拥塞反馈**科研原型，取自 `research/04_original.md`。全部数据为合成数据。

**安装：Python 3.11+、Go 1.22+。无 pip、Redis、GPU 或 API Key 依赖。**

| 操作 | Windows | Linux / macOS |
|---|---|---|
| 一键自检 | `scripts\check_windows.bat` | `sh scripts/check.sh` |
| 本地 HTTP 演示 | `scripts\start_windows.bat` | `sh scripts/start.sh` |
| 合成实验 | `py -3 -m benchmarks.run_eval --seeds 10` | `python3 -m benchmarks.run_eval --seeds 10` |

**在解压后的 `04code` 根目录运行。** Windows 演示会打开一个本地服务窗口，用完关闭该窗口。Linux 演示退出自动停服。

- `sim/`：Python 离散事件模拟器、DAG、调度策略、资源与故障模型。
- `benchmarks/`：9 组策略的固定种子对照，输出 `results/last_run.json`。
- `gateway/` + `cmd/`：Go 单进程 HTTP 调度器与本地 Mock 工具。端口 `127.0.0.1:8944`。
- `tests/`：Python 行为测试；Go 测试在 `gateway/`。

主要指标包括：工作流按时完成率、Goodput、P50/P95/P99、429、重试放大、加权 Jain 公平指数、最差租户完成率和轮候时间。

**限制：** 这是本地科研骨架；Go 和 Python 是两条独立的验证路径，算法细节不完全一致。尚无 Redis 跨副本配额、真实 Agent/LLM 负载、忠实的 Autellix/Kairos/DRF 复现，也不能据此宣称 SCI 创新已被证明。Go 演示不接受外部工具地址。

遇到问题先看 [排错指南](docs/troubleshooting.md) 和 [逐文件排错](docs/DEBUG_INDEX.md)。科研口径见 [实验协议](docs/BENCHMARK.md)、[架构](docs/DESIGN.md)、[自检报告](docs/QUALITY.md)。
