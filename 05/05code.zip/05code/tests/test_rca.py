"""End-user observable behaviors, with fixed oracle examples."""

import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from benchmarks.metrics import ece, paired_bootstrap_ci, summarize
from benchmarks.run_eval import POLICIES, run, run_policy
from benchmarks.workload import TEMPLATES, make_case, make_dataset
from tracelite import collect, diagnose, fit_temperature, rank
from tracelite.io import load_spans, save_spans, split_traces
from tracelite.model import TraceCase
from tracelite.observe import detail_size


class TraceLiteTests(unittest.TestCase):
    def setUp(self):
        self.case = make_case('stale_cache', 42)

    def test_workflow_oracle_excluded_from_gateway_observation(self):
        view = collect(self.case, 500, seed=3)
        self.assertEqual(view.spans[0].validation, {})
        self.assertTrue(all('first_irrecoverable' not in vars(s) for s in view.spans))
        self.assertEqual(self.case.first_irrecoverable, 'fetch')

    def test_all_fault_templates_produce_a_labeled_failure(self):
        for name in TEMPLATES[:-1]:
            with self.subTest(template=name):
                self.assertIn(make_case(name, 0).first_irrecoverable,
                              [s.span_id for s in make_case(name, 0).spans])

    def test_recoverable_error_is_not_falsely_used_as_oracle(self):
        example = make_case('permission', 5)
        self.assertEqual(example.injected_at, ('fetch', 'commit'))
        self.assertEqual(example.first_irrecoverable, 'commit')
        self.assertEqual(example.spans[0].status_code, 429)

    def test_verified_source_outweighs_terminal_symptom_with_full_evidence(self):
        case = make_case('stale_cache', 42)
        candidates = rank(collect(case, 2000, missing_fraction=0))
        self.assertEqual(candidates[0].span_id, 'fetch')

    def test_healthy_template_has_no_oracle_failure(self):
        self.assertIsNone(make_case('healthy', 1).first_irrecoverable)

    def test_collection_budget_is_never_exceeded(self):
        for budget in (0, 20, 160, 200, 350, 10000):
            for method in ('adaptive', 'uniform', 'random', 'full', 'none'):
                with self.subTest(budget=budget, method=method):
                    obs = collect(self.case, budget, policy=method)
                    self.assertLessEqual(obs.used_bytes, budget)
                    self.assertEqual(obs.used_bytes, sum(e.byte_cost for e in obs.evidence))

    def test_no_budget_does_not_show_validation(self):
        obs = collect(self.case, 0)
        self.assertEqual(obs.evidence, ())
        self.assertTrue(all(not span.validation for span in obs.spans))

    def test_100_percent_missing_requires_abstention(self):
        obs = collect(self.case, 300, missing_fraction=1)
        outcome = diagnose(obs, self.case.trace_id)
        self.assertTrue(outcome.abstained)
        self.assertEqual(len(outcome.missing_span_ids), len(self.case.spans))
        self.assertIsNone(outcome.selected)

    def test_zero_visible_spans_do_not_crash(self):
        self.assertEqual(rank(collect(self.case, 0, missing_fraction=1)), ())

    def test_high_threshold_abstains_and_explains(self):
        outcome = diagnose(collect(self.case, 160), self.case.trace_id, threshold=.99)
        self.assertTrue(outcome.abstained)
        self.assertTrue(outcome.next_check)

    def test_force_answer_is_explicitly_an_ablation(self):
        outcome = diagnose(collect(self.case, 160), self.case.trace_id,
                           threshold=.99, allow_abstain=False)
        self.assertIsNotNone(outcome.selected)

    def test_graph_toggle_maintains_valid_probabilities(self):
        for option in (True, False):
            scores = rank(collect(self.case, 480), use_graph=option)
            self.assertAlmostEqual(sum(c.confidence for c in scores), 1, places=7)

    def test_adaptive_selection_does_not_inspect_hidden_validation(self):
        case2 = replace(self.case, spans=tuple(replace(s, validation={'altered':'fail'})
                                                    for s in self.case.spans))
        left = collect(self.case, 320, seed=4)
        right = collect(case2, 320, seed=4)
        self.assertEqual([e.span_id for e in left.evidence], [e.span_id for e in right.evidence])

    def test_adaptive_uses_no_oracle_labels(self):
        changed = replace(self.case, first_irrecoverable='notify', intervention_roots=('notify',))
        a = collect(self.case, 320)
        b = collect(changed, 320)
        self.assertEqual([e.span_id for e in a.evidence], [e.span_id for e in b.evidence])

    def test_sampling_seed_reproducible(self):
        self.assertEqual(collect(self.case, 320, seed=21, missing_fraction=.2),
                         collect(self.case, 320, seed=21, missing_fraction=.2))

    def test_invalid_input_does_not_execute(self):
        with self.assertRaises(ValueError):
            collect(self.case, -1)
        with self.assertRaises(ValueError):
            collect(self.case, 160, missing_fraction=1.01)
        with self.assertRaises(ValueError):
            rank(collect(self.case, 160), temperature=0)

    def test_jsonl_roundtrip_preserves_privacy_mask(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'spans.jsonl'
            save_spans(path, self.case.spans)
            self.assertEqual(load_spans(path), self.case.spans)
            grouped = split_traces(load_spans(path))
            self.assertIsNone(grouped[self.case.trace_id].first_irrecoverable)

    def test_bad_jsonl_is_identified_with_line_number(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'broken.jsonl'
            path.write_text('{not json}\n', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'line 1'):
                load_spans(path)

    def test_validation_temperature_uses_no_test_labels(self):
        pairs = [(collect(self.case, 320), 'fetch')]
        self.assertIn(fit_temperature(pairs), (.4, .7, 1., 1.5, 2., 3., 5., 8.))

    def test_every_policy_reports_workflow_metric(self):
        dataset = make_dataset(2, 2, ('permission', 'healthy'))
        for p in POLICIES:
            with self.subTest(policy=p):
                self.assertEqual(len(run_policy(dataset, p, 160, 0, 1, 2)), len(dataset))

    def test_benchmark_repeats_same_accuracy_on_same_seed(self):
        a = run(3, 3, 160, .2)
        b = run(3, 3, 160, .2)
        # Measured wall-clock latency is inherently variable across runs.
        metric_keys = ('top1_all', 'top3', 'coverage', 'answered_accuracy',
                       'mean_evidence_bytes', 'ece_top1', 'brier_top1')
        for policy in POLICIES:
            for metric in metric_keys:
                self.assertEqual(a['summary'][policy][metric], b['summary'][policy][metric])
        self.assertEqual(a['paired_top1_ci_adaptive_minus_uniform'],
                         b['paired_top1_ci_adaptive_minus_uniform'])

    def test_no_fake_external_baselines(self):
        self.assertFalse(any('AgentRx' in name or 'CORRECT' in name for name in POLICIES))

    def test_paired_ci_uses_shared_trace_ids(self):
        a = [{'trace_id': 't1', 'truth': 'a', 'top1': 'a'}]
        b = [{'trace_id': 't1', 'truth': 'a', 'top1': 'b'}]
        self.assertEqual(paired_bootstrap_ci(a, b), (1., 1.))

    def test_ece_zero_for_perfect_confidence(self):
        self.assertEqual(ece([(1., True), (0., False)]), 0.)


if __name__ == '__main__':
    unittest.main()
