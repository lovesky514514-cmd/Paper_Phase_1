"""Transparent metrics; one workflow contributes at most one independent sample."""

import random
from statistics import mean


def percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.
    values = sorted(values)
    return values[round((len(values) - 1) * q)]


def ece(samples: list[tuple[float, bool]], bins: int = 5) -> float:
    if not samples:
        return 0.
    total = 0.
    for bucket in range(bins):
        lo, hi = bucket / bins, (bucket + 1) / bins
        subset = [(p, ok) for p, ok in samples if lo <= p <= hi if (p < hi or bucket == bins-1)]
        if subset:
            total += len(subset) / len(samples) * abs(mean(p for p, _ in subset) - mean(float(ok) for _, ok in subset))
    return total


def summarize(records: list[dict]) -> dict:
    if not records:
        return {}
    eligible = [r for r in records if r['truth'] is not None]
    answered = [r for r in eligible if r['prediction'] is not None]
    cals = [(r['confidence'], r['top1'] == r['truth']) for r in eligible
            if r['confidence'] is not None]
    return {
        'cases': len(records),
        'fault_cases': len(eligible),
        'top1_all': round(mean(r['top1'] == r['truth'] for r in eligible), 4) if eligible else None,
        'top3': round(mean(r['truth'] in r['top3'] for r in eligible), 4) if eligible else None,
        'coverage': round(len(answered) / len(eligible), 4) if eligible else None,
        'answered_accuracy': round(mean(r['prediction'] == r['truth'] for r in answered), 4) if answered else None,
        'unsafe_false_report_count': sum(r['truth'] is None and r['prediction'] is not None for r in records),
        'mean_evidence_bytes': round(mean(r['bytes'] for r in records), 2),
        'p95_diagnosis_us_offline': round(percentile([r['latency_us'] for r in records], .95), 2),
        'ece_top1': round(ece(cals), 4) if cals else None,
        'brier_top1': round(mean((float(ok) - p) ** 2 for p, ok in cals), 4) if cals else None,
    }


def paired_bootstrap_ci(a: list[dict], b: list[dict], seed: int = 9,
                        rounds: int = 800) -> tuple[float, float]:
    """CI of paired Top-1 differences, resampled by trace (not individual spans)."""
    left = {r['trace_id']: r for r in a if r['truth'] is not None}
    right = {r['trace_id']: r for r in b if r['truth'] is not None}
    keys = sorted(left.keys() & right.keys())
    if not keys:
        return (float('nan'), float('nan'))
    diffs = [int(left[k]['top1'] == left[k]['truth']) - int(right[k]['top1'] == right[k]['truth'])
             for k in keys]
    rng = random.Random(seed)
    samples = sorted(mean(rng.choice(diffs) for _ in keys) for _ in range(rounds))
    return (round(samples[int(.025 * (rounds-1))], 4), round(samples[int(.975 * (rounds-1))], 4))
