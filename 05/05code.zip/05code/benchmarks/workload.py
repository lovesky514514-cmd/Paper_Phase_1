"""Seeded, entirely synthetic workflows with separately held oracle labels."""

import random
from dataclasses import replace

from tracelite.model import Span, TraceCase

TEMPLATES = ('stale_cache', 'schema_change', 'rate_limit', 'agent_plan',
             'message_order', 'permission', 'duplicate_write', 'network_timeout',
             'healthy')


def make_case(template: str, seed: int) -> TraceCase:
    if template not in TEMPLATES:
        raise ValueError(template)
    rng = random.Random(seed)
    names = ('fetch', 'interpret', 'check', 'commit', 'notify', 'finalize')
    parents = (None, 'fetch', 'interpret', 'check', 'commit', 'notify')
    actors = ('inventory', 'planner', 'validator', 'order', 'notification', 'summary')
    spans = []
    for i, name in enumerate(names):
        spans.append(Span(f'{template}-{seed}', name, parents[i],
                          (), 1_000_000_000 + i * 1_000_000,
                          actors[i], name, 200, rng.randint(12, 60),
                          {'schema': 'pass', 'freshness': 'pass'}))
    origins = {
        'stale_cache': ('fetch', 'freshness', 200),
        'schema_change': ('interpret', 'schema', 200),
        'rate_limit': ('check', 'rate_limit', 429),
        'agent_plan': ('interpret', 'plan', 200),
        'message_order': ('notify', 'message_order', 200),
        'permission': ('commit', 'permission', 403),
        'duplicate_write': ('commit', 'state', 409),
        'network_timeout': ('fetch', 'network', 503),
    }
    oracle = None
    injected = ()
    if template != 'healthy':
        oracle, check, status = origins[template]
        root_index = names.index(oracle)
        old = spans[root_index]
        checks = {**old.validation, check: 'fail'}
        spans[root_index] = replace(old, status_code=status,
                                    latency_ms=1400 if check == 'network' else old.latency_ms,
                                    validation=checks)
        # The final reported error can be *downstream* of the originating fault.
        if root_index < len(names) - 1:
            old = spans[-1]
            spans[-1] = replace(old, status_code=500, validation={**old.validation, 'task': 'fail'})
        if root_index + 2 < len(names) - 1 and rng.random() < .55:
            old = spans[root_index + 2]
            spans[root_index + 2] = replace(old, status_code=409)
        injected = (oracle,)
        if seed % 5 == 0 and oracle != 'fetch':
            # A recoverable upstream 429 is a second injected fault, not the root
            # of the later irrecoverable failure. It prevents label = first error.
            earlier = spans[0]
            spans[0] = replace(earlier, status_code=429,
                               validation={**earlier.validation, 'recovered': 'pass'})
            injected = ('fetch', oracle)
    return TraceCase(f'{template}-{seed}', template, tuple(spans), oracle,
                     (oracle,) if oracle else (), injected)


def make_dataset(seed: int = 17, cases_per_template: int = 8,
                 templates: tuple[str, ...] = TEMPLATES) -> tuple[TraceCase, ...]:
    if cases_per_template <= 0:
        raise ValueError('cases_per_template must be positive')
    return tuple(make_case(name, seed * 1000 + i) for name in templates
                 for i in range(cases_per_template))
