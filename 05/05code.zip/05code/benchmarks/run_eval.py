"""Reproducible synthetic experiment; never call its outcome an SCI result."""

import argparse
import json
import time
from pathlib import Path

from tracelite import collect, diagnose, fit_temperature
from benchmarks.metrics import paired_bootstrap_ci, summarize
from benchmarks.workload import TEMPLATES, make_dataset

POLICIES = ('last_error', 'first_error', 'status_only', 'uniform', 'random',
            'adaptive', 'no_graph', 'full_capture', 'no_abstain')


def run_policy(dataset, policy: str, budget: int, missing: float, temperature: float, seed: int):
    records = []
    for index, case in enumerate(dataset):
        obs = collect(case, budget if policy != 'full_capture' else 100000,
                      'uniform' if policy == 'uniform' else 'random' if policy == 'random' else
                      'none' if policy in ('last_error', 'first_error', 'status_only') else 'full' if policy == 'full_capture' else 'adaptive',
                      missing_fraction=missing, seed=seed + index)
        start = time.perf_counter_ns()
        result = diagnose(obs, case.trace_id, temperature=temperature,
                          use_graph=policy not in ('no_graph', 'status_only', 'last_error', 'first_error'),
                          allow_abstain=policy != 'no_abstain')
        order = list(result.candidates)
        if policy in ('last_error', 'first_error'):
            errors = [s for s in obs.spans if s.abnormal]
            errors.sort(key=lambda s: s.time_ns, reverse=policy == 'last_error')
            fallback = [s for s in obs.spans if s not in errors]
            order_ids = [s.span_id for s in errors + fallback]
            rank_map = {c.span_id: c for c in order}
            order = [rank_map[name] for name in order_ids]
        elif policy == 'status_only':
            score = {s.span_id: (s.status_code >= 400, -s.time_ns) for s in obs.spans}
            order.sort(key=lambda x: score[x.span_id], reverse=True)
        top = order[0].span_id if order else None
        # Baseline policies always report a candidate if any visible symptom exists.
        selected = (top if policy in ('last_error', 'first_error', 'status_only') and
                    any(s.abnormal for s in obs.spans) else result.selected)
        latency_ns = time.perf_counter_ns() - start
        records.append({'trace_id': case.trace_id, 'template': case.template,
                        'truth': case.first_irrecoverable, 'top1': top,
                        'top3': [c.span_id for c in order[:3]], 'prediction': selected,
                        'confidence': (None if policy in ('last_error', 'first_error', 'status_only')
                                       else order[0].confidence if order else 0),
                        'bytes': obs.used_bytes, 'observed_spans': len(obs.spans),
                        'latency_us': round(latency_ns / 1000, 3)})
    return records


def run(seed=17, n=8, budget=200, missing=0.2):
    # Entire templates are held out: NOT a random record split across same template.
    train_templates = TEMPLATES[:3]
    valid_templates = TEMPLATES[3:5]
    test_templates = TEMPLATES[5:]
    validation = make_dataset(seed + 1, max(3, n), valid_templates)
    pairs = [(collect(c, budget, seed=seed + i), c.first_irrecoverable)
             for i, c in enumerate(validation) if c.first_irrecoverable]
    temperature = fit_temperature(pairs)
    test = make_dataset(seed, n, test_templates)
    raw = {p: run_policy(test, p, budget, missing, temperature, seed + 100) for p in POLICIES}
    return {
        'metadata': {'synthetic_only': True, 'seed': seed, 'cases_per_template': n,
                     'budget_bytes': budget, 'missing_fraction': missing,
                     'temperature_validation_only': temperature,
                     'train_templates_unused': list(train_templates),
                     'validation_templates': list(valid_templates), 'test_templates': list(test_templates),
                     'note': 'Local approximations only, NOT published-paper reproductions.'},
        'summary': {p: summarize(data) for p, data in raw.items()},
        'paired_top1_ci_adaptive_minus_uniform': paired_bootstrap_ci(raw['adaptive'], raw['uniform']),
        'records': raw,
    }


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--seed', type=int, default=17)
    cli.add_argument('--cases', type=int, default=8)
    cli.add_argument('--budget', type=int, default=200)
    cli.add_argument('--missing', type=float, default=.2)
    cli.add_argument('--output', default='results/last_run.json')
    args = cli.parse_args()
    output = run(args.seed, args.cases, args.budget, args.missing)
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Saved: {path} | temperature={output["metadata"]["temperature_validation_only"]}')
    for name, stats in output['summary'].items():
        print(f'{name:15} Top1={stats["top1_all"]} coverage={stats["coverage"]} bytes={stats["mean_evidence_bytes"]}')


if __name__ == '__main__':
    main()
