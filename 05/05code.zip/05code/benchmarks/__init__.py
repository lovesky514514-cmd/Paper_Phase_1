"""Synthetic fixtures and independent scoring helpers."""
