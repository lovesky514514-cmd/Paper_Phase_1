"""Create risk-coverage versus evidence-budget measurements (synthetic only)."""

import argparse
import json
from pathlib import Path

from .run_eval import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='results/matrix.json')
    parser.add_argument('--cases', type=int, default=8)
    args = parser.parse_args()
    points = []
    for seed in (17, 18, 19):
        for budget in (0, 160, 320, 960):
            for missing in (0, .2, .4, .6, .8):
                result = run(seed=seed, n=args.cases, budget=budget, missing=missing)
                for policy in ('first_error', 'uniform', 'adaptive', 'no_graph', 'no_abstain'):
                    points.append({'seed':seed, 'budget':budget, 'missing':missing,
                                   'policy':policy, **result['summary'][policy]})
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({'synthetic_only':True, 'points':points}, indent=2), encoding='utf-8')
    print(f'Saved {len(points)} matrix points to {output}')


if __name__ == '__main__':
    main()
