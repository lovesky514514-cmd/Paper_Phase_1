# 05code · TraceLite-RCA

Agent 工具调用的**轻量观测、预算化证据采集、根因候选排序、校准与弃权**研究原型。来源：`research/05_original.md`。

**安装：Python 3.11+、Go 1.22+。无需 pip、GPU、数据库或 API Key。**

| 用途 | Windows | Linux / macOS |
|---|---|---|
| 一键检查 | `scripts\check_windows.bat` | `sh scripts/check.sh` |
| 本地 HTTP 演示 | `scripts\start_windows.bat` | `sh scripts/start.sh` |
| 合成对照 | `py -3 -m benchmarks.run_eval` | `python3 -m benchmarks.run_eval` |

在解压后的 `05code` 根目录运行；端口固定使用 `127.0.0.1:8955` / `8956`。

- `gateway/`、`cmd/`：Go 本地 HTTP 工具网关，只采集脱敏元信息，异步落盘。
- `tracelite/`：Python 预算采样、证据分级排序、温度校准、低可信弃权与 JSONL 读取。
- `benchmarks/`：9 种**本地近似**对照/消融，结果在 `results/last_run.json`。
- `scripts/analyze.py`：分析任意符合本工程 JSONL 格式的轨迹；仅输出诊断建议，不执行修复。
- `tests/`：可复现单元与行为测试。

**重要：** 目前只有合成故障、有限的本地工具沙箱和近似基线；未忠实复现 AgentRx / CORRECT 等公开方法，未连接生产 MCP，也没有真实环境下的因果验证。论文贡献及低开销优势尚未证实。Go 网关默认本地演示，不能作为生产鉴权网关。

排错看 [`docs/troubleshooting.md`](docs/troubleshooting.md)；逐文件说明看 [`docs/DEBUG_INDEX.md`](docs/DEBUG_INDEX.md)。
