# 第五篇｜Agent 调用链异常检测与根因定位网关：SCI 科研立项与投稿报告

> **研究方向**：Agent Observability / Failure Attribution / Root Cause Localization / API Gateway / AIOps  
> **备选论文题名（暂用，不代表已经检索完所有同名工作）**：**TraceLite-RCA: Budgeted Evidence-Aware Root-Cause Localization for Tool-Using Agents under Partial Observability**  
> **中文题名**：**TraceLite-RCA：面向部分可观测工具调用智能体的预算约束与证据感知根因定位方法**  
> **用途**：学术立项、文献综述、算法与系统原型设计、预实验、SCI 选刊  
> **信息检索截至**：2026 年 10 月 20 日。  
> **重要说明**：本文属于**尚未实施、尚无验证结果**的研究方案。所有“目标改善”均为建议验收阈值，不是已获得的实验结论。文献中明确区分已发表作品、预印本、技术报告和综述。期刊数据为出版方展示的历史统计，不构成录用承诺。

---

## 0. 一页结论与第五篇在五篇选题中的位置

| 序号 | 方向 | 核心观点 | 主创新点（拟研究） | 相互关系 |
|---|---|---|---|---|
| 1 | Agent 故障感知与恢复网关 | 失败不等于应该直接重试 | 风险约束下的状态感知局部恢复 | 第五篇定位原因，可向第一篇发送恢复建议 |
| 2 | 多模型动态路由与成本优化 | 模型低报价不等于任务低总成本 | 验证费/执行风险进入端到端路由代价 | 第五篇提供故障风险画像与成本统计 |
| 3 | MCP 工具安全验证网关 | 工具可调用不等于当前操作获得授权 | 跨工具权限传播和执行前验证 | 第五篇提供违规证据与审计轨迹 |
| 4 | 多 Agent 调度与拥塞控制 | 局部最快不等于工作流整体最快 | 依赖感知的公平调度与拥塞反馈 | 第五篇区分真实故障和资源拥塞症状 |
| **5** | **调用链异常检测与根因定位** | **最终报错位置往往不是首先导致失败的环节** | **有限采样/隐私约束下的证据感知诊断、可弃权决策和针对性验证** | **可单独投稿，也是前四篇的观测基础** |

**主观点**：如果只看 HTTP 500、模型报错或最后失败的 Agent，就容易把**传播后的症状**当作**原始故障**。真正值得发表的研究问题不是“能否记录完整日志”，而是：**在不能读取全部 Agent 内部状态、采集预算有限且存在隐私限制时，能否以较低的系统开销给出可信的故障定位，并明确指出证据不足时无法判断？**

**主创新主张（待验证）**：将**有限预算的证据采集（selective observability）**、**跨 Agent/工具因果候选链重建（evidence graph）**和**带弃权的根因排名（calibrated attribution）**联合优化，在网关可见信息范围内找出最可能的起始故障点，并用可执行的安全干预验证少数候选。需要强调：**单靠观测图不能证明因果关系**。

**预期论文定位**：软件工程 / 分布式系统 / AIOps + Agent 系统可信性。比“日志分析平台开发报告”更有研究价值，但竞争比想象中激烈。推荐先跑小型可复现实验，达到预先登记的门槛再动笔写正式投稿稿。

---

## 1. 研究场景、研究问题与失败示例

### 1.1 与传统微服务故障有什么区别？

传统调用链：请求 → API 网关 → 服务 A → 服务 B → 数据库；常见的故障是超时、连接失败、资源不足、异常返回。

Agent 调用链：用户目标 → Agent 规划 → 工具选择 → 第三方 API/数据库 → 返回观测 → Agent 再规划 → 另一个 Agent → 最终操作。除传统服务故障外，还会出现：参数看似合法但**语义错误**、工具响应过时、Agent 把前一个结果当作错误前提、权限作用域不正确、上下文丢失、分支依赖被错误传播、部分步骤被人工或网关重试而掩盖。**HTTP 200 不等于业务正确。**

### 1.2 具体案例

一个采购 Agent 工作流：

1. `SearchAgent` 查询库存，工具响应 `sku-21: in_stock=true`，但结果快照实际已过期；
2. `PlannerAgent` 依据该结果承诺“可以下单”；
3. `BillingAgent` 生成付款请求，返回 HTTP 200；
4. `OrderAgent` 提交订单，库存检查失败、返回 409；
5. 网关最终只看到 `OrderAgent` 的 409。

**表面症状**在第 4 步；**候选根因**可能在第 1 步（过期库存）、第 2 步（未验证新鲜度）、第 3 步（错误提交顺序），不能在缺乏更多证据时武断判定。论文要给出候选、证据链、置信程度和“还缺什么证据”。

### 1.3 四项可回答的科研问题

- **RQ1：准确性**：在不同程度的链路缺失、日志采样和上下文删减下，能否仍精确找到**根因 Agent / 步骤 / 工具调用 / 故障类型**？
- **RQ2：开销**：在给定 P95 时延增量、存储体积和 Token 预算时，哪类事件最值得记录，是否优于平均采样？
- **RQ3：可信性**：模型给出的根因排名是否有可检查证据；低置信度时弃权能否显著降低误导性结论？
- **RQ4：迁移性**：在未见过的工作流、工具拓扑、模型家族和故障类型上，定位能力能否保持，而非记住注入模板？

---

## 2. 必须回避的“撞题”风险（2025–2026 直接竞争工作）

以下论文不是“背景读物”，而是投稿时审稿人最可能要求直接对照的工作。

| 现有论文 | 已覆盖的创新，不应再自称首次提出 | 第五篇可验证的差异化方向 |
|---|---|---|
| **Which Agent Causes Task Failures and When?**（ICML 2025） | Who&When 基准、Agent/步骤级归因 | 以网关采集预算和不可见状态为基本约束 |
| **TRAIL**（2025） | 人工标注 Agent 轨迹与错误定位基准 | 在被裁剪的网关 Span 上定位，量化丢失信息的影响 |
| **AgenTracer**（ICLR 2026） | 反事实重放与专门训练的失败追踪模型 | 不训练大模型也可运行；部署低成本；明确弃权 |
| **FAMAS**（2025） | Spectrum-based 失败归因与多次重放 | 单次运行证据不足时能否低成本选取补充测试 |
| **GraphTracer**（2025） | 跨 Agent 信息依赖图与错误传播分析 | 处理采集不完整、隐私遮蔽和采样预算 |
| **CORRECT**（ICML 2026） | 无训练在线故障模式缓存、快速归因 | 预算化主动采集 + 缺失证据条件下置信度校准 |
| **AgentRx**（EMNLP 2026 页面） | 不变量推导、约束检查、可审计证据链 | 网关边界不具完整执行轨迹：处理观测缺失/弃权代价 |
| **AgentEval**（2026 预印本） | DAG 逐步评估、依赖传播、根因分析 | 在同样诊断质量约束下尽量减少日志/LLM 成本 |
| **AgentTrace**（2026 预印本） | 从执行日志恢复图并做根因排名，低推断延迟 | 采样策略、隐私、统计置信度、跨工作流稳定性 |
| **DoVer**（2025 预印本） | 通过真实干预验证失败假设、强调修复效果 | “何时值得干预”由预算和风险约束决定；禁止生产环境危险重放 |
| **TraceElephant**（ACL 2026） | 完整执行轨迹和可重现环境对归因帮助显著 | 故意限制可观测性，研究精度/开销的 Pareto 前沿 |
| **Tracing Agentic Failure from the Flow of Success**（2026 预印本） | 仅用成功轨迹训练异常归因器 | 图结构与证据合规性、可解释缺失信息和部署成本 |

> **关键结论**：如果最终作品只有 `OpenTelemetry + DAG + LLM 分析日志`，创新不足。**TraceLite-RCA 必须证明：在等价总资源预算和相同可见信息条件下，它比强基线更准确，或在相同准确度下更省采集/计算开销，同时能正确表达不确定性。**

与上述研究相关的主要论文入口： [Who&When](https://proceedings.mlr.press/v267/zhang25cq.html)、[AgentRx](https://arxiv.org/abs/2602.02475)、[AgentTrace](https://arxiv.org/abs/2603.14688)、[AgentEval](https://arxiv.org/abs/2604.23581)、[AgenTracer](https://arxiv.org/abs/2509.03312)、[CORRECT](https://proceedings.mlr.press/v306/yu26x.html)、[DoVer](https://arxiv.org/abs/2512.06749)、[TraceElephant](https://aclanthology.org/2026.acl-long.912/)。

---

## 3. 提出的研究架构：TraceLite-RCA

### 3.1 概念性系统结构

```text
外部用户 / 多 Agent 工作流 / MCP 与 HTTP 工具
                    |
              [Gateway Proxy]
                    |
       +------------+-------------+
       |                          |
  [请求/响应处理]               [事件提取]
  trace_id / span_id             |
  agent_id / tool_name      元信息、延迟、参数校验结果
  status / request_hash          |
       |                    [隐私与配额过滤]
       |                     日志采样 / 摘要化
       |                          |
       +--------------------------+
                    |
          [证据与依赖图构造]
      时序边 / 调用边 / 数据版本边 /
         校验边 / 不确定依赖边
                    |
       [轻量异常检测 + 根因候选集]
                    |
   [带预算约束的补充证据选择策略]
                    |
       [证据一致性评分与置信校准]
                    |
         +----------+-----------+
         |                      |
  [有证据的根因候选报告]      [弃权/请求补充数据]
         |
  可选：沙箱/只读环境反事实测试
```

### 3.2 数据面和控制面分离

- **数据面**：执行转发；严禁因诊断失败阻塞核心业务；保护网关正常路径和可用性。
- **观测面**：统一跟踪关联 ID、校验字段、输出哈希与版本号；默认不采集敏感明文或模型私有推理内容。
- **诊断面**：异步构图、候选筛选、证据选择、结果校准、离线安全验证。
- **决策面**：向使用方报告候选来源、证据、置信度、限制条件；仅提供建议，不默认执行高风险恢复。

### 3.3 最小日志字段（MVP）

```json
{
  "trace_id": "example-run-001",
  "span_id": "tool-004",
  "parent_span_id": "agent-002",
  "time_ns": 0,
  "actor_type": "tool",
  "actor_id": "inventory-api",
  "operation": "get_stock",
  "request_schema_version": "v2",
  "input_digest": "sha256-redacted-value",
  "output_digest": "sha256-redacted-value",
  "status_code": 200,
  "latency_ms": 88,
  "result_freshness_ms": 120000,
  "validation": { "schema": "pass", "freshness": "fail" },
  "sampling_probability": 0.20,
  "observability_mask": ["hidden_tool_body", "hidden_reasoning"],
  "trace_policy": "pseudonymous-minimal"
}
```

**注意**：上述是拟定的统一中间表示，不是声称 MCP 或 OpenTelemetry 原生就有全部字段；`result_freshness_ms` 只有能取得版本时间戳时才成立，哈希也不能单独证明内容可信。

### 3.4 算法单元 A：预算感知观测选择

设调用事件为 $e_i$，采集决策 $z_i\in\{0,1\}$，记录事件的成本为 $c_i$，总采集预算为 $B$。

$$
\max_{z_i}\; \mathbb E[\Delta\,\mathrm{DiagnosticUtility}\mid z_1,\ldots,z_n]
\quad\text{s.t.}\quad \sum_i z_ic_i\leq B.
$$

实践中不用直接解复杂的最优控制，可从可解释的**异常分值 × 依赖关键度 ÷ 采集成本**开始，随后尝试多臂老虎机或上下文 bandit。极关键或合规必要的事件可设为**必录**；并记录每条 Span 的采样概率，避免评价偏差。对罕见故障设保护配额，不能因为“低频”就完全不可见。

**与普通均匀采样的差异**必须通过同等字节/事件预算实验体现。

### 3.5 算法单元 B：证据一致性根因候选排序

建立异构图 $G=(V,E)$：

- 节点：Agent 步骤、工具调用、工具结果、状态版本、验证事件、外部观测。
- 边：直接调用、数据依赖、版本一致性、显式引用、已知工作流依赖。
- 每条边附带来源和证据等级：**直接验证**、**有记录支持**、**仅为时间相关猜测**。

对候选根因 $r$ 使用下式作为**研究设计模板**：

$$
S(r)=w_1 A(r)+w_2 D(r)+w_3 V(r)-w_4 U(r)-w_5 K(r),
$$

其中 $A$ 是异常强度，$D$ 为传播路径一致性，$V$ 为独立验证证据，$U$ 是缺失观测惩罚，$K$ 是诊断/干预成本。**各变量必须在训练、验证、测试前定义；权重只能在验证集上确定**。不要把这个加权公式本身当作唯一算法创新；主要贡献应体现在新的信息采集与可信校准机制。

候选输出应包含：`suspect / step / observed_evidence / assumptions / confidence / missing_evidence / recommended_next_check`。

### 3.6 算法单元 C：置信校准、弃权与安全干预

- 对根因 Top-1 和 Top-k 概率进行温度缩放/保序校准；分开报告正确率与校准误差（ECE/Brier）。
- 当证据不足，系统可以输出“无法确认”。独立统计**覆盖率与已回答样本错误率**，避免模型靠全部弃权获得表面高准确度。
- 只能在沙箱、模拟器、只读服务或明确允许重放的幂等调用上做“候选步骤替换 / 故障变量回滚 / 结果新鲜度替换”干预；**不得在生产系统随意重放支付、删除、部署、写库等操作**。
- 观测数据上的边最多表示相关/依赖假设；若想宣称某一步是“因果根因”，须有明确干预、反事实对照或经实验设计支持的机制证据。不能仅依赖时序先后。

### 3.7 伪代码

```python
# 研究伪代码，仅表达逻辑；不是可直接运行的完整工程

def diagnose(workflow_trace, budget, policies):
    mandatory = collect_mandatory_events(workflow_trace, policies)
    candidates = cheap_anomaly_screen(mandatory)
    evidence = budgeted_evidence_selection(candidates, budget, policies)
    graph = build_provenance_graph(mandatory, evidence)
    ranked = score_root_cause_candidates(graph)
    calibrated = calibrate_confidence(ranked)
    if insufficient_evidence(calibrated, graph, policies):
        return abstain_with_missing_evidence(graph)
    if sandbox_available(policies):
        calibrated = optional_safe_counterfactual_checks(calibrated)
    return report_evidence_and_limitations(calibrated)
```

---

## 4. 交叉学科方向：8 个可独立拓展的小论文选题

| 交叉学科 | 论文子问题 | 可用方法 | 验证指标 | 适合程度 |
|---|---|---|---|---|
| **因果推断 × Agent** | 观测到的故障相关性是否真能解释干预后的恢复？ | 结构因果图、故障注入、反事实 | 干预验证成功率、假阳性因果声明率 | 高，学术性强但较难 |
| **信息论 × 网关** | 最少采集多少信息才不丢失关键根因？ | 信息增益、最小描述长度、主动采样 | Bytes/trace 与 Top-k 准确率曲线 | **首推，系统创新清晰** |
| **控制理论 × AIOps** | 能否在故障真正扩散前检测异常演化？ | CUSUM、变化点检测、状态估计 | 提前量、误报/漏报、检测延迟 | 高，可形成独立研究 |
| **软件测试 × 自动化故障注入** | 哪些注入事件可代表真实 Agent 故障？ | 变异测试、组合覆盖、故障模型 | 缺陷检出率、跨场景迁移 | **首推，易复现** |
| **形式化方法 × Agent** | 能否验证诊断报告是否违反操作约束？ | 设计契约、不变量、运行时验证 | 约束发现率、可解释证据覆盖率 | 高，需避免与 AgentRx 重复 |
| **隐私计算 × 可观测性** | 遮盖 PII/敏感 API 参数后能保留多少诊断能力？ | 字段级脱敏、聚合、加噪实验 | 隐私风险/精度/开销三目标 | 高，但不要空泛宣称隐私保证 |
| **图学习 × 软件工程** | 图依赖是否真的比平面统计特征有效？ | 异构图、图算法、严格图消融 | Top-1 / Top-3、跨系统泛化 | 中高，需注意图方法可能无增益 |
| **人因工程 × SRE** | 证据化诊断是否比黑盒结论更有助于工程师排查？ | 用户研究、任务时间、可信度校准 | MTTR、诊断准确率、信任校准 | 中高，需受试者与伦理安排 |

**最值得优先发展的两条副线**：A. 信息论驱动的**低成本采样**；B. 软件测试驱动的**可复现失败链生成**。既贴合后端网关，又不要求昂贵模型训练。

---

## 5. 数据集、实验平台与可行性

### 5.1 建议的主要数据来源

| 来源 | 类型 | 可用任务 | 实验位置/注意点 |
|---|---|---|---|
| **AgentRx Benchmark** | 已标注失败轨迹 | 第一个不可恢复失败步骤、失败分类 | 基准约 115 条轨迹；检查许可证、格式、标签定义 |
| **TRAIL** | 人工标注 Agent 轨迹 | 故障识别、长轨迹分析 | 约 148 条，适合低成本首次验证 |
| **Who&When** | 多 Agent 失败轨迹 | Agent 与步骤级归因 | 明确原基准输入是否含网关真实可见字段 |
| **TraceElephant** | 完整执行轨迹 | 完整观测→部分观测退化试验 | 最适合验证本研究的 partial observability 主张 |
| **CORRECT-Error** | 错误注入轨迹 | 模板复用/跨应用泛化 | 需要防止相同模板跨训练测试泄漏 |
| **τ-bench** | 工具、用户与状态评估 | 构造带真实工具约束的工作流 | 运行成本与开放接口视版本而定 |
| **AIOpsLab** | 云原生实验/故障注入 | 网络和资源故障、多模态遥测 | 更适合有服务器时部署 |
| **RCAEval** | 微服务故障/遥测 | 方法迁移到传统分布式服务 | 源数据较大，不能当作 Agent 原生故障基准 |
| **OpenRCA** | 大规模 RCA 遥测 | 故障根因识别 | 数据量/硬件开销明显较高，非第一阶段首选 |
| **自建 Gateway-FaultBench** | 受控合成 + 真实回放 | 网关采样/缺失/故障传播/回放评估 | 必须公开生成器、种子、注入位置及标签规则 |

数据地址： [AgentRx 代码与数据](https://github.com/microsoft/AgentRx)、[Who&When](https://github.com/mingyin1/Agents_Failure_Attribution)、[TraceElephant 论文](https://aclanthology.org/2026.acl-long.912/)、[τ-bench](https://arxiv.org/abs/2406.12045)、[AIOpsLab](https://github.com/microsoft/AIOpsLab)、[RCAEval](https://github.com/phamquiluan/RCAEval)、[OpenRCA](https://github.com/microsoft/OpenRCA)。

### 5.2 故障注入矩阵（必须跨类型）

| 故障大类 | 注入情景 | 期望“原始根因”粒度 |
|---|---|---|
| 网络与服务 | 429、503、超时、延迟放大 | 工具/服务/步骤 |
| 数据质量 | 过时缓存、字段遗漏、单位混淆、错误 ID | 数据版本/工具响应 |
| 参数与协议 | schema 兼容但语义不符、字段类型错、协议变更 | 参数生成/接口边界 |
| Agent 控制流 | 规划漏步、错误依赖、任务提前终止 | Agent/步骤 |
| Agent 通信 | 消息错序、角色引用错误、上下文删减 | Agent 间传输边 |
| 安全权限 | 被拒绝的工具调用、权限变更未同步 | 授权决策点 |
| 并发资源 | 队列拥塞、配额争夺、重试风暴 | 资源竞争/调度点 |
| 状态副作用 | 重复写、幂等键冲突、失败补偿 | 状态变更操作 |

**核心约束**：每种故障需有单因素注入和多因素注入；不能把“注入位置”永远等同“用户可见故障根因”。对于可自行恢复的暂时异常，第一次异常未必构成导致任务失败的根因。标注准则须区分：`注入故障 / 可见异常 / 首次不可恢复步骤 / 可干预根因集合`。

### 5.3 最小设备与预算

- 单机 **16–32 GB RAM、4–8 核 CPU**可先完成轨迹解析、规则、简单图算法与小规模模型辅助分析；具体取决于数据集体量。
- 不必本地训练 7B/8B；优先规则/统计/图排序，使用预先固定的小模型 API 做**相同条件对比**，单独统计推理费用。
- 首阶段选 TRAIL/AgentRx 部分样本，加自建合成场景，即可验证 “采样预算—精度” 曲线，避免一开始下载大型 OpenRCA 原始遥测。
- 服务栈建议：**Python 原型、FastAPI/gRPC 接口、OpenTelemetry OTLP Span、SQLite/DuckDB/Parquet、NetworkX；高并发转发可后续替换为 Go/Rust 网关**。若研究证据主要来自离线模拟，要如实称“离线代理式网关模拟”，不能宣称生产级低开销。

---

## 6. Baseline 设计与不可省略的实验

### 6.1 对照组至少 10 种

1. 无诊断：始终将最后报错步骤归为根因（Last Error）。
2. 最早异常：最先出现异常日志的位置（First Error）。
3. 规则/状态码：固定优先级规则。
4. 不采集额外证据的纯时间顺序排序。
5. 传统依赖图随机游走 / PageRank 类排序。
6. 单次 LLM 全日志阅读（控制 Token 与失败率）。
7. LLM 逐步/二分定位（对应 Who&When 基线类别）。
8. AgentRx（在允许的相同观测条件下对照，充分披露改造）。
9. AgentTrace 或 GraphTracer 的公开可运行实现（版本、代码可用性需单独核查）。
10. CORRECT、FAMAS 或 DoVer 中至少一项适配基线（若无法复现，应说明障碍并补同能力基线）。
11. **Ours without selective sampling**：全量/固定采样 + 同一根因分类器。
12. **Ours without abstention/calibration**：相同候选器但强制输出。

**公平性**：强基线如果本来要求全量隐私明文和内部隐藏状态，应分别报告**原配置上界**和**同观测约束配置**，不可把原方法削弱后只显示我们获胜。明确额外训练成本、缓存预热、人工标注和干预成本。

### 6.2 指标清单

| 目标 | 主要指标 | 关键误区 |
|---|---|---|
| 归因精度 | Root Cause Top-1/Top-3；Agent / Step / Tool 分层准确率 | Top-k 在候选集合很小时可能虚高 |
| 异常检测 | Precision、Recall、F1、PR-AUC | 不能只报告 accuracy |
| 诊断开销 | P50/P95 延迟、CPU、峰值 RAM、Bytes/trace、Token/trace | 必须包括日志采集和模型调用全成本 |
| 在线成本 | Gateway P95/P99 延迟增量、吞吐 QPS、丢 Span 率 | 离线指标不能冒充线上指标 |
| 证据可靠性 | 证据覆盖率、证据支持率、无证据断言率 | 可读解释不等于因果证据 |
| 校准与弃权 | ECE、Brier、风险-覆盖率曲线 | 不能全部弃权作弊 |
| 泛化 | 跨工作流、跨工具、新故障类型、跨 Agent 框架 | 同模板随机划分易泄漏 |
| 效益 | 工程师定位时间、可安全验证候选比例 | 人评需随机顺序、盲测/统一指导 |

### 6.3 必须有的五组关键图

- **图 1：** 采集预算（字节或 Span）—Root Cause Top-1/Top-3 Pareto 曲线。
- **图 2：** 观测缺失比例 0/20/40/60/80% 下各方法的精度和弃权率。
- **图 3：** 横跨不同工作流/框架的 OOD 结果，附置信区间。
- **图 4：** 网关额外 P95 延迟（ms）与吞吐量（QPS）；包含未接入监测的纯网关 baseline。
- **图 5：** 校准/风险覆盖图：错误定位率随“只回答最可信前 x% 案例”的变化。

### 6.4 消融方案

- 删掉关键依赖图边，只用时序；检验图的真实价值。
- 删除证据来源质量权重；检验证据分级。
- 删除预算选择；改均匀采样和随机采样。
- 删除隐私字段遮盖；量化隐私—效果折中。
- 删除置信校准、删除弃权、删除补充查询。
- 将所有 LLM 判断替换为轻量规则；判断是否真正需要 LLM。
- 用只依赖服务/Agent ID 的“先验模型”作为负面对照，排查基准标签泄漏（参考 2026 年对 RCAEval 的方法学批判）。

### 6.5 实验统计规范

- 故障注入要固定主随机种子并公开 3–5 组随机重复；重复运行不能把同一轨迹重复算成独立样本。
- 使用按工作流或工具集分组的划分，避免训练、验证、测试共享同一场景模板。
- 对主要指标报告置信区间与效应量；尽可能进行**配对**比较，而非只比较均值。
- 预注册核心成功门槛，之后不可为了凑结论任意变更指标。
- 对无法取得的内部状态应写清“观测盲区”；不能在网关方案中偷偷读取比竞争对手更多的资料。

### 6.6 可采用的立项阶段门槛（仅为拟定目标）

1. 在至少两个不同 Agent 数据来源上，低采集预算下的根因 Top-1 不低于均匀采样方法；最好取得统计上可重复的改善。
2. 同准确度条件下，相比全量采集显著降低日志体积或诊断费用；建议追求至少 **30% 成本降低**，但并非 SCI 的必要阈值。
3. “弃权”机制使高置信输出的错误率显著下降，并给出覆盖率代价。
4. 真实网关系统的 P95 时延增量可控；建议作为工程目标测试 **≤5%**，具体由基准和部署方式决定。
5. 至少一种跨工作流 OOD 测试有正向价值；如果只在人工注入训练模板上有效，不宜急于投稿。

---

## 7. 论文结构（可直接用于 SCI 初稿）

1. **Introduction**：为何最终异常≠根因；部署限制与研究空白；贡献三条。
2. **Background / Problem Statement**：观测预算、匿名日志、证据等级与根因标签的定义。
3. **Related Work**：Agent 失败归因；分布式追踪与微服务 RCA；主动监测与置信校准。
4. **TraceLite-RCA Design**：采样策略、证据图、候选排序、弃权及安全验证。
5. **Experimental Setup**：环境、故障模型、数据、基线、公平预算、统计方法。
6. **Evaluation**：准确度、消融、负载、OOD、校准和安全边界。
7. **Threats to Validity**：模拟故障和真实故障差距、隐状态不可得、标注歧义、跨系统迁移。
8. **Conclusion and Availability**：开源协议、代码/数据入口、限制。

**拟定摘要结构（不可在实验前填入假的性能数字）**：

> Agentic workflows increasingly combine model inference, tool calls, and delegated execution, making failures difficult to attribute from gateway-visible telemetry. We study root-cause localization under partial observability and bounded tracing budgets. We propose TraceLite-RCA, which [1] ..., [2] ..., and [3] ... . We evaluate it on ... against ... under matched tracing and inference budgets. Results show ... . The method does not claim causal certainty without validated interventions.

---

## 8. 12 周研究排期与任务分工

| 周次 | 必须交付的成果 | 未通过时的处理 |
|---|---|---|
| W1 | 读 AgentRx / AgentTrace / AgentEval / Who&When / TraceElephant，写逐篇差异矩阵 | 重选问题，切忌先开始堆代码 |
| W2 | 定义根因标签、可观测字段、隐私策略和最小数据契约 | 先确定任务边界 |
| W3 | 运行 TRAIL、AgentRx 的可用数据，得到 4 个基础 baseline | 先解决基准许可/格式/可复现性 |
| W4 | OpenTelemetry/Proxy 采集原型与日志量统计 | 网关不能稳定运行则先离线复现 |
| W5 | 异常规则、证据图、最简单的无训练根因排名 | 优先可解释性能而非大模型 |
| W6 | 加入预算选择和缺失 Span 处理 | 先取得一条完整 Pareto 曲线 |
| W7 | 置信校准、弃权和证据标签 | 排查是否因弃权造成虚高准确率 |
| W8 | 故障注入基准与 OOD 测试 | 增加跨拓扑/跨场景变化 |
| W9 | 与强竞争方法作公平复现 | 代码不可用时详细披露并补替代对照 |
| W10 | 消融、鲁棒性、网关 QPS/P95 测量 | 若只有“功能展示”，暂不进入投稿阶段 |
| W11 | 报表、样本核查、统计显著性和失败案例 | 复核结论是否经得起反例 |
| W12 | 英文正文、代码 README、数据说明、选刊最终核验 | 指标不达标时只输出技术报告，不强投 |

**适合你学弟的分工**：后端侧负责 OTLP 采集与追踪、压测、网关部署、故障注入；算法侧负责根因排名、信息选择、校准和实证统计；论文侧负责相关工作、实验严谨性与可重复运行脚本。两人也能做，但尽量别同时训练模型和重写整套网关。

---

## 9. 期刊筛选：优先“历史审稿较快 + 可免 APC + 选题吻合”

### 9.1 如何理解“免费 SCI”

**通常可行的免费路线是：在支持混合出版的 SCI/SCIE 期刊选择 *subscription publishing*（订阅发表）而非付费 Gold Open Access。** Elsevier 明确说明：其混合期刊的订阅发表路线通常不收取 APC；最终需检查该期刊是否另有特殊费用、是否允许你的资助项目选择非 OA、以及收录状态。**不要将“开放获取支持/支持 OA”直接理解为免费发表，也不要误把“3 天 first decision”当作 3 天录用。**

来源： [Elsevier 订阅与 OA 选项](https://www.elsevier.support/publishing/answer/which-open-access-options-are-available)、[Elsevier 期刊出版模式](https://www-prod.elsevier.com/publishing/publish-in-a-journal/journal-selection)、[Elsevier 费用政策](https://www.elsevier.com/about/policies-and-standards/pricing)。

### 9.2 候选期刊对照（出版商官网公开历史统计）

> 以下三项按顺序为：**投稿→首次编辑决定**（包含较快的 desk rejection）、**投稿→外审后决定**、**投稿→最终录用**。它们是来自不同历史样本的统计指标，不能相加，也不意味着任何具体论文必然在此时间内接收。单位：天。

| 期刊 | 首次决定 | 外审后决定 | 投稿→录用 | 费用路线 | 本选题匹配及投稿建议 |
|---|---:|---:|---:|---|---|
| [Expert Systems with Applications (ESWA)](https://www.sciencedirect.com/journal/expert-systems-with-applications/about/insights) | 5 | 62 | **147** | 订阅可免 APC | 若有明确算法提升、跨任务比较、足够实验，优先；仅网关日志工具不够 |
| [Computer Networks](https://www.sciencedirect.com/journal/computer-networks/about/insights) | 5 | 78 | **154** | 订阅可免 APC | **必须**有网络/分布式链路追踪、负载与通信开销贡献，单纯 Agent 分析容易跑题 |
| [Computer Communications](https://www.sciencedirect.com/journal/computer-communications) | 2 | 80 | **177** | 订阅可免 APC | 强调网关遥测、网络追踪代价和异常传播；有高并发实测更好 |
| [Future Generation Computer Systems (FGCS)](https://www.sciencedirect.com/journal/future-generation-computer-systems/about/insights) | 3 | 72 | **183** | 订阅可免 APC | 适合分布式 Agent 工作流、云网关部署、规模化可观测性；**综合首选** |
| [Journal of Network and Computer Applications (JNCA)](https://www.sciencedirect.com/journal/journal-of-network-and-computer-applications/about/insights) | 11 | 88 | **187** | 订阅可免 APC | 有 Agent API 网关、网络/服务应用场景、性能验证时很合适 |
| [Information and Software Technology (IST)](https://www.sciencedirect.com/journal/information-and-software-technology/about/insights) | 7 | 85 | **202** | 订阅可免 APC | 软件工程实证、调试实践、基准与威胁分析很合适；注重实验完整性 |
| [Journal of Systems and Software (JSS)](https://www.sciencedirect.com/journal/journal-of-systems-and-software/about/insights) | 5 | 74 | **203** | 订阅可免 APC | 系统设计、诊断解释、工程落地与复现合适；竞争也较激烈 |

**检索与政策核查提示**：

1. 上表周期为截至 **2026-10-20** 所见的出版商页面历史展示值；实时数值可能变化，投前需重新打开 Insights 页面。
2. “首轮决定 2–11 天”很可能包含**编辑初筛拒稿**；绝对不能当作“一个星期过审”。
3. 期刊题目与 SCIE/JCR 分区是不同概念；本文不冒用未核实的 2026 年中科院分区、JCR Quartile、影响因子或录用率。**正式投稿时逐项查询 [Clarivate Master Journal List](https://mjl.clarivate.com/)**，根据机构要求确认检索类型。
4. 订阅发表通常不收 APC，不代表没有**极少数特殊栏目、超页、图色印刷等附加费用**；以对应期刊 Guide for Authors 为准。
5. 免费路线不等于论文对所有读者免费阅读；若必须 OA，需另外确认机构转换协议、资助基金或完全免费的钻石 OA 期刊。
6. 该类期刊常会因创新性不足或不符合范围而快速 desk reject；“投快刊”不能替代实证验证。

### 9.3 两套选刊顺序

**路线 A（最推荐，软件系统/工程真实部署）**：FGCS → JNCA → IST → JSS。若网络追踪与通讯贡献非常突出，再考虑 Computer Networks / Computer Communications。

**路线 B（算法/异常检测具有明显新方法与结果）**：ESWA → FGCS → JNCA → IST。若只基于自建的小样本场景，建议先补实验，不能仅凭 ESWA 的较快历史录用统计选它。

**不可预先保证**：具体投稿周期、编辑要求、正式 SCIE 收录和免费政策都必须在**实际投稿日**再次核实。

---

## 10. 关联文献总表（45 篇/份，均提供可追溯入口）

> **数量说明**：这里严格按**45 篇不同研究作品**整理，不把官网工具文档算成论文。个别研究仅有 arXiv 预印本或技术报告、会议投稿件，均作标注；`arXiv` 链接**不等于已正式同行评审发表**。同一论文的会议版和 arXiv 版只计一次。每条下方的“用途”是本报告自己的研究建议，并不意味着原文已经证实第五篇的方法。

### A. Agent 失败归因与故障分析：1–19（必须重点读）

1. **AgentRx: Diagnosing AI Agent Failures from Execution Trajectories**（2026；Microsoft Research 页面列 EMNLP 2026）。[论文](https://arxiv.org/abs/2602.02475) / [代码](https://github.com/microsoft/AgentRx)。**用途**：不变量验证、第一关键失败步骤、审计证据，直接竞争。
2. **AgentTrace: Causal Graph Tracing for Root Cause Analysis in Deployed Multi-Agent Systems**（2026；预印本）。[论文](https://arxiv.org/abs/2603.14688)。**用途**：图重建、根因排序、低延迟分析，直接竞争。
3. **AgentEval: DAG-Structured Step-Level Evaluation for Agentic Workflows with Error Propagation Tracking**（2026；预印本）。[论文](https://arxiv.org/abs/2604.23581)。**用途**：DAG 逐步验证、质量指标与因果候选。
4. **DoVer: Intervention-Driven Auto Debugging for LLM Multi-Agent Systems**（2025；预印本）。[论文](https://arxiv.org/abs/2512.06749)。**用途**：从观察性定位走向干预验证；注意重放副作用。
5. **AgenTracer: Who Is Inducing Failure in the LLM Agentic Systems?**（ICLR 2026）。[论文](https://arxiv.org/abs/2509.03312)。**用途**：反事实轨迹标注、训练归因模型，强对手。
6. **Who is Introducing the Failure? Automatically Attributing Failures of Multi-Agent Systems via Spectrum Analysis**（2025；预印本，FAMAS）。[论文](https://arxiv.org/abs/2509.13782)。**用途**：Spectrum-based 异常归因，适合做统计基线。
7. **Which Agent Causes Task Failures and When? On Automated Failure Attribution of LLM Multi-Agent Systems**（ICML 2025）。[正式论文](https://proceedings.mlr.press/v267/zhang25cq.html)。**用途**：Who&When 数据及 Agent/Step 标签；必读。
8. **TRAIL: Trace Reasoning and Agentic Issue Localization**（2025；预印本）。[论文](https://arxiv.org/abs/2505.08638)。**用途**：人工注释错误分类、轨迹评测；小样本开局。
9. **Why Do Multi-Agent LLM Systems Fail?**（NeurIPS 2025）。[论文](https://arxiv.org/abs/2503.13657)。**用途**：失败分类学、实际错误模式与任务设计。
10. **Where LLM Agents Fail and How They Can Learn From Failures**（2025；预印本，AgentDebug）。[论文](https://arxiv.org/abs/2509.25370)。**用途**：跨规划/记忆/动作的级联错误定位。
11. **Seeing the Whole Elephant: A Benchmark for Failure Attribution in LLM-based Multi-Agent Systems**（ACL 2026，TraceElephant）。[正式论文](https://aclanthology.org/2026.acl-long.912/)。**用途**：完整轨迹基准；适合裁剪可见信息比较。
12. **Tracing Agentic Failure from the Flow of Success**（2026；预印本）。[论文](https://arxiv.org/abs/2607.12747)。**用途**：成功轨迹建模与无监督失败检测。
13. **CORRECT: COndensed eRror RECognition via knowledge Transfer in multi-agent systems**（ICML 2026）。[正式论文](https://proceedings.mlr.press/v306/yu26x.html)。**用途**：在线轻量故障模板与低开销方法的强基线。
14. **GraphTracer: Graph-Guided Failure Tracing in LLM Agents for Robust Multi-Turn Deep Search**（2025；预印本）。[论文](https://arxiv.org/abs/2510.10581)。**用途**：跨 Agent 数据依赖图、传播链追踪。
15. **CORRECT 与 GraphTracer 之外的谱系：ECHO — Where Did It All Go Wrong? A Hierarchical Look into Multi-Agent Error Attribution**（2025；公开会议稿）。[论文](https://openreview.net/pdf?id=0MyUdq7wLe)。**用途**：上下文层级和多评审一致性；核查最终录用状态。
16. **Flow-of-Action: SOP Enhanced LLM-Based Multi-Agent System for Root Cause Analysis**（2025；预印本）。[论文](https://arxiv.org/abs/2502.08224)。**用途**：Agent 做传统故障 RCA，反向帮助设计可检查诊断流程。
17. **Context or Capability? Debugging Agentic Workflows**（ACM CAIS 2026 workshop）。[IBM 论文页面](https://research.ibm.com/publications/context-or-capability-debugging-agentic-workflows)。**用途**：区分上下文不足与能力不足、与 DAG 结构相关的干预。
18. **TraceCoder: A Trace-Driven Multi-Agent Framework for Automated Debugging of LLM-Generated Code**（2026；预印本）。[论文](https://arxiv.org/abs/2602.06875)。**用途**：跟踪与回滚的调试思想，范围偏代码生成而非网关。
19. **A Survey for LLM Agent Trajectory Analysis: From Failure Attribution to Enhancement**（IEEE Transactions on Software Engineering，2026）。[IEEE 入口](https://ieeexplore.ieee.org/document/11626967) / [文献清单](https://github.com/IcyFeather233/Awesome-LLM-Agent-Trajectory-Analysis)。**用途**：覆盖核心分类、评价方法和已发表工作，必须用它二次追新。

### B. AIOps、微服务追踪与根因定位：20–34

20. **OpenRCA: Can Large Language Models Locate the Root Cause of Software Failures?**（ICLR 2025）。[正式论文](https://proceedings.iclr.cc/paper_files/paper/2025/hash/d29b8d53678015079e1d245c023e49d2-Abstract-Conference.html)。**用途**：开放 RCA 评价、微服务多模态遥测。
21. **OpenRCA 2.0: From Outcome Labels to Causal Process Supervision**（2026；预印本）。[论文](https://arxiv.org/abs/2606.27154)。**用途**：因果传播路径的分步标注，避免“猜中服务”却无因果证据。
22. **RCAEval: A Benchmark for Root Cause Analysis of Microservice Systems with Telemetry Data**（WWW 2025 Companion；另有 arXiv 版本）。[论文](https://arxiv.org/abs/2412.17015) / [代码](https://github.com/phamquiluan/RCAEval)。**用途**：15 种以上经典对比方法与公开数据协议。
23. **Does Graph Structure Earn Its Place in Microservice Root-Cause Analysis? A Controlled Study on RCAEval, and What the Benchmark Was Really Measuring**（2026；预印本）。[论文](https://arxiv.org/abs/2609.27069)。**用途**：重要的负面证据；防止图模型收益其实来自标签先验或评估缺陷。
24. **MicroHECL: High-Efficient Root Cause Localization in Large-Scale Microservice Systems**（ICSE-SEIP 2021）。[论文](https://arxiv.org/abs/2103.01782)。**用途**：服务依赖传播、剪枝与快速候选定位。
25. **MicroRank: End-to-End Latency Issue Localization with Extended Spectrum Analysis in Microservice Environments**（WWW 2021）。[ACM DOI](https://doi.org/10.1145/3442381.3449905) / [代码](https://github.com/IntelligentDDS/MicroRank)。**用途**：正常/异常 trace 与 spectrum 分析。
26. **BARO: Robust Root Cause Analysis for Microservices via Multivariate Bayesian Online Change Point Detection**（Proceedings of the ACM on Software Engineering / FSE 2024）。[DOI](https://doi.org/10.1145/3660805)。**用途**：异常检测鲁棒性和统计变化点。
27. **Root Cause Analysis for Microservice System based on Causal Inference: How Far Are We?**（ASE 2024）。[论文关联仓库/引用](https://github.com/phamquiluan/RCAEval)。**用途**：检验因果算法在 RCA 上的可复制价值。
28. **AIOpsLab: A Holistic Framework to Evaluate AI Agents for Enabling Autonomous Clouds**（MLSys 2025）。[正式论文](https://openreview.net/forum?id=3EXBLwGxtq) / [代码](https://github.com/microsoft/AIOpsLab)。**用途**：云原生故障注入和 AIOps Agent 工程验证。
29. **Building AI Agents for Autonomous Clouds: Challenges and Design Principles**（SoCC 2024）。[作者项目与引文](https://github.com/microsoft/AIOpsLab)。**用途**：AgentOps 的问题界定及工程指标。
30. **Towards In-Depth Root Cause Localization for Microservices with Multi-Agent Recursion-of-Thought**（2026；预印本，RCLAgent）。[论文](https://arxiv.org/abs/2605.14866)。**用途**：传统服务根因分析的多 Agent 推理对照。
31. **How Far Can Root Cause Analysis Go on Real-World Telemetry Data?**（2026；预印本）。[论文](https://arxiv.org/abs/2607.13548)。**用途**：在真实遥测下验证模型/因果方法局限。
32. **Stalled, Biased, and Confused: Uncovering Reasoning Failures in LLMs for Cloud-Based Root Cause Analysis**（2026；预印本/另有 ACM DOI）。[论文](https://arxiv.org/abs/2601.22208)。**用途**：错误推理模式分类与真实 RCA 局限。
33. **Graph-Augmented Multi-Agent Robust Root Cause Analysis in AIOps**（2026；期刊论文）。[DOI](https://doi.org/10.32604/cmc.2026.077908)。**用途**：多模态遥测与图增强证据，需核对具体实验可比性。
34. **Dapper, a Large-Scale Distributed Systems Tracing Infrastructure**（Google 技术报告，2010）。[Google Research](https://research.google/pubs/dapper-a-large-scale-distributed-systems-tracing-infrastructure/)。**用途**：低侵入式链路追踪、采样与工程取舍的经典基础。

### C. Agent 基础、评估与风险：35–45

35. **τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains**（2024）。[论文](https://arxiv.org/abs/2406.12045)。**用途**：工具调用和状态目标评估，支持故障注入场景。
36. **AgentBoard: An Analytical Evaluation Board of Multi-turn LLM Agents**（NeurIPS 2024）。[论文](https://arxiv.org/abs/2401.13178)。**用途**：逐步状态和过程级评价体系。
37. **AgentBench: Evaluating LLMs as Agents**（ICLR 2024）。[论文](https://arxiv.org/abs/2308.03688)。**用途**：不同环境的 Agent 基础故障类别和 benchmark。
38. **R-Judge: Benchmarking Safety Risk Awareness for LLM Agents**（Findings of EMNLP 2024）。[ACL Anthology](https://aclanthology.org/2024.findings-emnlp.79/)。**用途**：日志风险审查，对接第三篇安全网关。
39. **AgentHarm: A Benchmark for Measuring Harmfulness of LLM Agents**（ICLR 2025）。[论文](https://arxiv.org/abs/2410.09024)。**用途**：关注多步骤工具执行的安全边界；与根因诊断并非相同任务。
40. **ReAct: Synergizing Reasoning and Acting in Language Models**（ICLR 2023）。[论文](https://arxiv.org/abs/2210.03629)。**用途**：交替推理—行动的执行轨迹基础。
41. **AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent Conversation**（COLM 2024）。[论文](https://arxiv.org/abs/2308.08155)。**用途**：多 Agent 消息链与事件关联；可作为负载生成框架。
42. **CORRECT 的扩展对照：Magentic-One: A Generalist Multi-Agent System for Solving Complex Tasks**（2024；预印本）。[论文](https://arxiv.org/abs/2411.04468)。**用途**：产生多 Agent 任务与长轨迹，区别于故障归因方法。
43. **AIOpsLab 相关基准扩展：RCAEval 后续 TORAI: Multi-source Root Cause Analysis for Blind Spots in Microservice Service Call Graph**（FSE 2026，仓库列为论文）。[作者项目/文献信息](https://github.com/phamquiluan/RCAEval)。**用途**：与本题“图的盲区/缺失”高度相关，正式引用前请从仓库取论文最终出版入口。
44. **AIOpsLab 相关基准扩展：EventADL: Open-Box Anomaly Detection and Localization Framework for Events in Cloud-Based Service Systems**（FSE 2026，仓库列为论文）。[作者项目/文献信息](https://github.com/phamquiluan/RCAEval)。**用途**：事件级异常与定位对照，正式引用需核对出版记录。
45. **Observability and Causal Tracing for Agentic Data Pipelines: Span Semantics, Replay, and Hops-To-Root-Cause**（2026；已发表文章；小规模合成实验）。[DOI](https://doi.org/10.56578/ataiml050305)。**用途**：Agent / MCP Span 的语义追踪；因样本规模较小，应谨慎解释其结论。

### 10.1 最优先阅读的 12 篇（从中立即形成 Related Work）

按以下顺序：**19 综述 → 7 Who&When → 1 AgentRx → 11 TraceElephant → 2 AgentTrace → 3 AgentEval → 13 CORRECT → 14 GraphTracer → 4 DoVer → 22 RCAEval → 23 图结构批判 → 34 Dapper**。

### 10.2 30 篇文献是否足够？

此处给出 **45 篇研究作品的检索入口**，足以做选题级初稿材料池；但不能机械地全部写进最终论文：发表形式不一，部分不够直接相关。最终 Related Work 建议分为 3 条主线，优先引用**正式同行评审版本**；而当涉及直接撞题的 2026 年预印本时，应合理讨论但明确其预印本状态。

---

## 11. 可复现性、隐私、伦理与失败风险清单

### 11.1 可复现性

- 公开数据集版本哈希、全部依赖锁定文件、实验随机种子、压测机器资源及批次。
- 数据集协议若禁止重分发原始日志，则只公开脱敏结构特征、生成器、拉取脚本与索引，不重新发布有版权或敏感的原始数据。
- 指标须公开计算脚本，尤其是对**多根因集合、不可恢复步骤、无答案的样本**的打分规范。
- 明确比较各方法是否使用了更丰富的“Agent 内部状态”，确保观测条件公平。

### 11.2 系统安全边界

- 不能默认记录明文提示词、API Key、Cookie、用户隐私和业务内容。
- 避免跨租户复用原始特征导致数据泄漏；日志保存和访问应受到权限、保留期与加密策略控制。
- 对 Agent 内部隐藏推理不作“能够完全观测”的假设；可观测证据不足时报告限制。
- 不允许仅凭统计异常触发删除、付款、重部署等危险“自动修复”。

### 11.3 最可能让投稿失败的 6 个问题

1. **新意不足**：重复 AgentRx + AgentTrace + OpenTelemetry 的能力，而无明确新研究问题。
2. **强基线缺失**：只对比最后错误/随机算法，不和近期真正竞争方法比较。
3. **不公平采集**：新算法拿到更多隐藏信息、或者只计算推断成本不计算日志成本。
4. **数据泄漏**：同一生成模板出现在训练/测试，导致模型学到了注入位置而不是根因。
5. **因果概念滥用**：时间先后/图边被错误描述为因果证据。
6. **无在线性能验证**：声称高性能网关，但只有离线 notebook 的推断耗时。

---

## 12. 正式立项前的 Go / No-Go 检查单

- [ ] 已阅读至少 8 篇直接竞争研究，完成可操作的差异矩阵。
- [ ] 已取得至少 2 组可运行轨迹，并核对许可证与根因标签定义。
- [ ] 已明确“故障症状 / 首个不可恢复步骤 / 干预根因”之间差别。
- [ ] 最小网关能正确串联 trace_id、parent_span_id 和 tool call。
- [ ] 已建立 Last Error、First Error、规则、全日志 LLM、无训练图方法等基线。
- [ ] 已定义固定采集预算，并能测日志字节、CPU、P95 延迟和 Token。
- [ ] 已实现完整观测/部分观测两种数据协议。
- [ ] 已在至少一个 OOD 分组上跑出可信消融。
- [ ] 已进行置信度校准并保留弃权率。
- [ ] 已查清目标期刊**实际投稿当日**的 SCIE 收录、出版路线、费用和是否有特殊文章类型限制。

**立项结论**：建议学弟优先做「**低采集预算条件下的证据感知 Agent 故障定位**」这一**小而明确**的问题。若第一轮预实验显示图和信息选择并没有真实增益，立即转向更具可证伪性的「网关隐私约束下的可观测性边界测量」，也可以形成严谨的负面/经验研究，而不是强行声称算法创新。

---

## 附录 A. 期刊与行业资料的核验入口（非论文，不计入上述 45 篇）

- Clarivate Master Journal List：https://mjl.clarivate.com/
- Elsevier 投稿与费用说明：https://www-prod.elsevier.com/publishing/publish-in-a-journal/journal-selection
- Elsevier 订阅/OA 政策：https://www.elsevier.support/publishing/answer/which-open-access-options-are-available
- OpenTelemetry 项目：https://opentelemetry.io/docs/
- IEEE TSE 2026 轨迹研究综述资料库：https://github.com/IcyFeather233/Awesome-LLM-Agent-Trajectory-Analysis
- RCAEval benchmark：https://github.com/phamquiluan/RCAEval
- Microsoft AgentRx：https://github.com/microsoft/AgentRx
- Microsoft AIOpsLab：https://github.com/microsoft/AIOpsLab

**版本说明**：第五篇研究立项版，2026-10-20。包含论文研究方案与文献检索，不包含程序代码或实验结果；所有拟创新点须通过复现实验验证，不能视为现有已实现成果。
