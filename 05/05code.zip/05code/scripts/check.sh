#!/bin/sh
# Run from any working directory. No dependency download required.
set -eu
cd "$(dirname "$0")/.."
python3 -m unittest discover -s tests -v
go test ./...
go test -race ./...
go vet ./...
python3 -m benchmarks.run_eval --cases 8 --output results/check.json
printf 'PASS: tests, Go vet, synthetic benchmark\n'
