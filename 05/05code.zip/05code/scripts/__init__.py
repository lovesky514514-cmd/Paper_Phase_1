"""User-facing command-line examples."""
