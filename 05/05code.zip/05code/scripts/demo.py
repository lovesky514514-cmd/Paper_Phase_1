"""Build and run localhost-only Go components, then run Python diagnostics."""

import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = 'http://127.0.0.1:8955'


def wait_healthy(seconds=10):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(BASE + '/healthz', timeout=.5) as resp:
                if resp.status == 200:
                    return
        except (OSError, urllib.error.URLError):
            time.sleep(.1)
    raise RuntimeError('Go gateway did not become healthy; check port conflicts')


def call(step, fault='', parent=''):
    request = urllib.request.Request(
        BASE + '/v1/tool/' + step, data=b'{"synthetic":true}', method='POST',
        headers={'Content-Type':'application/json', 'X-Trace-ID':'synthetic-demo',
                 'X-Span-ID':step, 'X-Parent-Span-ID':parent,
                 'X-Sandbox-Fault':fault})
    try:
        with urllib.request.urlopen(request, timeout=4) as resp:
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code


def main():
    output = ROOT / 'results' / 'gateway_spans.jsonl'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.unlink(missing_ok=True)
    with tempfile.TemporaryDirectory(prefix='tracelite-build-') as tmp:
        ext = '.exe' if os.name == 'nt' else ''
        binaries = []
        for name in ('mocktool', 'tracelite'):
            path = str(Path(tmp) / (name + ext))
            subprocess.run(['go', 'build', '-o', path, './cmd/' + name], cwd=ROOT, check=True)
            binaries.append(path)
        procs = []
        try:
            procs.append(subprocess.Popen([binaries[0]], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE))
            procs.append(subprocess.Popen([binaries[1], '-log', str(output)], cwd=ROOT,
                                          stdout=subprocess.DEVNULL, stderr=subprocess.PIPE))
            wait_healthy()
            # Guard against a stale server satisfying /healthz after new bind failed.
            time.sleep(.2)
            if any(p.poll() is not None for p in procs):
                raise RuntimeError('Tool or gateway exited early; check port 8955/8956')
            for step, fault, parent in [('read', 'stale', ''), ('plan', '', 'read'), ('write', 'denied', 'plan')]:
                status = call(step, fault, parent)
                print(f'{step}: HTTP {status}')
        finally:
            # Go receives SIGTERM and flushes its buffered span writer.
            for p in reversed(procs):
                if p.poll() is None:
                    p.terminate()
            for p in reversed(procs):
                try: p.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    p.kill(); p.communicate()
    if not output.exists():
        raise RuntimeError('No spans persisted; see docs/troubleshooting.md')
    subprocess.run([sys.executable, '-m', 'scripts.analyze', str(output)],
                   cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
