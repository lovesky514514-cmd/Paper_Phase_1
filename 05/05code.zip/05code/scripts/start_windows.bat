@echo off
setlocal
cd /d "%~dp0.."
where py >nul 2>nul
if %errorlevel%==0 (set "PYCMD=py -3") else (set "PYCMD=python")
%PYCMD% -m scripts.demo
if errorlevel 1 echo FAIL: see docs\troubleshooting.md
pause
