"""Diagnose a gateway JSONL export without inventing ground-truth labels."""

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from tracelite import collect, diagnose
from tracelite.io import load_spans, split_traces


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path', help='metadata-only JSONL from the Go gateway')
    parser.add_argument('--budget', type=int, default=480)
    parser.add_argument('--out', default='results/diagnosis.json')
    args = parser.parse_args()
    traces = split_traces(load_spans(args.path))
    reports = []
    for case in traces.values():
        view = collect(case, args.budget)
        report = diagnose(view, case.trace_id, temperature=1.0)
        reports.append(asdict(report))
        print(f'{case.trace_id}: {report.selected or "ABSTAIN"} ({report.reason})')
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Diagnostic suggestions: {path} (not causal proofs)')


if __name__ == '__main__':
    main()
