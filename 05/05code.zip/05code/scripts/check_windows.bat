@echo off
setlocal
cd /d "%~dp0.."
where go >nul 2>nul || (echo Install Go 1.22+ & pause & exit /b 1)
where py >nul 2>nul
if %errorlevel%==0 (set "PYCMD=py -3") else (set "PYCMD=python")
%PYCMD% --version || goto fail
go test ./... || goto fail
go vet ./... || goto fail
%PYCMD% -m unittest discover -s tests -v || goto fail
%PYCMD% -m benchmarks.run_eval --cases 8 --output results/check.json || goto fail
echo PASS: all automated checks completed.
pause
exit /b 0
:fail
echo FAIL: see docs\troubleshooting.md
pause
exit /b 1
