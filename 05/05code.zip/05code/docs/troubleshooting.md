# 常见故障与修复

| 报错 / 现象 | 原因排查 | 处理 |
|---|---|---|
| `python` / `go` 找不到 | 运行环境 PATH 缺失 | 安装 Python 3.11+、Go 1.22+，关闭终端重新打开 |
| `No module named tracelite` | 当前目录错误 | 先切换到解压后的 `05code` 根目录，再用 `python -m ...` 运行 |
| 8955 / 8956 端口占用 | 旧进程没有退出 | 结束先前的 demo 进程，确认本地端口空闲 |
| Go `build` 或 `test` 失败 | Go 版本/本地缓存损坏 | `go version`、`go clean -cache` 后重试；保留第一条原始报错 |
| 没有 JSONL | HTTP 请求未发出，或进程提前退出 | 运行 `python -m scripts.demo` 并查看 `results/gateway_spans.jsonl` |
| `/healthz` 显示 dropped_spans > 0 | 异步证据缓冲满 | 降低本地请求速率、改善磁盘写入；**不得**把缺失 Span 视作不存在异常 |
| 诊断为 `ABSTAIN` | 证据太少、温度/阈值保守 | 增加只读核验、采集预算；**不要**直接在危险工具上重试 |
| 校验失败却返回 200 | HTTP 200 不代表业务校验通过 | 检查 JSONL 的 `validation` 字段和 `docs/DESIGN.md` |
| `Invalid JSONL Span` | 轨迹格式不匹配/断行/多余字段 | 按 `tracelite/model.py` 提供字段，不要把 oracle 混入运行日志 |
| Windows 脚本乱码 | 系统控制台编码 | bat 的提示均用 ASCII；中文 MD 用 UTF-8 阅读 |
| 统计结果与样例不同 | 种子、Python 版本、预算不同 | 固定 `--seed 17 --cases 8 --budget 200 --missing 0.2`；计时值可波动 |

源码级定位见 `docs/DEBUG_INDEX.md`；每份程序/脚本均有对应的文件级排错页。

若 `go test -race` 报 CGO/编译器相关错误，先确认本机 C 编译环境；普通 `go test` 不能替代竞态测试，报告时如实标记竞态测试未执行。
