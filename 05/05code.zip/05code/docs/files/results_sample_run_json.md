# 排错：`results/sample_run.json`

**作用：**Reproducible synthetic result/sample。修改前先确认路径正确，保留原始报错。

**自检命令：** `python -m benchmarks.run_eval --output results/check.json`

**出现异常时：** Check seed and budget in metadata. Do not treat generated data as real-world evidence.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
