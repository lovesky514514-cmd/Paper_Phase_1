# 排错：`scripts/check_windows.bat`

**作用：**Windows launch or check script。修改前先确认路径正确，保留原始报错。

**自检命令：** `scripts\check_windows.bat`

**出现异常时：** Use a Windows command prompt; check py/python/go are on PATH and avoid non-ASCII console output.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
