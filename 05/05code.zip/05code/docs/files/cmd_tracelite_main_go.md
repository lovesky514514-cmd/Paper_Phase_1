# 排错：`cmd/tracelite/main.go`

**作用：**Go gateway, mock tool or test。修改前先确认路径正确，保留原始报错。

**自检命令：** `go test ./... && go vet ./...`

**出现异常时：** Check Go 1.22+, read the first compiler error, then rerun gofmt and race tests.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
