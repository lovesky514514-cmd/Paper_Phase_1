# 排错：`research/05_original.md`

**作用：**Project documentation。修改前先确认路径正确，保留原始报错。

**自检命令：** `Open the file in a UTF-8 Markdown viewer`

**出现异常时：** If a path or command is stale, compare with README and actual files; fix the documentation only after verifying the command.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
