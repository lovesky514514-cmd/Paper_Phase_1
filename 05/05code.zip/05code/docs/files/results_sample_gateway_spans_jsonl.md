# 排错：`results/sample_gateway_spans.jsonl`

**作用：**Sanitized sandbox recording。修改前先确认路径正确，保留原始报错。

**自检命令：** `python -m scripts.analyze results/sample_gateway_spans.jsonl`

**出现异常时：** Verify one JSON object per line. If IDs/fields are missing, reproduce with scripts.demo.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
