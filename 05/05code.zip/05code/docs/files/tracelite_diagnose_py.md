# 排错：`tracelite/diagnose.py`

**作用：**Python module or CLI。修改前先确认路径正确，保留原始报错。

**自检命令：** `python -m unittest discover -s tests -v`

**出现异常时：** Check the traceback at the relevant function; confirm the working directory is 05code and rerun with the fixed seed.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
