# 排错：`.gitignore`

**作用：**Ignore rules。修改前先确认路径正确，保留原始报错。

**自检命令：** `git status --short`

**出现异常时：** Check excluded files are caches, secret logs and local outputs; never publish private API keys.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
