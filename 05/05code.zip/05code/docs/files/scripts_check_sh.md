# 排错：`scripts/check.sh`

**作用：**POSIX launch or check script。修改前先确认路径正确，保留原始报错。

**自检命令：** `sh scripts/check.sh`

**出现异常时：** Run from a terminal, check executable permissions and that python3/go are on PATH.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
