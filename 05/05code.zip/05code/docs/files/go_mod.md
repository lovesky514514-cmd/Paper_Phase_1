# 排错：`go.mod`

**作用：**Go module definition。修改前先确认路径正确，保留原始报错。

**自检命令：** `go test ./...`

**出现异常时：** Update the minimum Go version only after running tests under the requested supported version.

**复验：** 修复后先运行上述命令，再运行 `sh scripts/check.sh`；涉及 Go 请求时额外跑 `python -m scripts.demo`。
