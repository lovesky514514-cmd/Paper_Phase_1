# 设计说明

## 核心数据流

`Agent / 工具请求 → Go 本地网关 → 固定本地工具沙箱 → 脱敏 Span(JSONL)`

`Span(JSONL) → Python 两阶段采样 → 依赖证据图 → 排序 → 校准与弃权 → 诊断建议`

Go 与 Python 按数据格式连接，不通过 Python 故障来决定是否转发业务请求。

## 两层观测，不泄漏真值

第一层是所有策略共享的廉价元信息；第二层是通过预算选择的工具校验摘要。选择策略只读取第一层，绝不读取 `first_irrecoverable`、`injected_at` 等标签，也不以隐藏的校验文本长度改变采样优先级。

选择前为每条证据保留 160 字节固定信封；实际 `used_bytes` 是 JSON 摘要的 UTF-8 长度。超过信封的校验记录报错，避免默默截断。**预算只包括第二层数据**；比较完整开销需另外计入元信息、网络与固定缓冲。

## 安全边界

Go：工具列表固定、上游地址必须是 `http://127.0.0.1:<port>`，请求和响应有大小限制；不转发原始 Authorization、Cookie；JSONL 保存为 0600 权限、只含标识符与响应统计，不含业务正文。异步队列满时丢 Span 并计数；诊断不可用不会阻断数据面。

**限制**：Go 从模拟工具响应头取得的校验状态没有外部签名，不构成“独立验证”；HTTP 502 对写入是否已提交保持未知，不自动重试；日志仍含相关标识符，需要本机隔离、权限控制与定期清理。跨机器/跨租户和真实 MCP SDK 适配尚未完成。

Python：依赖图只代表记录到的前驱或相关关系，不自称证明因果。温度在独立模板的验证集拟合；证据缺失或信心不足会弃权。系统仅提出只读沙箱检查建议，没有任何自动支付、删除、修改权限或写库修复功能。

## 接口

`POST http://127.0.0.1:8955/v1/tool/{read|plan|write}`，可选 `X-Trace-ID`、`X-Span-ID`、`X-Parent-Span-ID`、`X-Dependency-IDs`；`X-Sandbox-Fault` 仅供本地注入演示。

`GET /healthz` 返回 `accepted_spans` 和 `dropped_spans`。JSONL schema 在 `tracelite/model.py` 与 `gateway/record.go`；这些字段**不是 MCP/OTel 原生规范的完整实现**。
