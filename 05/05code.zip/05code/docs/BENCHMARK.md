# 实验协议与公平性

运行：`python -m benchmarks.run_eval --seed 17 --cases 8 --budget 200 --missing 0.2 --output results/last_run.json`

- 9 个合成任务族，每族固定种子生成 8 条轨迹（包括健康流程）。当前示范将 2 个完整模板用于温度验证、4 个独立模板用于测试，剩余 3 个未用于拟合；**不是对真实 Agent 数据集的评测**。
- 故障包含 HTTP 429/403/503、缓存过时、schema/plan/消息/状态问题、网络延时和恢复过的非根因异常；一条轨迹可能有两个注入故障，只有实验 oracle 定义“首个不可恢复步骤”。
- 对照：`last_error`、`first_error`、`status_only`、`uniform`、`random`、`adaptive`、`no_graph`、`full_capture`、`no_abstain`。以上是工程近似基线/消融，**不是 AgentRx/Who&When/GraphTracer 等论文复现**。
- 所有同预算策略看到一样的基础元信息，预算仅覆盖可选校验摘要，`full_capture` 是明确超预算的上界而不是同预算对手。`no_abstain` 强制输出是消融。
- Top-1 和 Top-3 在故障轨迹上计算，含弃权时 Top-1 为“候选排序准确率”，`answered_accuracy` 只评估非弃权样本且必须联合报告 `coverage`。对健康场景报告无故障却报告根因的次数。
- CI 用逐轨迹配对 bootstrap（同一随机种子的相同轨迹），不是逐 Span 重新取样。温度选择仅在独立验证模板进行。纯规则基线没有有效预测概率，ECE/Brier 标记为 null。
- `latency_us` 仅是 Python 单次排序计时，不代表在线网关 P95。未测 QPS、GPU、真实 LLM/OTel 开销、不同故障的真实分布迁移或人员排障时间。

缺少的正式论文实验：多随机种子、多源公开真实轨迹、AgentRx/Who&When 等忠实强基线、全量采样预算口径、真实 Agent 在线采集、跨工作流 OOD、消融及人工干预验证。不能凭本地测试宣称 SCI 论文效果。

批量曲线原始数据：`python -m benchmarks.matrix --output results/matrix.json`，覆盖 3 组种子 × 4 个附加证据预算 × 5 个缺失比例 × 5 个策略，输出 300 个策略-工况点。请先检查各组差异，再生成科研图；不要只挑最好的种子。
