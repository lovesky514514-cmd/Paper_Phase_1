// tracelite is a localhost-only observational gateway for synthetic tools.
package main

import (
	"context"
	"flag"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"tracelite-rca/gateway"
)

func main() {
	listen := flag.String("listen", "127.0.0.1:8955", "local gateway address")
	upstream := flag.String("upstream", "http://127.0.0.1:8956", "trusted local mock tool URL")
	output := flag.String("log", "results/gateway_spans.jsonl", "private metadata-only JSONL")
	flag.Parse()
	host, _, err := net.SplitHostPort(*listen)
	if err != nil || host != "127.0.0.1" {
		log.Fatal("local demo must listen on 127.0.0.1")
	}
	recorder, err := gateway.NewRecorder(*output, 1024)
	if err != nil {
		log.Fatal(err)
	}
	proxy, err := gateway.NewProxy(*upstream, recorder)
	if err != nil {
		log.Fatal(err)
	}
	server := &http.Server{Addr: *listen, Handler: proxy, ReadHeaderTimeout: 3 * time.Second}
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-done
		ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
		defer cancel()
		_ = server.Shutdown(ctx)
	}()
	log.Printf("TraceLite local gateway listening on %s", *listen)
	err = server.ListenAndServe()
	if err != nil && err != http.ErrServerClosed {
		log.Printf("gateway error: %v", err)
	}
	if closeErr := recorder.Close(); closeErr != nil {
		log.Printf("writer error: %v", closeErr)
	}
}
