// mocktool never touches external services or real customer data.
package main

import (
	"encoding/json"
	"flag"
	"log"
	"net"
	"net/http"
	"time"
)

func handler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405)
		return
	}
	fault := r.Header.Get("X-Sandbox-Fault")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Sandbox-Check-schema", "pass")
	w.Header().Set("X-Sandbox-Check-freshness", "pass")
	w.Header().Set("X-Sandbox-Check-state", "pass")
	switch fault {
	case "stale":
		w.Header().Set("X-Sandbox-Check-freshness", "fail")
	case "schema":
		w.Header().Set("X-Sandbox-Check-schema", "fail")
	case "state":
		w.Header().Set("X-Sandbox-Check-state", "fail")
	case "denied":
		w.WriteHeader(403)
	case "busy":
		w.WriteHeader(429)
	case "error":
		w.WriteHeader(503)
	case "slow":
		time.Sleep(1300 * time.Millisecond)
	}
	_ = json.NewEncoder(w).Encode(map[string]string{"kind": "synthetic", "tool": r.URL.Path})
}

func main() {
	listen := flag.String("listen", "127.0.0.1:8956", "local sandbox address")
	flag.Parse()
	host, _, err := net.SplitHostPort(*listen)
	if err != nil || host != "127.0.0.1" {
		log.Fatal("local demo must listen on 127.0.0.1")
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/tool/read", handler)
	mux.HandleFunc("/v1/tool/plan", handler)
	mux.HandleFunc("/v1/tool/write", handler)
	log.Fatal(http.ListenAndServe(*listen, mux))
}
