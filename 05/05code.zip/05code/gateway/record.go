// Package gateway forwards local test tool calls and writes metadata-only spans.
package gateway

import (
	"bufio"
	"encoding/json"
	"errors"
	"os"
	"sync"
	"sync/atomic"
)

// Span contains only identifiers and observations, never request/response bodies.
// Headers containing validation assertions are not inherently trusted evidence.
type Span struct {
	TraceID           string            `json:"trace_id"`
	SpanID            string            `json:"span_id"`
	ParentSpanID      *string           `json:"parent_span_id"`
	DependencyIDs     []string          `json:"dependency_ids"`
	TimeNS            int64             `json:"time_ns"`
	ActorID           string            `json:"actor_id"`
	Operation         string            `json:"operation"`
	StatusCode        int               `json:"status_code"`
	LatencyMS         int               `json:"latency_ms"`
	Validation        map[string]string `json:"validation"`
	ObservabilityMask []string          `json:"observability_mask"`
}

// Recorder isolates gateway latency from disk writes; congestion drops spans.
// Its caller must stop HTTP serving before calling Close.
type Recorder struct {
	file     *os.File
	channel  chan Span
	done     chan struct{}
	dropped  atomic.Uint64
	accepted atomic.Uint64
	errMu    sync.Mutex
	writeErr error
}

func NewRecorder(path string, capacity int) (*Recorder, error) {
	if capacity < 1 {
		return nil, errors.New("capacity must be positive")
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0600)
	if err != nil {
		return nil, err
	}
	if err := f.Chmod(0600); err != nil {
		_ = f.Close()
		return nil, err
	}
	r := &Recorder{file: f, channel: make(chan Span, capacity), done: make(chan struct{})}
	go r.writeLoop()
	return r, nil
}

func (r *Recorder) writeLoop() {
	defer close(r.done)
	writer := bufio.NewWriter(r.file)
	for span := range r.channel {
		if err := json.NewEncoder(writer).Encode(span); err != nil {
			r.errMu.Lock()
			r.writeErr = err
			r.errMu.Unlock()
		}
	}
	if err := writer.Flush(); err != nil {
		r.errMu.Lock()
		r.writeErr = err
		r.errMu.Unlock()
	}
}

func (r *Recorder) Emit(s Span) {
	select {
	case r.channel <- s:
		r.accepted.Add(1)
	default:
		r.dropped.Add(1)
	}
}

func (r *Recorder) Stats() (uint64, uint64) {
	return r.accepted.Load(), r.dropped.Load()
}

func (r *Recorder) Close() error {
	close(r.channel)
	<-r.done
	r.errMu.Lock()
	err := r.writeErr
	r.errMu.Unlock()
	if closeErr := r.file.Close(); err == nil {
		err = closeErr
	}
	return err
}
