package gateway

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
)

func testGateway(t *testing.T, tool http.Handler) (*Proxy, *Recorder, string, func()) {
	t.Helper()
	server := httptest.NewServer(tool)
	path := filepath.Join(t.TempDir(), "spans.jsonl")
	recorder, err := NewRecorder(path, 4096)
	if err != nil {
		t.Fatal(err)
	}
	// httptest uses 127.0.0.1 by default.
	proxy, err := NewProxy(server.URL, recorder)
	if err != nil {
		t.Fatal(err)
	}
	return proxy, recorder, path, server.Close
}

func TestRejectsUnexpectedUpstreams(t *testing.T) {
	for _, s := range []string{"https://127.0.0.1:9", "http://example.com:80", "http://127.0.0.1:9/path", "file:///etc/passwd", "http://127.0.0.1:9?q=1"} {
		if _, err := NewProxy(s, nil); err == nil {
			t.Errorf("accepted %q", s)
		}
	}
}

func TestValidCallEmitsMetadataOnly(t *testing.T) {
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "" || r.Header.Get("Cookie") != "" {
			t.Error("credentials forwarded")
		}
		w.Header().Set("X-Sandbox-Check-freshness", "fail")
		_, _ = w.Write([]byte(`{"private":"password-secret"}`))
	})
	p, recorder, path, stop := testGateway(t, handler)
	defer stop()
	req := httptest.NewRequest("POST", "/v1/tool/read", bytes.NewBufferString(`{"secret":"dont-log-me"}`))
	req.Header.Set("Authorization", "Bearer secret-token")
	req.Header.Set("Cookie", "session=private")
	req.Header.Set("X-Trace-ID", "trace-A")
	req.Header.Set("X-Span-ID", "fetch")
	rr := httptest.NewRecorder()
	p.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("status=%d", rr.Code)
	}
	if err := recorder.Close(); err != nil {
		t.Fatal(err)
	}
	saved, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(saved), "password-secret") || strings.Contains(string(saved), "dont-log-me") || strings.Contains(string(saved), "secret-token") {
		t.Fatal("secret leaked to trace")
	}
	var s Span
	if err := json.Unmarshal(bytes.TrimSpace(saved), &s); err != nil {
		t.Fatal(err)
	}
	if s.TraceID != "trace-A" || s.SpanID != "fetch" || s.Validation["freshness"] != "fail" {
		t.Fatalf("bad span: %+v", s)
	}
	if s.ObservabilityMask[0] != "body_redacted" {
		t.Fatal("missing privacy mask")
	}
}

func TestUnknownToolRejectedWithoutForwarding(t *testing.T) {
	calls := 0
	p, recorder, _, stop := testGateway(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls++ }))
	defer stop()
	defer recorder.Close()
	rr := httptest.NewRecorder()
	p.ServeHTTP(rr, httptest.NewRequest("POST", "/v1/tool/unknown", nil))
	if rr.Code != 404 || calls != 0 {
		t.Fatal(rr.Code, calls)
	}
}

func TestTooLargeInputNeverExecutesTool(t *testing.T) {
	calls := 0
	p, recorder, _, stop := testGateway(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls++ }))
	defer stop()
	defer recorder.Close()
	rr := httptest.NewRecorder()
	p.ServeHTTP(rr, httptest.NewRequest("POST", "/v1/tool/write", strings.NewReader(strings.Repeat("x", maxBytes+1))))
	if rr.Code != 413 || calls != 0 {
		t.Fatal(rr.Code, calls)
	}
}

func TestConcurrentCallsAreAuditable(t *testing.T) {
	p, recorder, path, stop := testGateway(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { _, _ = io.WriteString(w, `{"ok":true}`) }))
	defer stop()
	var wg sync.WaitGroup
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			rr := httptest.NewRecorder()
			p.ServeHTTP(rr, httptest.NewRequest("POST", "/v1/tool/read", bytes.NewBufferString(`{}`)))
			if rr.Code != 200 {
				t.Errorf("status %d", rr.Code)
			}
		}()
	}
	wg.Wait()
	if err := recorder.Close(); err != nil {
		t.Fatal(err)
	}
	content, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if lines := bytes.Count(content, []byte("\n")); lines != 50 {
		t.Fatalf("got %d of 50", lines)
	}
}

func TestRecorderPermissions(t *testing.T) {
	path := filepath.Join(t.TempDir(), "private.jsonl")
	r, err := NewRecorder(path, 3)
	if err != nil {
		t.Fatal(err)
	}
	if err := r.Close(); err != nil {
		t.Fatal(err)
	}
	stat, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if stat.Mode().Perm()&0077 != 0 {
		t.Fatal("trace readable by group/other")
	}
}
