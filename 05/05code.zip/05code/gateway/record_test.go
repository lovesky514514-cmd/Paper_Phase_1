package gateway

import (
	"os"
	"path/filepath"
	"testing"
)

func TestRecorderRejectsZeroBuffer(t *testing.T) {
	if _, err := NewRecorder(filepath.Join(t.TempDir(), "x"), 0); err == nil {
		t.Fatal("wanted error")
	}
}

func TestRecorderCountsEmittedSpans(t *testing.T) {
	r, err := NewRecorder(filepath.Join(t.TempDir(), "x"), 1)
	if err != nil {
		t.Fatal(err)
	}
	r.Emit(Span{TraceID: "T1", SpanID: "A"})
	accepted, dropped := r.Stats()
	if accepted+dropped != 1 {
		t.Fatal("inaccurate counters")
	}
	if err := r.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestRecorderFixesExistingLoosePermissions(t *testing.T) {
	path := filepath.Join(t.TempDir(), "existing.jsonl")
	if err := os.WriteFile(path, []byte(""), 0666); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(path, 0666); err != nil {
		t.Fatal(err)
	}
	recorder, err := NewRecorder(path, 2)
	if err != nil {
		t.Fatal(err)
	}
	if err := recorder.Close(); err != nil {
		t.Fatal(err)
	}
	stat, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if stat.Mode().Perm()&0077 != 0 {
		t.Fatalf("leaked access: %o", stat.Mode().Perm())
	}
}
