package gateway

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

const maxBytes = 64 << 10

var safeID = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,80}$`)
var permitted = map[string]bool{"read": true, "plan": true, "write": true}

// Proxy only forwards to a preconfigured upstream; caller input cannot set the host.
type Proxy struct {
	base   *url.URL
	client *http.Client
	logger *Recorder
}

func NewProxy(upstream string, logger *Recorder) (*Proxy, error) {
	base, err := url.Parse(upstream)
	if err != nil || base.Scheme != "http" || base.Hostname() != "127.0.0.1" || base.Port() == "" || base.User != nil || base.RawQuery != "" || base.Fragment != "" || base.Path != "" {
		return nil, &url.Error{Op: "validate", URL: upstream, Err: http.ErrNotSupported}
	}
	if logger == nil {
		return nil, &url.Error{Op: "validate", URL: upstream, Err: http.ErrNotSupported}
	}
	return &Proxy{base: base, logger: logger, client: &http.Client{Timeout: 3 * time.Second}}, nil
}

func id(v string) string {
	if safeID.MatchString(v) {
		return v
	}
	b := make([]byte, 8)
	if _, err := rand.Read(b); err != nil {
		return "generated"
	}
	return hex.EncodeToString(b)
}

func parent(s string) *string {
	if !safeID.MatchString(s) {
		return nil
	}
	return &s
}

func statusCheck(v string) string {
	if v == "pass" || v == "fail" {
		return v
	}
	return "unknown"
}

func (p *Proxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path == "/healthz" {
		ok, dropped := p.logger.Stats()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]uint64{"accepted_spans": ok, "dropped_spans": dropped})
		return
	}
	tool := strings.TrimPrefix(r.URL.Path, "/v1/tool/")
	if !permitted[tool] || !strings.HasPrefix(r.URL.Path, "/v1/tool/") || r.Method != http.MethodPost {
		http.Error(w, "unknown tool or method", http.StatusNotFound)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "payload too large", http.StatusRequestEntityTooLarge)
		return
	}

	traceID := id(r.Header.Get("X-Trace-ID"))
	spanID := id(r.Header.Get("X-Span-ID"))
	started := time.Now()
	target := p.base.String() + "/v1/tool/" + tool
	outbound, err := http.NewRequestWithContext(r.Context(), http.MethodPost, target, strings.NewReader(string(body)))
	if err != nil {
		http.Error(w, "invalid internal request", 500)
		return
	}
	outbound.Header.Set("Content-Type", "application/json")
	// Restrictive allowlist: no Authorization, Cookie, or arbitrary headers.
	if fault := r.Header.Get("X-Sandbox-Fault"); len(fault) < 32 {
		outbound.Header.Set("X-Sandbox-Fault", fault)
	}
	response, err := p.client.Do(outbound)
	status := http.StatusBadGateway
	validation := map[string]string{}
	var responseBody []byte
	if err == nil {
		defer response.Body.Close()
		responseBody, err = io.ReadAll(io.LimitReader(response.Body, maxBytes+1))
		if err == nil && len(responseBody) <= maxBytes {
			status = response.StatusCode
			for _, k := range []string{"schema", "freshness", "state"} {
				validation[k] = statusCheck(response.Header.Get("X-Sandbox-Check-" + k))
			}
		}
	}
	if err != nil || len(responseBody) > maxBytes {
		// A 502 cannot establish whether a write was committed; never auto-retry.
		status = http.StatusBadGateway
		responseBody = []byte(`{"error":"upstream unavailable or response too large"}`)
	}
	deps := []string{}
	for _, dep := range strings.Split(r.Header.Get("X-Dependency-IDs"), ",") {
		dep = strings.TrimSpace(dep)
		if safeID.MatchString(dep) && len(deps) < 16 {
			deps = append(deps, dep)
		}
	}
	p.logger.Emit(Span{traceID, spanID, parent(r.Header.Get("X-Parent-Span-ID")), deps,
		started.UnixNano(), tool, tool, status, int(time.Since(started).Milliseconds()),
		validation, []string{"body_redacted", "reasoning_hidden"}})
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Trace-ID", traceID)
	w.Header().Set("X-Span-ID", spanID)
	w.WriteHeader(status)
	_, _ = w.Write(responseBody)
}
