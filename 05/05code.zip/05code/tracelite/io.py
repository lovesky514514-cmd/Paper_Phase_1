"""Strict JSONL exchange; excludes oracle truth from production records."""

import json
from dataclasses import asdict
from pathlib import Path

from .model import Span, TraceCase


def load_spans(path: str | Path) -> tuple[Span, ...]:
    result = []
    for number, line in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
            item['dependency_ids'] = tuple(item.get('dependency_ids', ()))
            item['observability_mask'] = tuple(item.get('observability_mask', ()))
            item['validation'] = item.get('validation', {})
            result.append(Span(**item))
        except (TypeError, ValueError, KeyError) as exc:
            raise ValueError(f'Invalid JSONL Span on line {number}: {exc}') from exc
    return tuple(result)


def save_spans(path: str | Path, spans: tuple[Span, ...]) -> None:
    with Path(path).open('w', encoding='utf-8') as stream:
        for span in spans:
            stream.write(json.dumps(asdict(span), ensure_ascii=False, separators=(',', ':')) + '\n')


def split_traces(spans: tuple[Span, ...]) -> dict[str, TraceCase]:
    groups: dict[str, list[Span]] = {}
    for span in spans:
        groups.setdefault(span.trace_id, []).append(span)
    # No fake oracle label from gateway observations.
    return {name: TraceCase(name, 'unknown', tuple(sorted(group, key=lambda x: x.time_ns)),
                            None, ()) for name, group in groups.items()}
