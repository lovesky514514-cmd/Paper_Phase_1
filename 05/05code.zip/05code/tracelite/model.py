"""TraceLite-RCA's stable observation contract (not an MCP-native schema)."""

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True)
class Span:
    trace_id: str
    span_id: str
    parent_span_id: str | None
    dependency_ids: tuple[str, ...]
    time_ns: int
    actor_id: str
    operation: str
    status_code: int
    latency_ms: int
    validation: dict[str, str] = field(default_factory=dict)
    observability_mask: tuple[str, ...] = ()

    @property
    def abnormal(self) -> bool:
        # A 200 does not establish that the business state is correct.
        return self.status_code >= 400 or self.latency_ms >= 1200


@dataclass(frozen=True)
class TraceCase:
    trace_id: str
    template: str
    spans: tuple[Span, ...]
    # Oracle labels are stored *only* on the evaluation object.
    first_irrecoverable: str | None
    intervention_roots: tuple[str, ...]
    injected_at: tuple[str, ...] = ()


@dataclass(frozen=True)
class Evidence:
    span_id: str
    validation: dict[str, str]
    byte_cost: int
    source: Literal['tool_response', 'sandbox', 'external_check'] = 'tool_response'


@dataclass(frozen=True)
class Observation:
    spans: tuple[Span, ...]
    evidence: tuple[Evidence, ...]
    used_bytes: int
    budget_bytes: int
    missing_span_ids: tuple[str, ...]


@dataclass(frozen=True)
class Candidate:
    span_id: str
    score: float
    confidence: float
    evidence: tuple[str, ...]
    missing_evidence: tuple[str, ...]


@dataclass(frozen=True)
class Diagnosis:
    trace_id: str
    candidates: tuple[Candidate, ...]
    selected: str | None
    abstained: bool
    reason: str
    used_bytes: int
    missing_span_ids: tuple[str, ...]
    next_check: str | None
