"""Evidence-graded root-cause candidates; correlations are not causal proofs."""

import math
from dataclasses import replace

from .model import Candidate, Diagnosis, Observation


def _softmax(scores: list[float], temperature: float) -> list[float]:
    high = max(scores)
    weights = [math.exp((s - high) / temperature) for s in scores]
    total = sum(weights)
    return [v / total for v in weights]


def rank(obs: Observation, temperature: float = 1.0, use_graph: bool = True) -> tuple[Candidate, ...]:
    if temperature <= 0:
        raise ValueError('temperature must be positive')
    spans = {s.span_id: s for s in obs.spans}
    extras = {e.span_id: e for e in obs.evidence}
    deps = {s.span_id: (set(s.dependency_ids) | ({s.parent_span_id} if s.parent_span_id else set())) & spans.keys()
            for s in obs.spans}

    def ancestors(node: str) -> set[str]:
        seen = set()
        pending = list(deps[node])
        while pending:
            name = pending.pop()
            if name not in seen:
                seen.add(name)
                pending.extend(deps.get(name, ()))
        return seen

    anomaly = {s.span_id for s in obs.spans if s.abnormal}
    # Generate a candidate for each *observed* Span only; do not fill missing nodes.
    candidates = []
    for span in obs.spans:
        evidence = []
        missing = []
        score = (1.5 if span.status_code >= 500 else 1.0 if span.status_code >= 400 else 0.0)
        if span.latency_ms >= 1200:
            score += .5
        if span.span_id in extras:
            checks = extras[span.span_id].validation
            fails = sorted(k for k, value in checks.items() if value == 'fail')
            if fails:
                # Task-level failure is a downstream symptom, not direct root evidence.
                direct = [key for key in fails if key != 'task']
                score += (2.7 + .25 * len(direct)) if direct else .4
                evidence.append('Tool-reported check failed: ' + ', '.join(fails))
            else:
                evidence.append('Collected checks have no reported failure')
        else:
            missing.append('Validation details not collected')
        if span.abnormal:
            evidence.append('Gateway observed error status or high latency')
        if use_graph:
            affected = sum(1 for other in anomaly if other != span.span_id and span.span_id in ancestors(other))
            score += 1.05 * min(affected, 3)
            if affected:
                evidence.append(f'{affected} downstream anomalous span(s) depend on this span')
        if not span.abnormal and span.span_id not in extras:
            score -= .2
        candidates.append((span.span_id, score, tuple(evidence), tuple(missing)))

    if not candidates:
        return ()
    probs = _softmax([c[1] for c in candidates], temperature)
    result = [Candidate(c[0], c[1], p, c[2], c[3]) for c, p in zip(candidates, probs)]
    return tuple(sorted(result, key=lambda c: (-c.score, c.span_id)))


def diagnose(obs: Observation, trace_id: str, *, temperature: float = 1.0,
             threshold: float = .25, use_graph: bool = True,
             allow_abstain: bool = True) -> Diagnosis:
    ordered = rank(obs, temperature, use_graph)
    top = ordered[0] if ordered else None
    has_direct_check = bool(top and any('Tool-reported check failed' in item and 'task' not in item for item in top.evidence))
    has_symptom = bool(top and any('Gateway observed' in item for item in top.evidence))
    uncertain = (not top or top.confidence < threshold or not (has_direct_check or has_symptom))
    abstained = allow_abstain and uncertain
    selected = None if abstained or not top else top.span_id
    reason = ('No visible spans' if not top else 'Insufficient evidence or confidence' if abstained
              else 'Ranked observation; causal status unverified')
    next_check = None if selected else (f'Check {top.span_id} in a read-only sandbox' if top else 'Collect at least one Span')
    return Diagnosis(trace_id, ordered, selected, abstained, reason,
                     obs.used_bytes, obs.missing_span_ids, next_check)


def fit_temperature(examples: list[tuple[Observation, str]], use_graph: bool = True) -> float:
    """Fit softmax temperature using *validation-only* labeled observations."""
    if not examples:
        return 1.0
    best = (float('inf'), 1.0)
    for temperature in (.4, .7, 1., 1.5, 2., 3., 5., 8.):
        loss = 0.
        for obs, truth in examples:
            candidates = rank(obs, temperature, use_graph)
            truth_prob = next((c.confidence for c in candidates if c.span_id == truth), 1e-8)
            loss -= math.log(max(1e-8, truth_prob))
        if loss < best[0]:
            best = loss, temperature
    return best[1]
