"""Fair two-stage collection: cheap metadata first, budgeted validation second."""

import json
import random
from dataclasses import replace

from .model import Evidence, Observation, Span, TraceCase


def detail_size(span: Span) -> int:
    """Actual UTF-8 payload size for the optional validation record."""
    payload = {'span_id': span.span_id, 'validation': span.validation}
    return len(json.dumps(payload, ensure_ascii=False, separators=(',', ':'), sort_keys=True).encode())


def collect(case: TraceCase, budget_bytes: int, policy: str = 'adaptive',
            missing_fraction: float = 0, seed: int = 0) -> Observation:
    if budget_bytes < 0 or not 0 <= missing_fraction <= 1:
        raise ValueError('Invalid budget or missing fraction')
    if policy not in ('adaptive', 'uniform', 'random', 'full', 'none'):
        raise ValueError(f'Unknown collection policy: {policy}')

    rng = random.Random(seed)
    # A missing Span is NOT reconstructed from the oracle or from hidden metadata.
    hidden = {s.span_id for s in case.spans if rng.random() < missing_fraction}
    available = [s for s in case.spans if s.span_id not in hidden]
    lite = [replace(s, validation={}) for s in available]

    if policy == 'adaptive':
        # Metadata-only priority; never peek at validation values to decide sampling.
        parents = {s.span_id: set(filter(None, (s.parent_span_id,))) | set(s.dependency_ids)
                   for s in available}
        def descendants(node: str) -> int:
            found = {node.span_id}
            for _ in range(len(available)):
                found |= {child for child, deps in parents.items() if deps & found}
            return sum(s.abnormal and s.span_id in found for s in available)
        ordered = sorted(available, key=lambda s: (
            -((2 if s.abnormal else 0) + descendants(s) * .9 + (1 if s.status_code >= 500 else 0)) / 160,
            s.time_ns, s.span_id))
    elif policy == 'random':
        ordered = available.copy()
        rng.shuffle(ordered)
    elif policy == 'uniform':
        # Deterministic evenly spaced ordering; no privileged access to fault label.
        ordered = available[::2] + available[1::2]
    elif policy == 'full':
        ordered = available
    else:
        ordered = []

    # Reserve a constant envelope before fetching the optional record. This prevents
    # hidden validation length from influencing which Span is selected.
    slots = budget_bytes // 160
    chosen = []
    for span in ordered[:slots]:
        cost = detail_size(span)
        if cost > 160:
            raise ValueError("Validation record exceeds fixed collection envelope")
        chosen.append(Evidence(span.span_id, dict(span.validation), cost))
    used = sum(item.byte_cost for item in chosen)
    return Observation(tuple(lite), tuple(chosen), used,
                       budget_bytes, tuple(sorted(hidden)))
