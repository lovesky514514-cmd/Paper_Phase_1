"""Small standard-library client for the local ZeroGate sandbox."""

from __future__ import annotations

import json
from dataclasses import dataclass
from urllib.error import HTTPError
from urllib.request import Request, urlopen


@dataclass(frozen=True)
class Reply:
    status: int
    data: dict | list


class Client:
    def __init__(self, base_url: str, agent_token: str, admin_token: str):
        self.base_url = base_url
        self.agent_token = agent_token
        self.admin_token = admin_token

    def request(self, path: str, data: dict | None = None, *, admin: bool = False) -> Reply:
        payload = json.dumps(data, ensure_ascii=False).encode() if data is not None else None
        req = Request(
            self.base_url + path,
            data=payload,
            headers={
                "Authorization": "Bearer " + (self.admin_token if admin else self.agent_token),
                "Content-Type": "application/json",
            },
            method="POST" if data is not None else "GET",
        )
        try:
            with urlopen(req, timeout=5) as response:
                return Reply(response.status, json.load(response))
        except HTTPError as exc:
            return Reply(exc.code, json.load(exc))

    def manifest(self, tool: str) -> str:
        return self.request("/v1/manifests").data[tool]

    def grant(
        self, ident: str, task: str, tool: str, scope: str,
        *, sources: list[str] | None = None, destinations: list[str] | None = None,
    ) -> Reply:
        from datetime import datetime, timedelta, timezone
        expiration = datetime.now(timezone.utc) + timedelta(minutes=30)
        return self.request("/v1/grants", {
            "id": ident, "principal": "demo_user", "task_id": task,
            "tool": tool, "scope": scope, "manifest": self.manifest(tool),
            "sources": sources or [], "destinations": destinations or [],
            "expires_at": expiration.isoformat().replace("+00:00", "Z"),
        }, admin=True)

    def call(self, task: str, grant: str, tool: str, arguments: dict, *, manifest: str | None = None) -> Reply:
        prepared = self.prepare(task, grant, tool, arguments, manifest=manifest)
        return self.commit(prepared.data["ticket"]) if prepared.status == 200 else prepared

    def prepare(self, task: str, grant: str, tool: str, arguments: dict, *, manifest: str | None = None) -> Reply:
        return self.request("/v1/prepare", {
            "task_id": task, "grant_id": grant, "tool": tool,
            "manifest": manifest if manifest is not None else self.manifest(tool),
            "arguments": arguments,
        })

    def commit(self, ticket: str) -> Reply:
        return self.request("/v1/commit", {"ticket": ticket})

    def derive(self, task: str, value: str, refs: list[str] | None = None) -> Reply:
        return self.request("/v1/derive", {
            "principal": "demo_user", "task_id": task,
            "value": value, "source_refs": refs or [],
        }, admin=True)

    def revoke(self, grant: str) -> Reply:
        return self.request("/v1/revoke", {"id": grant}, admin=True)

    def effects(self) -> dict:
        return self.request("/v1/effects", admin=True).data
