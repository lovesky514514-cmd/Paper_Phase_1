"""Build and run a temporary loopback-only Go sandbox for integration tests."""

from __future__ import annotations

import os
import secrets
import socket
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from .client import Client

ROOT = Path(__file__).resolve().parent.parent


def available_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


@contextmanager
def sandbox():
    """Every run uses fresh memory, random credentials and a disposable binary."""
    with tempfile.TemporaryDirectory(prefix="zerogate-") as temp:
        binary = Path(temp) / ("zerogate.exe" if os.name == "nt" else "zerogate")
        subprocess.run(["go", "build", "-o", str(binary), "./cmd/zerogate"], cwd=ROOT, check=True)
        port = available_port()
        admin_token, agent_token = secrets.token_hex(32), secrets.token_hex(32)
        env = dict(os.environ, ZG_ADMIN_TOKEN=admin_token, ZG_AGENT_TOKEN=agent_token)
        proc = subprocess.Popen(
            [str(binary), "-listen", f"127.0.0.1:{port}"], env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        )
        base = f"http://127.0.0.1:{port}"
        try:
            for _ in range(100):
                if proc.poll() is not None:
                    raise RuntimeError("sandbox exited before ready: " + proc.stderr.read().decode(errors="replace"))
                try:
                    with urlopen(base + "/health", timeout=0.2) as response:
                        if response.status == 200:
                            break
                except (OSError, URLError):
                    time.sleep(0.05)
            else:
                raise RuntimeError("sandbox startup timeout")
            yield Client(base, agent_token, admin_token)
        finally:
            proc.terminate()
            try:
                proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
