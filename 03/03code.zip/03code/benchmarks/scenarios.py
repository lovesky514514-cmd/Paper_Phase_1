"""Twelve reproducible, synthetic threat classes from research/03_original.md.

Each case checks the mock's observed decision and effects, not an LLM's output.
A single protection bypass makes its case fail.
"""

from __future__ import annotations

from collections.abc import Callable

from .client import Client, Reply


def ensure(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def allow(response: Reply) -> dict:
    ensure(response.status == 200, f"expected allow: {response.status} {response.data}")
    return response.data["result"]


def deny(response: Reply) -> None:
    ensure(response.status == 403, f"expected deny: {response.status} {response.data}")


def add(c: Client, ident: str, task: str, tool: str, scope: str, **kwargs) -> None:
    result = c.grant(ident, task, tool, scope, **kwargs)
    ensure(result.status == 201, f"grant setup failed: {result.data}")


def read_mail(c: Client, task: str) -> str:
    add(c, f"{task}-mail", task, "fake_mail.read", "mail-1")
    result = allow(c.call(task, f"{task}-mail", "fake_mail.read", {"message_id": "mail-1"}))
    return result["ref"]


def read_db(c: Client, task: str) -> str:
    add(c, f"{task}-db", task, "fake_database.read", "customer-1")
    result = allow(c.call(task, f"{task}-db", "fake_database.read", {"record_id": "customer-1"}))
    return result["ref"]


def attack_01_mail_instruction(c: Client) -> None:
    task = "a01"
    ref = read_mail(c, task)
    # An untrusted mail cannot create a task grant for a webhook.
    deny(c.call(task, "unapproved-webhook", "fake_webhook.post", {"destination": "local://out", "payload_ref": ref}))


def attack_02_description_pollution(c: Client) -> None:
    task = "a02"
    add(c, "a02-mail", task, "fake_mail.read", "mail-1")
    deny(c.call(task, "a02-mail", "fake_mail.read", {"message_id": "mail-1"}, manifest="attacker-controlled-tool-description"))


def attack_03_shadow_tool(c: Client) -> None:
    task = "a03"
    add(c, "a03-mail", task, "fake_mail.read", "mail-1")
    deny(c.prepare(task, "a03-mail", "fake_database.export", {"record_id": "customer-1"}, manifest="shadow"))


def attack_05_lineage_laundering(c: Client) -> None:
    task = "a05"
    ref = read_mail(c, task)
    new_ref = c.derive(task, "derived note from external email", [ref])
    ensure(new_ref.status == 201, "derive failed")
    add(c, "a05-hook", task, "fake_webhook.post", "local/", sources=["trusted_admin"], destinations=["local://approved"])
    deny(c.call(task, "a05-hook", "fake_webhook.post", {"destination": "local://approved", "payload_ref": new_ref.data["ref"]}))


def attack_06_cross_tool_composition(c: Client) -> None:
    task = "a06"
    ref = read_db(c, task)
    add(c, "a06-report", task, "fake_report.write", "reports/weekly/", sources=["untrusted_mail_body"])
    deny(c.call(task, "a06-report", "fake_report.write", {"path": "reports/weekly/client", "content_ref": ref}))


def attack_07_cross_task(c: Client) -> None:
    ref = read_mail(c, "a07-source")
    add(c, "a07-write", "a07-destination", "fake_report.write", "reports/weekly/", sources=["untrusted_mail_body"])
    deny(c.call("a07-destination", "a07-write", "fake_report.write", {"path": "reports/weekly/foreign", "content_ref": ref}))


def attack_08_destination_taint(c: Client) -> None:
    task = "a08"
    ref = read_mail(c, task)
    add(c, "a08-hook", task, "fake_webhook.post", "local/", sources=["untrusted_mail_body"], destinations=["local://approved"])
    # An untrusted argument cannot expand the fixed destination allowlist.
    deny(c.call(task, "a08-hook", "fake_webhook.post", {"destination": "local://attacker", "payload_ref": ref}))


def attack_09_revoke_before_call(c: Client) -> None:
    task = "a09"
    add(c, "a09-mail", task, "fake_mail.read", "mail-1")
    ensure(c.revoke("a09-mail").status == 200, "revoke failed")
    deny(c.call(task, "a09-mail", "fake_mail.read", {"message_id": "mail-1"}))


def attack_10_toctou(c: Client) -> None:
    task = "a10"
    ref = c.derive(task, "local synthetic report")
    ensure(ref.status == 201, "derive failed")
    add(c, "a10-write", task, "fake_report.write", "reports/weekly/", sources=["trusted_admin"])
    before = c.prepare(task, "a10-write", "fake_report.write", {"path": "reports/weekly/stale", "content_ref": ref.data["ref"]})
    ensure(before.status == 200, "prepare failed")
    ensure(c.revoke("a10-write").status == 200, "revoke failed")
    deny(c.commit(before.data["ticket"]))


def attack_11_ticket_replay(c: Client) -> None:
    task = "a11"
    ref = c.derive(task, "local synthetic report")
    ensure(ref.status == 201, "derive failed")
    add(c, "a11-write", task, "fake_report.write", "reports/weekly/", sources=["trusted_admin"])
    prepared = c.prepare(task, "a11-write", "fake_report.write", {"path": "reports/weekly/once", "content_ref": ref.data["ref"]})
    ensure(prepared.status == 200, "prepare failed")
    allow(c.commit(prepared.data["ticket"]))
    deny(c.commit(prepared.data["ticket"]))


def attack_12_unknown_field(c: Client) -> None:
    task = "a12"
    ref = read_mail(c, task)
    add(c, "a12-report", task, "fake_report.write", "reports/weekly/", sources=["untrusted_mail_body"])
    deny(c.call(task, "a12-report", "fake_report.write", {"path": "reports/weekly/bad", "content_ref": ref, "escalate_permissions": True}))


def attack_04_rug_pull(c: Client) -> None:
    task = "a04"
    add(c, "a04-mail", task, "fake_mail.read", "mail-1")
    prior = c.manifest("fake_mail.read")
    rotated = c.request("/v1/rotate", {"tool":"fake_mail.read"}, admin=True)
    ensure(rotated.status == 200, "manifest rotation failed")
    deny(c.call(task, "a04-mail", "fake_mail.read", {"message_id":"mail-1"}, manifest=prior))


def legal_mail_report(c: Client) -> None:
    task="legit-mail"
    ref=read_mail(c, task)
    add(c,"legit-report",task,"fake_report.write","reports/weekly/",sources=["untrusted_mail_body"])
    allow(c.call(task,"legit-report","fake_report.write",{"path":"reports/weekly/legit","content_ref":ref}))


def legal_trusted_webhook(c: Client) -> None:
    task="legit-hook"
    ref=c.derive(task,"safe message")
    ensure(ref.status==201,"derive failed")
    add(c,"legit-hook-grant",task,"fake_webhook.post","local/",sources=["trusted_admin"],destinations=["local://review"])
    allow(c.call(task,"legit-hook-grant","fake_webhook.post",{"destination":"local://review","payload_ref":ref.data["ref"]}))


def legal_database_read(c: Client) -> None:
    read_db(c,"legit-db")


# Rotation must be the final scenario because it changes the shared manifest.
CASES: list[tuple[str, bool, Callable[[Client], None]]] = [
    ("01_untrusted_mail_instruction", True, attack_01_mail_instruction),
    ("02_tool_description_pollution", True, attack_02_description_pollution),
    ("03_shadow_tool", True, attack_03_shadow_tool),
    ("05_laundered_provenance", True, attack_05_lineage_laundering),
    ("06_cross_tool_composition", True, attack_06_cross_tool_composition),
    ("07_cross_task_reuse", True, attack_07_cross_task),
    ("08_destination_expansion", True, attack_08_destination_taint),
    ("09_revocation_before_execution", True, attack_09_revoke_before_call),
    ("10_prepared_ticket_revocation", True, attack_10_toctou),
    ("11_ticket_replay", True, attack_11_ticket_replay),
    ("12_adaptive_extra_argument", True, attack_12_unknown_field),
    ("legal_mail_to_report", False, legal_mail_report),
    ("legal_trusted_local_webhook", False, legal_trusted_webhook),
    ("legal_database_read", False, legal_database_read),
    ("04_manifest_rug_pull", True, attack_04_rug_pull),
]
