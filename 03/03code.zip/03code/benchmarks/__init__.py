"""Local synthetic threat scenarios, not a public MCP benchmark."""
