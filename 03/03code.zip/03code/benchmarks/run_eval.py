"""Executable synthetic ZeroGate-CT smoke evaluation; no fabricated baselines."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .runtime import sandbox
from .scenarios import CASES


def evaluate() -> dict:
    findings = []
    with sandbox() as client:
        for name, adversarial, scenario in CASES:
            try:
                scenario(client)
                passed, detail = True, "expected local effects/decision observed"
            except (AssertionError, KeyError, TypeError, ValueError) as exc:
                passed, detail = False, str(exc)
            findings.append({"name": name, "adversarial": adversarial, "passed": passed, "detail": detail})
        effects = client.effects()
        audit_events = len(client.request("/v1/audit", admin=True).data)
    return {
        "type": "local_mock_synthetic_scenarios",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "attack_cases": sum(int(x["adversarial"]) for x in findings),
        "attack_cases_passed": sum(int(x["adversarial"] and x["passed"]) for x in findings),
        "legitimate_cases": sum(int(not x["adversarial"]) for x in findings),
        "legitimate_cases_passed": sum(int(not x["adversarial"] and x["passed"]) for x in findings),
        "findings": findings,
        "observed_mock_effects": effects,
        "audit_event_count": audit_events,
        "limits": "Test-level expectations only. Not real attack success rate, FPR or full MCP interoperability.",
    }


def main() -> int:
    result = evaluate()
    destination = Path("results") / "last_run.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Synthetic attacks blocked: {result['attack_cases_passed']}/{result['attack_cases']}")
    print(f"Legal flows accepted:      {result['legitimate_cases_passed']}/{result['legitimate_cases']}")
    for item in result["findings"]:
        print(f"{'PASS' if item['passed'] else 'FAIL'} {item['name']}")
    print(f"Detailed results: {destination}")
    return 0 if all(item["passed"] for item in result["findings"]) else 1


if __name__ == "__main__":
    sys.exit(main())
