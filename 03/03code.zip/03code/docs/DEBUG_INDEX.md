# 逐文件排错索引

先运行 `python scripts/check.py`，记录第一条失败命令；再到对应文件页定位。以下帮助仅针对源码、脚本和项目文档，排错页自身无需递归生成排错页。

- [`gateway/model.go`](files/gateway__model_go.md)：请求解析、领域数据结构
- [`gateway/policy.go`](files/gateway__policy_go.md)：授权、对象范围与来源验证
- [`gateway/gate.go`](files/gateway__gate_go.md)：策略/票据/副作用的同锁执行面
- [`gateway/http.go`](files/gateway__http_go.md)：鉴权与本地 JSON-RPC 入口
- [`gateway/gate_test.go`](files/gateway__gate_test_go.md)：Go 安全性质与并发测试
- [`cmd/zerogate/main.go`](files/cmd__zerogate__main_go.md)：Go 本地启动入口
- [`go.mod`](files/go_mod.md)：Go 模块版本声明
- [`benchmarks/client.py`](files/benchmarks__client_py.md)：Python 标准库 HTTP 测试客户端
- [`benchmarks/runtime.py`](files/benchmarks__runtime_py.md)：可丢弃 Go 进程的启停和随机鉴权
- [`benchmarks/scenarios.py`](files/benchmarks__scenarios_py.md)：12 类威胁和合法流的可观测断言
- [`benchmarks/run_eval.py`](files/benchmarks__run_eval_py.md)：实验总入口和 JSON 报告
- [`benchmarks/__init__.py`](files/benchmarks____init___py.md)：Python 包标记
- [`tests/test_scenarios.py`](files/tests__test_scenarios_py.md)：端到端 HTTP/MCP 行为测试
- [`scripts/check.py`](files/scripts__check_py.md)：一次性跨语言自检
- [`scripts/start.py`](files/scripts__start_py.md)：本机手工运行网关
- [`scripts/start.sh`](files/scripts__start_sh.md)：Linux/macOS 启动包装
- [`scripts/check.sh`](files/scripts__check_sh.md)：Linux/macOS 自检包装
- [`scripts/start_windows.bat`](files/scripts__start_windows_bat.md)：Windows 启动包装
- [`scripts/check_windows.bat`](files/scripts__check_windows_bat.md)：Windows 自检包装
- [`.gitignore`](files/_gitignore.md)：本地临时文件忽略规则
- [`README.md`](files/README_md.md)：最短上手指引
- [`GLOSSARY.md`](files/GLOSSARY_md.md)：团队统一术语
- [`docs/DESIGN.md`](files/docs__DESIGN_md.md)：模块依赖与部署边界
- [`docs/THREAT_MODEL.md`](files/docs__THREAT_MODEL_md.md)：攻击者能力和信任假设
- [`docs/POLICY_SEMANTICS.md`](files/docs__POLICY_SEMANTICS_md.md)：授权字段和拒绝条件
- [`docs/EVALUATION_PROTOCOL.md`](files/docs__EVALUATION_PROTOCOL_md.md)：12 类合成威胁实验方法
- [`docs/QUALITY.md`](files/docs__QUALITY_md.md)：自检结果及未验证部分
- [`research/03_original.md`](files/research__03_original_md.md)：原始研究方案保留件
