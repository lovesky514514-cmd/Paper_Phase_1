# 设计与模块

`Agent / MCP JSON-RPC client → Go HTTP handler → Gate.check → Prepare ticket → Commit → mock effects`

Go 是安全决策与沙箱执行边界；Python 是测试驱动器和观测端。所有请求经同一 Gate，不引入新的代理、ORM、数据库框架。

- `gateway/model.go`：明确 Grant、Call、Ticket、Artifact、Record 术语与严格 JSON 读取。
- `gateway/policy.go`：权限范围、来源标签、manifest、父子委托校验。
- `gateway/gate.go`：持有状态锁，执行原子提交、撤权、审计与模拟读写。
- `gateway/http.go`：仅限本地的 HTTP 和 MCP JSON-RPC 最小适配。
- `benchmarks`：以真实 HTTP 行为观测通过/拒绝，不生成虚构基线分数。

**状态耦合是有意的**：只有内存中的策略、消费票据和 mock 工具状态共用同一锁，才能提供当前限定条件下的线性化顺序。迁移到多个进程时必须重新设计工具端验证和共享事务语义。

生产实现需要 OAuth/OIDC/JWT 验证、真实服务 TLS/mTLS、持久审计、策略审批与密钥管理、MCP 规范兼容、自适应负载保护及跨进程竞态分析。这些目前都不在原型内。
