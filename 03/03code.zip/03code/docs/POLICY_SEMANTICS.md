# 策略语义

每份 Grant 绑定：`id, principal, task_id, tool, scope, manifest, expires_at, sources, destinations, parent_id`。`active/version` 永远由网关控制；管理接口只接受管理员令牌。

- **范围**：读对象必须精确匹配；报告限定 `reports/` 内相应目录；路径穿越、未知 JSON 字段拒绝；webhook 只接受显式 `local://...` 目的地。
- **来源**：写操作只读取网关登记的 `content_ref` / `payload_ref`，不接受 Agent 直接声明来源标签。管理员生成派生内容必须列出来源引用，派生标签取最高限制级别（`trusted_admin` → `untrusted_mail_body` → `restricted_database`）。没有自动推断完整自然语言血缘的能力。
- **委托**：同一主体、任务、工具内可生成子 Grant；scope、sources、destinations、expiry 不可扩张，父授权撤销将阻止所有后代调用。
- **版本**：工具描述版本升级后旧 manifest 与旧 Grant 一并失效。`Prepare` 不造成副作用；`Commit` 重新验证、消费一次性票据并执行本地操作。票据默认 30 秒。
- **默认规则**：凡未经肯定验证的操作均拒绝；管理员可以显式审批新的更窄或新的根授权。真实身份鉴别/授权审批 UI 不在此包。

演示 HTTP 端点：`GET /health`, `GET /v1/manifests`, `POST /v1/grants` (admin), `POST /v1/revoke` (admin), `POST /v1/prepare`, `POST /v1/commit`, `POST /mcp`, `GET /v1/effects` (admin), `GET /v1/provenance` (admin), `GET /v1/audit` (admin)。
