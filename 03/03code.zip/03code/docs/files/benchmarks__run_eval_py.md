# `benchmarks/run_eval.py`

**职责**：实验总入口和 JSON 报告。

**常见错误**：没有 last_run.json、统计数不对应实际案例。

**查错与修复**：检查当前工作目录、目录写权限与 CASES 数量；失败记录必须保留原始名称。

**验证命令**（项目根目录）：

```text
python -m benchmarks.run_eval
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
