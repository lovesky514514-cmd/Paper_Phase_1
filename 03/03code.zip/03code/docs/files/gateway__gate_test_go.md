# `gateway/gate_test.go`

**职责**：Go 安全性质与并发测试。

**常见错误**：偶发失败、断言不明确、模型变更引起测试误报。

**查错与修复**：保持真实 Gate 路径与隔离的测试实例；先查断言的实际副作用是否可观测。

**验证命令**（项目根目录）：

```text
go test -race ./gateway -count=3
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
