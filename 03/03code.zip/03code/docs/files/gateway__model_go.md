# `gateway/model.go`

**职责**：请求解析、领域数据结构。

**常见错误**：JSON 语法错误、字段不被识别、票据结构变更导致编译失败。

**查错与修复**：先比较客户端字段与 Grant/Call 定义；检查 decodeStrict 是否拒绝未知字段和尾随垃圾。

**验证命令**（项目根目录）：

```text
go test ./gateway -run TestStrictDecodeAndExpiry -v
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
