# `.gitignore`

**职责**：本地临时文件忽略规则。

**常见错误**：Git 检测到 pycache、exe 或临时结果。

**查错与修复**：检查文件是否已被 Git 跟踪；不要提交临时密钥或可识别数据。

**验证命令**（项目根目录）：

```text
git status --short
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
