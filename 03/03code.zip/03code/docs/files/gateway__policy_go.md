# `gateway/policy.go`

**职责**：授权、对象范围与来源验证。

**常见错误**：合法写入被拒、路径穿越误放行、子授权越权。

**查错与修复**：用 scopeCovers/withinScope 和 allowed sources 构造最小反例；禁止改成模糊字符串前缀匹配。

**验证命令**（项目根目录）：

```text
go test ./gateway -run "TestDelegationAttenuation|TestCrossTaskAndPathTraversal|TestLegalReportAndTaintEnforcement" -v
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
