# `tests/test_scenarios.py`

**职责**：端到端 HTTP/MCP 行为测试。

**常见错误**：集成测试卡住或断言报错。

**查错与修复**：先执行 Go 单测，再跑该文件；失败时核对临时网关是否按需启动。

**验证命令**（项目根目录）：

```text
python -m unittest tests.test_scenarios -v
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
