# `scripts/start.sh`

**职责**：Linux/macOS 启动包装。

**常见错误**：找不到 python3、执行权限不足。

**查错与修复**：使用 sh scripts/start.sh，无需 chmod；检查 Python 3.11+ 和 Go 1.22+。

**验证命令**（项目根目录）：

```text
sh scripts/start.sh
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
