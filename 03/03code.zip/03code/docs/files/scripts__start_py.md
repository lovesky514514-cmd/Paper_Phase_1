# `scripts/start.py`

**职责**：本机手工运行网关。

**常见错误**：未打印本次令牌、启动后无响应。

**查错与修复**：验证 Go 已加入 PATH，8933 端口空闲；注意退出会丢失所有内存状态。

**验证命令**（项目根目录）：

```text
python scripts/start.py
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
