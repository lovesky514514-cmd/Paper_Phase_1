# `scripts/check.sh`

**职责**：Linux/macOS 自检包装。

**常见错误**：sh 路径错误或 py/go 不在 PATH。

**查错与修复**：先 cd 到解压目录；用 python3 scripts/check.py 直接定位失败阶段。

**验证命令**（项目根目录）：

```text
sh scripts/check.sh
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
