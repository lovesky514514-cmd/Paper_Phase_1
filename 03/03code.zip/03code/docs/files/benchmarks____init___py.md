# `benchmarks/__init__.py`

**职责**：Python 包标记。

**常见错误**：No module named benchmarks。

**查错与修复**：在项目根目录使用 -m 启动而非切入 benchmarks 子目录。

**验证命令**（项目根目录）：

```text
python -m benchmarks.run_eval
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
