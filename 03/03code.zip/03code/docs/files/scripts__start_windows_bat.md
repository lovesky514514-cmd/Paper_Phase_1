# `scripts/start_windows.bat`

**职责**：Windows 启动包装。

**常见错误**：双击闪退、找不到 py 或 Go。

**查错与修复**：安装 Python Launcher 或 python，并将 Go 加入 PATH；从终端运行以保留报错。

**验证命令**（项目根目录）：

```text
scripts\start_windows.bat
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
