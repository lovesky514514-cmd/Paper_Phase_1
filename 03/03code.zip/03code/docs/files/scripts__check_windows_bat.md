# `scripts/check_windows.bat`

**职责**：Windows 自检包装。

**常见错误**：双击后红字、编码/路径问题。

**查错与修复**：从 cmd 运行本脚本；检查 Python 和 Go；优先修复第一条失败命令。

**验证命令**（项目根目录）：

```text
scripts\check_windows.bat
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
