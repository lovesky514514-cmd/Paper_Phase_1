# `benchmarks/scenarios.py`

**职责**：12 类威胁和合法流的可观测断言。

**常见错误**：某攻击意外放行、合法任务被错误阻断。

**查错与修复**：逐个查看对应 attack_XX 和 allow/deny；验证最终 mock effects；不要为了通过率放宽断言。

**验证命令**（项目根目录）：

```text
python -m benchmarks.run_eval
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
