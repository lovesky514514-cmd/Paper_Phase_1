# `benchmarks/client.py`

**职责**：Python 标准库 HTTP 测试客户端。

**常见错误**：HTTP 400/401/403 被误认为异常、请求超时。

**查错与修复**：使用 Reply.status 排查业务拒绝；检查 JSON 字段、临时令牌和服务监听地址。

**验证命令**（项目根目录）：

```text
python -m unittest tests.test_scenarios -v
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
