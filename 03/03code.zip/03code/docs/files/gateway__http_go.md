# `gateway/http.go`

**职责**：鉴权与本地 JSON-RPC 入口。

**常见错误**：401、403、400、MCP error code 不符合预期。

**查错与修复**：401 先检查 Bearer；403 查 grant 与 manifest；400 查 Content-Type 与多余字段；禁止关闭验证绕过。

**验证命令**（项目根目录）：

```text
python -m unittest tests.test_scenarios -v
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
