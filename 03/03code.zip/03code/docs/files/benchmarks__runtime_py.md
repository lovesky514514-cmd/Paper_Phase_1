# `benchmarks/runtime.py`

**职责**：可丢弃 Go 进程的启停和随机鉴权。

**常见错误**：go build 不存在、端口占用、启动超时。

**查错与修复**：检查 PATH 中的 go；确保回环端口可用；查看子进程退出状态，不要固定复用令牌。

**验证命令**（项目根目录）：

```text
python -m unittest tests.test_scenarios -v
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
