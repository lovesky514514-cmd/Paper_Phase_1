# `README.md`

**职责**：最短上手指引。

**常见错误**：命令从错误目录运行、依赖安装不全。

**查错与修复**：确认正在项目根目录；依次安装 Python/Go，再执行自检。

**验证命令**（项目根目录）：

```text
python scripts/check.py
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
