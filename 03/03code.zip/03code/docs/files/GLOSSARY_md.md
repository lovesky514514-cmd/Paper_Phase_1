# `GLOSSARY.md`

**职责**：团队统一术语。

**常见错误**：代码的 Grant/Commit/Artifact 含义与说明不符。

**查错与修复**：以 Go 领域结构为依据，修复术语定义时同步更新性质测试。

**验证命令**（项目根目录）：

```text
go test ./gateway
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
