# `docs/POLICY_SEMANTICS.md`

**职责**：授权字段和拒绝条件。

**常见错误**：策略示例与实现不一致。

**查错与修复**：用当前结构体字段校验；尤其检查父授权、来源和 manifest 判定。

**验证命令**（项目根目录）：

```text
go test ./gateway
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
