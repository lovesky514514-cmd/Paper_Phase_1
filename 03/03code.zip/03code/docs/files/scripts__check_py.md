# `scripts/check.py`

**职责**：一次性跨语言自检。

**常见错误**：未检测到 python/go、某一阶段未执行。

**查错与修复**：看打印的 Running 命令；逐条在包根目录运行，修复环境后重试。

**验证命令**（项目根目录）：

```text
python scripts/check.py
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
