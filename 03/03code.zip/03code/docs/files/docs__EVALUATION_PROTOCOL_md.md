# `docs/EVALUATION_PROTOCOL.md`

**职责**：12 类合成威胁实验方法。

**常见错误**：结果被误解成论文级攻击成功率。

**查错与修复**：核对样本数量、真实 HTTP 观测和实验边界；不要合成外部基线数值。

**验证命令**（项目根目录）：

```text
python -m benchmarks.run_eval
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
