# `gateway/gate.go`

**职责**：策略/票据/副作用的同锁执行面。

**常见错误**：撤权后写入、票据重放成功、派生数据丢失标签。

**查错与修复**：确保 Revoke、Commit 与 mock effect 修改在同一把锁下；修复必须补竞态测试。

**验证命令**（项目根目录）：

```text
go test -race ./gateway -run "TestConcurrent|TestProvenanceEdges|TestPreparedTicketInvalidatedByRevocation"
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
