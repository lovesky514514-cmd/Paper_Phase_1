# `go.mod`

**职责**：Go 模块版本声明。

**常见错误**：go: version not supported、依赖解析失败。

**查错与修复**：安装 Go 1.22+，在包根目录运行；本项目不依赖第三方 Go 模块。

**验证命令**（项目根目录）：

```text
go test ./...
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
