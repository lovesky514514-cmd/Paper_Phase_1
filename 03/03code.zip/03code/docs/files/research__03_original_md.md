# `research/03_original.md`

**职责**：原始研究方案保留件。

**常见错误**：计划与已实现功能混淆。

**查错与修复**：对照 README 与 DESIGN 中已实现/未实现项，不修改原始方案冒充实验结果。

**验证命令**（项目根目录）：

```text
python scripts/check.py
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
