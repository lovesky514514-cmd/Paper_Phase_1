# `cmd/zerogate/main.go`

**职责**：Go 本地启动入口。

**常见错误**：启动失败、拒绝非本机地址、端口被占用。

**查错与修复**：确认随机令牌由 scripts/start.py 传入；检查 8933 端口，勿改成 0.0.0.0。

**验证命令**（项目根目录）：

```text
go build ./cmd/zerogate
```

若本文件修改后引入新的行为变化，还需运行 `python scripts/check.py` 做完整回归。
