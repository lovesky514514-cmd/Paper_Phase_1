"""Integration acceptance tests against the real Go HTTP server."""

import unittest

from benchmarks.run_eval import evaluate
from benchmarks.runtime import sandbox
from benchmarks.scenarios import CASES


class TestLiveSandbox(unittest.TestCase):
    def test_twelve_threat_classes_and_legal_tasks(self):
        result = evaluate()
        self.assertEqual(12, result["attack_cases"])
        self.assertEqual(12, result["attack_cases_passed"], result["findings"])
        self.assertEqual(3, result["legitimate_cases"])
        self.assertEqual(3, result["legitimate_cases_passed"], result["findings"])
        self.assertEqual(["local://review"], result["observed_mock_effects"]["webhook_destinations"])

    def test_authentication_and_mcp_jsonrpc(self):
        with sandbox() as client:
            self.assertEqual(401, client.request("/v1/audit").status)
            self.assertEqual(200, client.request("/v1/manifests").status)
            tools = client.request("/mcp", {"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
            self.assertEqual(200, tools.status)
            self.assertEqual(4, len(tools.data["result"]["tools"]))
            denied = client.request("/mcp", {
                "jsonrpc": "2.0", "id": 2, "method": "tools/call",
                "params": {"name": "fake_mail.read", "arguments": {"message_id": "mail-1"},
                           "_meta": {"task_id": "t", "grant_id": "nonexistent", "manifest": client.manifest("fake_mail.read")}},
            })
            self.assertEqual("grant_mismatch", denied.data["error"]["message"])
            granted = client.grant("mcp-read", "t", "fake_mail.read", "mail-1")
            self.assertEqual(201, granted.status)
            accepted = client.request("/mcp", {
                "jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": "fake_mail.read", "arguments": {"message_id": "mail-1"},
                           "_meta": {"task_id": "t", "grant_id": "mcp-read", "manifest": client.manifest("fake_mail.read")}},
            })
            self.assertIn("content", accepted.data["result"])
            self.assertFalse(accepted.data["result"]["isError"])


if __name__ == "__main__":
    unittest.main()
