# 03code · MCP-ZeroGate

面向 Agent 工具调用的**结构化授权 + 来源约束 + 撤权安全**研究骨架。默认只能操作本地合成数据。

**安装：Python 3.11+、Go 1.22+。不需要 pip、API Key 或数据库。**

| 操作 | Windows | Linux / macOS |
|---|---|---|
| 运行 12 类合成威胁测试 | `py -3 -m benchmarks.run_eval` | `python3 -m benchmarks.run_eval` |
| 全量自检 | 双击 `scripts\check_windows.bat` | `sh scripts/check.sh` |
| 手工启动本地网关 | 双击 `scripts\start_windows.bat` | `sh scripts/start.sh` |

命令请在**解压后的 `03code` 根目录**运行。测试结果写入 `results/last_run.json`。
手工启动后访问 `http://127.0.0.1:8933/health`；启动窗口会打印本次临时生成的访问令牌，仅供本机测试。

**已实现**：Go 内存策略账本、基于请求和工具版本的授权、父子任务权限收缩、来源标签/派生边、短时单次票据、撤权与模拟执行原子提交；MCP JSON-RPC 的 `initialize` / `tools/list` / `tools/call` 子集。Python 驱动真实 HTTP 场景与测试。

**未实现**：完整 MCP Streamable HTTP 协议、外部工具端分布式事务、持久化/多租户身份、真实 Agent/LLM、公开强基线复现。**不能作为生产安全网关使用。**

- 出错从 [排错索引](docs/DEBUG_INDEX.md) 开始，全部代码文件有独立排错页。
- 设计与限制：[架构](docs/DESIGN.md)、[威胁模型](docs/THREAT_MODEL.md)、[策略语义](docs/POLICY_SEMANTICS.md)、[评估协议](docs/EVALUATION_PROTOCOL.md)、[自检报告](docs/QUALITY.md)。
- [原始选题 03.md](research/03_original.md) 保留在包内。
