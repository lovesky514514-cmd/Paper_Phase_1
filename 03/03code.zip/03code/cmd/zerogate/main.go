package main

import (
	"flag"
	"log"
	"net"
	"net/http"
	"os"
	"time"

	"example.org/mcp-zerogate/gateway"
)

func main() {
	address := flag.String("listen", "127.0.0.1:8933", "loopback address for local research")
	flag.Parse()
	host, _, err := net.SplitHostPort(*address)
	if err != nil || (host != "127.0.0.1" && host != "localhost" && host != "::1") {
		log.Fatal("only a loopback bind address is allowed")
	}
	handler, err := gateway.NewServer(gateway.New(), os.Getenv("ZG_AGENT_TOKEN"), os.Getenv("ZG_ADMIN_TOKEN"))
	if err != nil {
		log.Fatal(err)
	}
	srv := &http.Server{Addr: *address, Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second, MaxHeaderBytes: 8192}
	log.Printf("ZeroGate local mock listening at %s (no real outbound tools)", *address)
	log.Fatal(srv.ListenAndServe())
}
