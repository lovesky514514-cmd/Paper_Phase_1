module example.org/mcp-zerogate

go 1.22
