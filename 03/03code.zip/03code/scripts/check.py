"""Cross-platform one-command self check: no pip packages required."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def run(*command: str) -> bool:
    print("\nRunning:", " ".join(command), flush=True)
    return subprocess.run(command, cwd=ROOT, check=False).returncode == 0


def main() -> int:
    steps = [
        ("go", "test", "./..."),
        ("go", "vet", "./..."),
        (sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"),
        (sys.executable, "-m", "benchmarks.run_eval"),
    ]
    return 0 if all(run(*cmd) for cmd in steps) else 1


if __name__ == "__main__":
    raise SystemExit(main())
