"""Start the local sandbox with ephemeral credentials for manual exploration."""

from __future__ import annotations

import os
import secrets
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    agent, admin = secrets.token_hex(32), secrets.token_hex(32)
    env = dict(os.environ, ZG_AGENT_TOKEN=agent, ZG_ADMIN_TOKEN=admin)
    print("Only listening on 127.0.0.1:8933 (synthetic mock)", flush=True)
    print(f"ZG_AGENT_TOKEN={agent}", flush=True)
    print(f"ZG_ADMIN_TOKEN={admin}", flush=True)
    print("Press Ctrl+C to stop. Do not publish these session tokens.", flush=True)
    try:
        return subprocess.run(["go", "run", "./cmd/zerogate"], env=env, cwd=ROOT).returncode
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
