package gateway

import (
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// HTTP only exposes loopback-safe lab endpoints. All policy mutations need admin auth.
type Server struct {
	gate       *Gate
	agentToken string
	adminToken string
	mux        *http.ServeMux
}

func NewServer(g *Gate, agentToken, adminToken string) (*Server, error) {
	if len(agentToken) < 24 || len(adminToken) < 24 || agentToken == adminToken {
		return nil, fmt.Errorf("distinct random credentials (>=24 chars) required")
	}
	s := &Server{gate: g, agentToken: agentToken, adminToken: adminToken, mux: http.NewServeMux()}
	s.mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		write(w, http.StatusOK, map[string]any{"status": "ok", "mode": "local_mock"})
	})
	s.mux.HandleFunc("GET /v1/manifests", s.agent(s.manifests))
	s.mux.HandleFunc("POST /v1/prepare", s.agent(s.prepare))
	s.mux.HandleFunc("POST /v1/commit", s.agent(s.commit))
	s.mux.HandleFunc("POST /mcp", s.agent(s.mcp))
	s.mux.HandleFunc("POST /v1/grants", s.admin(s.addGrant))
	s.mux.HandleFunc("POST /v1/revoke", s.admin(s.revoke))
	s.mux.HandleFunc("POST /v1/rotate", s.admin(s.rotate))
	s.mux.HandleFunc("POST /v1/derive", s.admin(s.derive))
	s.mux.HandleFunc("GET /v1/effects", s.admin(s.effects))
	s.mux.HandleFunc("GET /v1/provenance", s.admin(s.provenance))
	s.mux.HandleFunc("GET /v1/audit", s.admin(s.audit))
	return s, nil
}

func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	// Do not allow cross-origin browser requests or intermediary cache reuse.
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	s.mux.ServeHTTP(w, r)
}

func authenticated(r *http.Request, token string) bool {
	prefix := "Bearer "
	h := r.Header.Get("Authorization")
	return strings.HasPrefix(h, prefix) && subtle.ConstantTimeCompare([]byte(strings.TrimPrefix(h, prefix)), []byte(token)) == 1
}

func (s *Server) agent(fn http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !authenticated(r, s.agentToken) {
			write(w, 401, map[string]string{"error": "unauthorized"})
			return
		}
		fn(w, r)
	}
}
func (s *Server) admin(fn http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !authenticated(r, s.adminToken) {
			write(w, 401, map[string]string{"error": "unauthorized"})
			return
		}
		fn(w, r)
	}
}

func write(w http.ResponseWriter, status int, data any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(data)
}

func body(r *http.Request, v any) error {
	if r.Header.Get("Content-Type") != "application/json" {
		return fmt.Errorf("content-type must be application/json")
	}
	limited, err := io.ReadAll(io.LimitReader(r.Body, 32*1024+1))
	if err != nil || len(limited) > 32*1024 {
		return fmt.Errorf("body too large")
	}
	return decodeStrict(limited, v)
}

func (s *Server) manifests(w http.ResponseWriter, r *http.Request) { write(w, 200, s.gate.Manifests()) }
func (s *Server) prepare(w http.ResponseWriter, r *http.Request) {
	var c Call
	if err := body(r, &c); err != nil {
		write(w, 400, map[string]string{"error": "invalid_call"})
		return
	}
	id, reason := s.gate.Prepare("demo_user", c)
	if reason != "" {
		write(w, 403, map[string]string{"error": reason})
		return
	}
	write(w, 200, map[string]string{"ticket": id})
}
func (s *Server) commit(w http.ResponseWriter, r *http.Request) {
	var q struct {
		Ticket string `json:"ticket"`
	}
	if err := body(r, &q); err != nil {
		write(w, 400, map[string]string{"error": "invalid_ticket"})
		return
	}
	result, reason := s.gate.Commit("demo_user", q.Ticket)
	if reason != "" {
		write(w, 403, map[string]string{"error": reason})
		return
	}
	write(w, 200, map[string]any{"result": result})
}
func (s *Server) addGrant(w http.ResponseWriter, r *http.Request) {
	var g Grant
	if err := body(r, &g); err != nil {
		write(w, 400, map[string]string{"error": "invalid_grant"})
		return
	}
	if err := s.gate.AddGrant(g); err != nil {
		write(w, 400, map[string]string{"error": err.Error()})
		return
	}
	write(w, 201, map[string]any{"id": g.ID})
}
func (s *Server) revoke(w http.ResponseWriter, r *http.Request) {
	var q struct {
		ID string `json:"id"`
	}
	if err := body(r, &q); err != nil {
		write(w, 400, map[string]string{"error": "invalid_request"})
		return
	}
	if err := s.gate.Revoke(q.ID); err != nil {
		write(w, 404, map[string]string{"error": "not_found"})
		return
	}
	write(w, 200, map[string]any{"revoked": q.ID})
}
func (s *Server) rotate(w http.ResponseWriter, r *http.Request) {
	var q struct {
		Tool string `json:"tool"`
	}
	if err := body(r, &q); err != nil {
		write(w, 400, map[string]string{"error": "invalid_request"})
		return
	}
	digest, err := s.gate.Rotate(q.Tool)
	if err != nil {
		write(w, 404, map[string]string{"error": "not_found"})
		return
	}
	write(w, 200, map[string]string{"manifest": digest})
}
func (s *Server) derive(w http.ResponseWriter, r *http.Request) {
	var q struct {
		Principal string   `json:"principal"`
		TaskID    string   `json:"task_id"`
		Value     string   `json:"value"`
		Sources   []string `json:"source_refs"`
	}
	if err := body(r, &q); err != nil {
		write(w, 400, map[string]string{"error": "invalid_request"})
		return
	}
	if q.Principal != "demo_user" {
		write(w, 403, map[string]string{"error": "invalid_principal"})
		return
	}
	ref, err := s.gate.DeriveTrusted(q.Principal, q.TaskID, q.Value, q.Sources)
	if err != nil {
		write(w, 400, map[string]string{"error": err.Error()})
		return
	}
	write(w, 201, map[string]string{"ref": ref})
}
func (s *Server) effects(w http.ResponseWriter, r *http.Request) { write(w, 200, s.gate.Effects()) }
func (s *Server) provenance(w http.ResponseWriter, r *http.Request) {
	write(w, 200, s.gate.Provenance())
}
func (s *Server) audit(w http.ResponseWriter, r *http.Request) { write(w, 200, s.gate.Audit()) }

// mcp supports a small JSON-RPC subset. It is NOT full MCP Streamable HTTP.
func (s *Server) mcp(w http.ResponseWriter, r *http.Request) {
	var q struct {
		JSONRPC string          `json:"jsonrpc"`
		ID      json.RawMessage `json:"id"`
		Method  string          `json:"method"`
		Params  json.RawMessage `json:"params"`
	}
	if err := body(r, &q); err != nil || q.JSONRPC != "2.0" || len(q.ID) == 0 {
		write(w, 400, map[string]string{"error": "bad_jsonrpc"})
		return
	}
	reply := func(result any) {
		write(w, 200, map[string]any{"jsonrpc": "2.0", "id": json.RawMessage(q.ID), "result": result})
	}
	failure := func(code int, message string) {
		write(w, 200, map[string]any{"jsonrpc": "2.0", "id": json.RawMessage(q.ID), "error": map[string]any{"code": code, "message": message}})
	}
	switch q.Method {
	case "initialize":
		reply(map[string]any{"protocolVersion": "2025-03-26", "capabilities": map[string]any{"tools": map[string]any{}}, "serverInfo": map[string]string{"name": "mcp-zerogate-lab", "version": "0.1.0"}})
	case "tools/list":
		var listed []map[string]any
		for _, name := range tools {
			listed = append(listed, map[string]any{"name": name, "description": "Synthetic local mock tool, requires separately approved grant.", "inputSchema": map[string]any{"type": "object"}})
		}
		reply(map[string]any{"tools": listed})
	case "tools/call":
		var p struct {
			Name      string          `json:"name"`
			Arguments json.RawMessage `json:"arguments"`
			Meta      struct {
				TaskID   string `json:"task_id"`
				GrantID  string `json:"grant_id"`
				Manifest string `json:"manifest"`
			} `json:"_meta"`
		}
		if err := decodeStrict(q.Params, &p); err != nil {
			failure(-32602, "invalid_params")
			return
		}
		c := Call{TaskID: p.Meta.TaskID, GrantID: p.Meta.GrantID, Manifest: p.Meta.Manifest, Tool: p.Name, Arguments: p.Arguments}
		id, reason := s.gate.Prepare("demo_user", c)
		if reason != "" {
			failure(-32001, reason)
			return
		}
		result, reason := s.gate.Commit("demo_user", id)
		if reason != "" {
			failure(-32001, reason)
			return
		}
		data, _ := json.Marshal(result)
		reply(map[string]any{"content": []map[string]any{{"type": "text", "text": string(data)}}, "isError": false})
	default:
		failure(-32601, "method_not_found")
	}
}

// Exported for local-only manual test clients.
func SampleGrant(id, task, tool, scope, manifest string, sources []string) Grant {
	return Grant{ID: id, Principal: "demo_user", TaskID: task, Tool: tool, Scope: scope, Manifest: manifest, Sources: sources, ExpiresAt: time.Now().Add(30 * time.Minute)}
}
