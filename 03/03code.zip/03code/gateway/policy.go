package gateway

import (
	"encoding/json"
	"errors"
	"fmt"
	"path"
	"strings"
	"time"
)

var tools = []string{"fake_mail.read", "fake_database.read", "fake_report.write", "fake_webhook.post"}

// validScope rejects traversal even in policy definitions, not only in calls.
func validScope(scope string) bool {
	if scope == "" || strings.Contains(scope, "..") || strings.Contains(scope, "\\") || strings.HasPrefix(scope, "/") {
		return false
	}
	return path.Clean(strings.TrimSuffix(scope, "/")) == strings.TrimSuffix(scope, "/")
}

// withinScope checks the delegation itself; objects are checked separately.
func withinScope(parent, child string) bool {
	return parent == child || (strings.HasSuffix(parent, "/") && strings.HasPrefix(child, parent))
}

// scopeCovers treats the final slash as a directory boundary, not arbitrary prefix.
func scopeCovers(scope, object string) bool {
	if scope == "" || object == "" || strings.Contains(object, "\\") || strings.Contains(object, "..") {
		return false
	}
	if path.Clean(object) != object || strings.HasPrefix(object, "/") {
		return false
	}
	return object == scope || (strings.HasSuffix(scope, "/") && strings.HasPrefix(object, scope))
}

func contains(xs []string, wanted string) bool {
	for _, x := range xs {
		if x == wanted {
			return true
		}
	}
	return false
}

// check is called at preparation AND while committing under the same mutex as effects.
func (g *Gate) check(principal string, c Call, now time.Time) (Grant, string) {
	p, ok := g.grants[c.GrantID]
	if !ok || !p.Active || p.Principal != principal || p.TaskID != c.TaskID || p.Tool != c.Tool {
		return Grant{}, "grant_mismatch"
	}
	if !now.Before(p.ExpiresAt) {
		return Grant{}, "expired"
	}
	for parentID := p.ParentID; parentID != ""; {
		ancestor, found := g.grants[parentID]
		if !found || !ancestor.Active || !now.Before(ancestor.ExpiresAt) {
			return Grant{}, "ancestor_revoked"
		}
		parentID = ancestor.ParentID
	}
	current, ok := g.manifests[c.Tool]
	if !ok || p.Manifest != current || c.Manifest != current {
		return Grant{}, "manifest_changed"
	}
	var err error
	switch c.Tool {
	case "fake_mail.read":
		var a struct {
			MessageID string `json:"message_id"`
		}
		err = decodeStrict(c.Arguments, &a)
		if err == nil && (!scopeCovers(p.Scope, a.MessageID) || a.MessageID != "mail-1") {
			err = errDenied
		}
	case "fake_database.read":
		var a struct {
			RecordID string `json:"record_id"`
		}
		err = decodeStrict(c.Arguments, &a)
		if err == nil && (!scopeCovers(p.Scope, a.RecordID) || a.RecordID != "customer-1") {
			err = errDenied
		}
	case "fake_report.write":
		var a struct {
			Path       string `json:"path"`
			ContentRef string `json:"content_ref"`
		}
		err = decodeStrict(c.Arguments, &a)
		if err == nil && !scopeCovers(p.Scope, a.Path) {
			err = errDenied
		}
		if err == nil {
			err = g.checkArtifact(a.ContentRef, principal, c.TaskID, p.Sources)
		}
	case "fake_webhook.post":
		var a struct {
			Destination string `json:"destination"`
			PayloadRef  string `json:"payload_ref"`
		}
		err = decodeStrict(c.Arguments, &a)
		if err == nil && (!contains(p.Destinations, a.Destination) || !strings.HasPrefix(a.Destination, "local://")) {
			err = errDenied
		}
		if err == nil {
			err = g.checkArtifact(a.PayloadRef, principal, c.TaskID, p.Sources)
		}
	default:
		return Grant{}, "unknown_tool"
	}
	if err != nil {
		return Grant{}, "argument_or_provenance_denied"
	}
	return p, ""
}

func (g *Gate) checkArtifact(ref, principal, task string, allowed []string) error {
	a, ok := g.artifacts[ref]
	if !ok || a.Owner != principal || a.TaskID != task || !contains(allowed, a.Label) {
		return errDenied
	}
	return nil
}

// Manifest hashes are pinned to the approved tool definition, not a tool's self-reported name.
func manifestDigest(tool string, version uint64) string {
	return hash([]byte(fmt.Sprintf("mcp-zerogate:v1:%s:%d", tool, version)))
}

func (g *Gate) validateGrant(p Grant) error {
	if p.ID == "" || p.Principal == "" || p.TaskID == "" || !validScope(p.Scope) || !p.ExpiresAt.After(time.Now()) {
		return errors.New("invalid grant identity/scope/expiry")
	}
	if _, exists := g.grants[p.ID]; exists {
		return errors.New("duplicate grant")
	}
	digest, ok := g.manifests[p.Tool]
	if !ok || p.Manifest != digest {
		return errors.New("manifest must be current")
	}
	if len(p.Destinations) > 8 || len(p.Sources) > 8 {
		return errors.New("too many constraints")
	}
	for _, s := range p.Sources {
		if s != "untrusted_mail_body" && s != "restricted_database" && s != "trusted_admin" {
			return errors.New("unknown source label")
		}
	}
	for _, d := range p.Destinations {
		if !strings.HasPrefix(d, "local://") {
			return errors.New("only local mock destinations")
		}
	}
	if p.Tool == "fake_webhook.post" && len(p.Destinations) == 0 {
		return errors.New("missing destinations")
	}
	if (p.Tool == "fake_report.write" || p.Tool == "fake_webhook.post") && len(p.Sources) == 0 {
		return errors.New("missing allowed source labels")
	}
	// Prevent unstructured delegation and unsafe broad grants.
	if (p.Tool == "fake_report.write" && !strings.HasPrefix(p.Scope, "reports/")) || (p.Tool == "fake_mail.read" && p.Scope != "mail-1") || (p.Tool == "fake_database.read" && p.Scope != "customer-1") {
		return errors.New("unsupported object scope")
	}
	if p.ParentID != "" {
		parent, found := g.grants[p.ParentID]
		if !found || !parent.Active || parent.Principal != p.Principal || parent.TaskID != p.TaskID || parent.Tool != p.Tool || parent.Manifest != p.Manifest || p.ExpiresAt.After(parent.ExpiresAt) || !withinScope(parent.Scope, p.Scope) {
			return errors.New("delegation cannot expand parent authorization")
		}
		for _, source := range p.Sources {
			if !contains(parent.Sources, source) {
				return errors.New("delegation expands permitted sources")
			}
		}
		for _, destination := range p.Destinations {
			if !contains(parent.Destinations, destination) {
				return errors.New("delegation expands destinations")
			}
		}
	}
	return nil
}

func (g *Gate) parseCall(body []byte) (Call, error) {
	var c Call
	if err := decodeStrict(body, &c); err != nil {
		return c, err
	}
	if c.TaskID == "" || c.GrantID == "" || c.Tool == "" || len(c.Arguments) == 0 {
		return c, errors.New("missing call field")
	}
	// Normalize JSON so differences in whitespace cannot alter ticket binding.
	var data any
	if err := json.Unmarshal(c.Arguments, &data); err != nil {
		return c, err
	}
	c.Arguments, _ = json.Marshal(data)
	return c, nil
}
