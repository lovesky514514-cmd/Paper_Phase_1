package gateway

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"strings"
	"time"
)

// Grant is trusted administrative intent, never Agent-generated permission.
type Grant struct {
	ID           string    `json:"id"`
	ParentID     string    `json:"parent_id,omitempty"`
	Principal    string    `json:"principal"`
	TaskID       string    `json:"task_id"`
	Tool         string    `json:"tool"`
	Scope        string    `json:"scope"`
	Destinations []string  `json:"destinations,omitempty"`
	Sources      []string  `json:"sources,omitempty"`
	Manifest     string    `json:"manifest"`
	ExpiresAt    time.Time `json:"expires_at"`
	Version      uint64    `json:"version"`
	Active       bool      `json:"active"`
}

// Call has no field for a principal: authentication determines the caller.
type Call struct {
	TaskID    string          `json:"task_id"`
	GrantID   string          `json:"grant_id"`
	Tool      string          `json:"tool"`
	Manifest  string          `json:"manifest"`
	Arguments json.RawMessage `json:"arguments"`
}

type Ticket struct {
	ID        string `json:"ticket"`
	grantID   string
	principal string
	version   uint64
	manifest  string
	digest    string
	expires   time.Time
	call      Call
}

type Artifact struct {
	Value   string   `json:"value"`
	Label   string   `json:"label"`
	Owner   string   `json:"-"`
	TaskID  string   `json:"-"`
	Parents []string `json:"parents,omitempty"`
}

type Record struct {
	Sequence  int       `json:"sequence"`
	Time      time.Time `json:"time"`
	Principal string    `json:"principal"`
	TaskID    string    `json:"task_id"`
	Tool      string    `json:"tool"`
	Decision  string    `json:"decision"`
	Reason    string    `json:"reason"`
	PrevHash  string    `json:"prev_hash"`
	Hash      string    `json:"hash"`
}

var errDenied = errors.New("denied")

func randomID() string {
	var b [24]byte
	if _, err := rand.Read(b[:]); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b[:])
}

func hash(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

// Strict JSON decoding prevents unreviewed policy/argument fields being ignored.
func decodeStrict(raw []byte, dst any) error {
	d := json.NewDecoder(strings.NewReader(string(raw)))
	d.DisallowUnknownFields()
	if err := d.Decode(dst); err != nil {
		return err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return errors.New("trailing or invalid JSON")
	}
	if len(strings.TrimSpace(string(raw))) == 0 {
		return errors.New("empty body")
	}
	return nil
}
