package gateway

import (
	"encoding/json"
	"fmt"
	"sync"
	"testing"
	"time"
)

func call(task, id, tool, manifest string, args map[string]any) Call {
	payload, _ := json.Marshal(args)
	return Call{TaskID: task, GrantID: id, Tool: tool, Manifest: manifest, Arguments: payload}
}
func grant(g *Gate, id, task, tool, scope string, sources ...string) Grant {
	return SampleGrant(id, task, tool, scope, g.Manifests()[tool], sources)
}
func must(t *testing.T, err error) {
	t.Helper()
	if err != nil {
		t.Fatal(err)
	}
}
func run(t *testing.T, g *Gate, c Call) (map[string]any, string) {
	t.Helper()
	ticket, reason := g.Prepare("demo_user", c)
	if reason != "" {
		return nil, reason
	}
	return g.Commit("demo_user", ticket)
}
func TestLegalReportAndTaintEnforcement(t *testing.T) {
	g := New()
	must(t, g.AddGrant(grant(g, "r", "a", "fake_mail.read", "mail-1")))
	must(t, g.AddGrant(grant(g, "w", "a", "fake_report.write", "reports/weekly/", "untrusted_mail_body")))
	read, err := run(t, g, call("a", "r", "fake_mail.read", g.Manifests()["fake_mail.read"], map[string]any{"message_id": "mail-1"}))
	if err != "" {
		t.Fatal(err)
	}
	ref := read["ref"].(string)
	result, err := run(t, g, call("a", "w", "fake_report.write", g.Manifests()["fake_report.write"], map[string]any{"path": "reports/weekly/test", "content_ref": ref}))
	if err != "" || result["saved"] != true {
		t.Fatalf("write failed: %v %s", result, err)
	}
	must(t, g.AddGrant(grant(g, "d", "a", "fake_database.read", "customer-1")))
	db, err := run(t, g, call("a", "d", "fake_database.read", g.Manifests()["fake_database.read"], map[string]any{"record_id": "customer-1"}))
	if err != "" {
		t.Fatal(err)
	}
	_, err = run(t, g, call("a", "w", "fake_report.write", g.Manifests()["fake_report.write"], map[string]any{"path": "reports/weekly/leak", "content_ref": db["ref"]}))
	if err == "" {
		t.Fatal("restricted data reached report")
	}
	if len(g.Effects()["report_paths"].([]string)) != 1 {
		t.Fatal("unexpected side effect")
	}
}
func TestPreparedTicketInvalidatedByRevocation(t *testing.T) {
	g := New()
	must(t, g.AddGrant(grant(g, "r", "task", "fake_mail.read", "mail-1")))
	c := call("task", "r", "fake_mail.read", g.Manifests()["fake_mail.read"], map[string]any{"message_id": "mail-1"})
	ticket, reason := g.Prepare("demo_user", c)
	if reason != "" {
		t.Fatal(reason)
	}
	must(t, g.Revoke("r"))
	if _, reason = g.Commit("demo_user", ticket); reason == "" {
		t.Fatal("revoked ticket executed")
	}
	if _, reason = g.Commit("demo_user", ticket); reason != "invalid_or_used_ticket" {
		t.Fatalf("not single-use: %s", reason)
	}
}
func TestManifestRotation(t *testing.T) {
	g := New()
	old := g.Manifests()["fake_mail.read"]
	must(t, g.AddGrant(grant(g, "r", "task", "fake_mail.read", "mail-1")))
	if _, err := g.Rotate("fake_mail.read"); err != nil {
		t.Fatal(err)
	}
	if _, reason := g.Prepare("demo_user", call("task", "r", "fake_mail.read", old, map[string]any{"message_id": "mail-1"})); reason != "manifest_changed" {
		t.Fatalf("got %s", reason)
	}
}
func TestCrossTaskAndPathTraversal(t *testing.T) {
	g := New()
	must(t, g.AddGrant(grant(g, "r", "task", "fake_report.write", "reports/weekly/", "trusted_admin")))
	ref, err := g.DeriveTrusted("demo_user", "task", "synthetic", nil)
	must(t, err)
	for _, p := range []string{"reports/weekly/../customer", "reports/weekly2/f", "/reports/weekly/a"} {
		_, reason := g.Prepare("demo_user", call("task", "r", "fake_report.write", g.Manifests()["fake_report.write"], map[string]any{"path": p, "content_ref": ref}))
		if reason == "" {
			t.Errorf("accepted path %s", p)
		}
	}
	_, reason := g.Prepare("demo_user", call("another-task", "r", "fake_report.write", g.Manifests()["fake_report.write"], map[string]any{"path": "reports/weekly/a", "content_ref": ref}))
	if reason == "" {
		t.Fatal("cross-task grant reuse")
	}
}
func TestConcurrentReplayOneCommit(t *testing.T) {
	g := New()
	ref, err := g.DeriveTrusted("demo_user", "task", "synthetic", nil)
	must(t, err)
	p := grant(g, "w", "task", "fake_webhook.post", "local/", "trusted_admin")
	p.Destinations = []string{"local://review"}
	must(t, g.AddGrant(p))
	c := call("task", "w", "fake_webhook.post", g.Manifests()["fake_webhook.post"], map[string]any{"destination": "local://review", "payload_ref": ref})
	ticket, reason := g.Prepare("demo_user", c)
	if reason != "" {
		t.Fatal(reason)
	}
	var wg sync.WaitGroup
	results := make(chan string, 100)
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); _, r := g.Commit("demo_user", ticket); results <- r }()
	}
	wg.Wait()
	close(results)
	success := 0
	for result := range results {
		if result == "" {
			success++
		}
	}
	if success != 1 || len(g.Effects()["webhook_destinations"].([]string)) != 1 {
		t.Fatalf("commits: %d", success)
	}
}
func TestConcurrentRevocationSerialization(t *testing.T) {
	// Whatever happens first under the mutex wins; nothing can commit after revoke.
	for iteration := 0; iteration < 100; iteration++ {
		g := New()
		ref, err := g.DeriveTrusted("demo_user", "task", "data", nil)
		must(t, err)
		must(t, g.AddGrant(grant(g, "w", "task", "fake_report.write", "reports/weekly/", "trusted_admin")))
		ticket, reason := g.Prepare("demo_user", call("task", "w", "fake_report.write", g.Manifests()["fake_report.write"], map[string]any{"path": "reports/weekly/r", "content_ref": ref}))
		if reason != "" {
			t.Fatal(reason)
		}
		var wg sync.WaitGroup
		wg.Add(2)
		go func() { defer wg.Done(); _, _ = g.Commit("demo_user", ticket) }()
		go func() { defer wg.Done(); _ = g.Revoke("w") }()
		wg.Wait()
		events := g.Audit()
		revokeAt, executeAt := 0, 0
		for _, event := range events {
			if event.Decision == "revoke" {
				revokeAt = event.Sequence
			}
			if event.Decision == "execute" {
				executeAt = event.Sequence
			}
		}
		if executeAt > revokeAt && revokeAt > 0 {
			t.Fatalf("execution after revoke, iteration %d", iteration)
		}
	}
}
func TestStrictDecodeAndExpiry(t *testing.T) {
	g := New()
	p := grant(g, "r", "t", "fake_mail.read", "mail-1")
	p.ExpiresAt = time.Now().Add(-time.Second)
	if err := g.AddGrant(p); err == nil {
		t.Fatal("accepted expired policy")
	}
	must(t, g.AddGrant(grant(g, "r", "t", "fake_mail.read", "mail-1")))
	for _, raw := range []string{`{"message_id":"mail-1","debug":true}`, `{"message_id":"mail-1"} false`, `{"message_id":"mail-1"} x`} {
		c := Call{TaskID: "t", GrantID: "r", Tool: "fake_mail.read", Manifest: g.Manifests()["fake_mail.read"], Arguments: []byte(raw)}
		if _, reason := g.Prepare("demo_user", c); reason == "" {
			t.Fatal("unsafe JSON accepted", raw)
		}
	}
	// source refs must be task scoped, even after an admin-approved derivation.
	ref, err := g.DeriveTrusted("demo_user", "t", "okay", nil)
	must(t, err)
	if _, err = g.DeriveTrusted("demo_user", "other", "bad", []string{ref}); err == nil {
		t.Fatal("source cross task")
	}
}
func TestAuditChain(t *testing.T) {
	g := New()
	must(t, g.AddGrant(grant(g, "r", "t", "fake_mail.read", "mail-1")))
	records := g.Audit()
	prev := "genesis"
	for _, record := range records {
		if record.PrevHash != prev {
			t.Fatal("broken prev link")
		}
		expected := record.Hash
		record.Hash = ""
		payload, _ := json.Marshal(record)
		if hash(payload) != expected {
			t.Fatal("invalid digest")
		}
		prev = expected
	}
}
func BenchmarkPrepareCommit(b *testing.B) {
	g := New()
	for i := 0; i < b.N; i++ {
		id := fmt.Sprintf("r-%d", i)
		_ = g.AddGrant(grant(g, id, id, "fake_mail.read", "mail-1"))
		c := call(id, id, "fake_mail.read", g.Manifests()["fake_mail.read"], map[string]any{"message_id": "mail-1"})
		ticket, _ := g.Prepare("demo_user", c)
		_, _ = g.Commit("demo_user", ticket)
	}
}

func TestDelegationAttenuation(t *testing.T) {
	g := New()
	parent := grant(g, "parent", "task", "fake_report.write", "reports/weekly/", "untrusted_mail_body")
	parent.ExpiresAt = time.Now().Add(time.Hour)
	must(t, g.AddGrant(parent))
	child := grant(g, "child", "task", "fake_report.write", "reports/weekly/sub/", "untrusted_mail_body")
	child.ParentID = "parent"
	must(t, g.AddGrant(child))
	wide := grant(g, "wide", "task", "fake_report.write", "reports/", "untrusted_mail_body")
	wide.ParentID = "parent"
	if g.AddGrant(wide) == nil {
		t.Fatal("delegation widened report prefix")
	}
	extra := grant(g, "extra", "task", "fake_report.write", "reports/weekly/", "restricted_database")
	extra.ParentID = "parent"
	if g.AddGrant(extra) == nil {
		t.Fatal("delegation widened data label")
	}
	ref, err := g.DeriveTrusted("demo_user", "task", "data", nil)
	must(t, err)
	_ = ref
	must(t, g.Revoke("parent"))
	_, reason := g.Prepare("demo_user", call("task", "child", "fake_report.write", g.Manifests()["fake_report.write"], map[string]any{"path": "reports/weekly/sub/a", "content_ref": ref}))
	if reason != "ancestor_revoked" {
		t.Fatalf("expected ancestor_revoked, got %s", reason)
	}
}

func TestProvenanceEdges(t *testing.T) {
	g := New()
	must(t, g.AddGrant(grant(g, "mail", "task", "fake_mail.read", "mail-1")))
	a, reason := run(t, g, call("task", "mail", "fake_mail.read", g.Manifests()["fake_mail.read"], map[string]any{"message_id": "mail-1"}))
	if reason != "" {
		t.Fatal(reason)
	}
	source := a["ref"].(string)
	dest, err := g.DeriveTrusted("demo_user", "task", "summary", []string{source})
	must(t, err)
	nodes := g.Provenance()
	if nodes[dest]["label"] != "untrusted_mail_body" {
		t.Fatal("derived input was laundered")
	}
	parents := nodes[dest]["parents"].([]string)
	if len(parents) != 1 || parents[0] != source {
		t.Fatal("missing provenance edge")
	}
}
