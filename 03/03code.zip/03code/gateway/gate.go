package gateway

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// Gate owns policy, one-use tickets, provenance and mock effects under one lock.
// This is a lab linearization model, NOT distributed exactly-once semantics.
type Gate struct {
	mu        sync.Mutex
	grants    map[string]Grant
	manifests map[string]string
	versions  map[string]uint64
	tickets   map[string]Ticket
	artifacts map[string]Artifact
	reports   map[string]string
	webhooks  []string
	audit     []Record
	now       func() time.Time
}

func New() *Gate {
	g := &Gate{
		grants: make(map[string]Grant), manifests: make(map[string]string), versions: make(map[string]uint64),
		tickets: make(map[string]Ticket), artifacts: make(map[string]Artifact), reports: make(map[string]string), now: time.Now,
	}
	for _, tool := range tools {
		g.versions[tool] = 1
		g.manifests[tool] = manifestDigest(tool, 1)
	}
	return g
}

func (g *Gate) Manifests() map[string]string {
	g.mu.Lock()
	defer g.mu.Unlock()
	out := make(map[string]string, len(g.manifests))
	for name, digest := range g.manifests {
		out[name] = digest
	}
	return out
}

func (g *Gate) AddGrant(p Grant) error {
	g.mu.Lock()
	defer g.mu.Unlock()
	if err := g.validateGrant(p); err != nil {
		return err
	}
	p.Active = true
	p.Version = 1 // Admin cannot forge live grant state.
	g.grants[p.ID] = p
	g.log(p.Principal, p.TaskID, p.Tool, "grant", "admin_approval")
	return nil
}

func (g *Gate) Revoke(id string) error {
	g.mu.Lock()
	defer g.mu.Unlock()
	p, ok := g.grants[id]
	if !ok {
		return fmt.Errorf("grant not found")
	}
	p.Active = false
	p.Version++
	g.grants[id] = p
	g.log(p.Principal, p.TaskID, p.Tool, "revoke", "policy_version_changed")
	return nil
}

func (g *Gate) Rotate(tool string) (string, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if _, ok := g.versions[tool]; !ok {
		return "", fmt.Errorf("unknown tool")
	}
	g.versions[tool]++
	g.manifests[tool] = manifestDigest(tool, g.versions[tool])
	g.log("admin", "", tool, "rotate", "manifest_changed")
	return g.manifests[tool], nil
}

// Prepare only authorizes a future attempt; it does not execute anything.
func (g *Gate) Prepare(principal string, c Call) (string, string) {
	g.mu.Lock()
	defer g.mu.Unlock()
	p, reason := g.check(principal, c, g.now())
	if reason != "" {
		g.log(principal, c.TaskID, c.Tool, "deny", reason)
		return "", reason
	}
	encoded, _ := json.Marshal(c)
	id := randomID()
	g.tickets[id] = Ticket{ID: id, grantID: p.ID, principal: principal, version: p.Version, manifest: p.Manifest, digest: hash(encoded), expires: g.now().Add(30 * time.Second), call: c}
	g.log(principal, c.TaskID, c.Tool, "prepare", "pending_commit")
	return id, ""
}

// Commit and effect mutation share a linearization point with Revoke and Rotate.
func (g *Gate) Commit(principal, id string) (map[string]any, string) {
	g.mu.Lock()
	defer g.mu.Unlock()
	t, ok := g.tickets[id]
	if !ok || t.principal != principal {
		return nil, "invalid_or_used_ticket"
	}
	delete(g.tickets, id) // Consume even if policy has changed; never resurrect.
	c := t.call
	p, reason := g.check(principal, c, g.now())
	if reason == "" && (t.version != p.Version || t.manifest != p.Manifest || !g.now().Before(t.expires)) {
		reason = "stale_or_expired_ticket"
	}
	serialized, _ := json.Marshal(c)
	if reason == "" && hash(serialized) != t.digest {
		reason = "ticket_binding_mismatch"
	}
	if reason != "" {
		g.log(principal, c.TaskID, c.Tool, "deny", reason)
		return nil, reason
	}
	result := g.effect(principal, c)
	g.log(principal, c.TaskID, c.Tool, "execute", "mock_effect_committed")
	return result, ""
}

// Effects are strictly local and simulated: no payment, email or network egress.
func (g *Gate) effect(principal string, c Call) map[string]any {
	switch c.Tool {
	case "fake_mail.read":
		ref := randomID()
		g.artifacts[ref] = Artifact{Value: "Weekly project update: synthetic milestone complete.", Label: "untrusted_mail_body", Owner: principal, TaskID: c.TaskID}
		return map[string]any{"ref": ref, "value": g.artifacts[ref].Value, "label": "untrusted_mail_body"}
	case "fake_database.read":
		ref := randomID()
		g.artifacts[ref] = Artifact{Value: "SYNTHETIC_CUSTOMER_001", Label: "restricted_database", Owner: principal, TaskID: c.TaskID}
		return map[string]any{"ref": ref, "value": g.artifacts[ref].Value, "label": "restricted_database"}
	case "fake_report.write":
		var a struct {
			Path       string `json:"path"`
			ContentRef string `json:"content_ref"`
		}
		_ = json.Unmarshal(c.Arguments, &a)
		g.reports[a.Path] = g.artifacts[a.ContentRef].Value
		return map[string]any{"path": a.Path, "saved": true}
	case "fake_webhook.post":
		var a struct {
			Destination string `json:"destination"`
			PayloadRef  string `json:"payload_ref"`
		}
		_ = json.Unmarshal(c.Arguments, &a)
		g.webhooks = append(g.webhooks, a.Destination)
		return map[string]any{"destination": a.Destination, "accepted": true}
	}
	panic("unreachable: tool validated at prepare and commit")
}

func (g *Gate) DeriveTrusted(principal, taskID, value string, refs []string) (string, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if len(value) == 0 || len(value) > 4096 || principal == "" || taskID == "" {
		return "", fmt.Errorf("invalid derived artifact")
	}
	// Conservative propagation: derived values retain all restrictive labels.
	label := "trusted_admin"
	for _, ref := range refs {
		a, ok := g.artifacts[ref]
		if !ok || a.Owner != principal || a.TaskID != taskID {
			return "", fmt.Errorf("unknown source reference")
		}
		if a.Label == "restricted_database" {
			label = "restricted_database"
		} else if a.Label == "untrusted_mail_body" && label != "restricted_database" {
			label = "untrusted_mail_body"
		}
	}
	ref := randomID()
	g.artifacts[ref] = Artifact{Value: value, Label: label, Owner: principal, TaskID: taskID, Parents: append([]string(nil), refs...)}
	g.log(principal, taskID, "provenance", "derive", "source_labels_propagated")
	return ref, nil
}

// Provenance returns reference/label edges only, never payload values.
func (g *Gate) Provenance() map[string]map[string]any {
	g.mu.Lock()
	defer g.mu.Unlock()
	out := make(map[string]map[string]any, len(g.artifacts))
	for id, a := range g.artifacts {
		out[id] = map[string]any{"label": a.Label, "task_id": a.TaskID, "parents": append([]string{}, a.Parents...)}
	}
	return out
}

func (g *Gate) Effects() map[string]any {
	g.mu.Lock()
	defer g.mu.Unlock()
	// Never reveal report contents or secret-like demo data via this endpoint.
	paths := make([]string, 0, len(g.reports))
	for p := range g.reports {
		paths = append(paths, p)
	}
	return map[string]any{"report_paths": paths, "webhook_destinations": append([]string{}, g.webhooks...)}
}

func (g *Gate) Audit() []Record {
	g.mu.Lock()
	defer g.mu.Unlock()
	return append([]Record{}, g.audit...)
}

func (g *Gate) log(principal, task, tool, decision, reason string) {
	prev := "genesis"
	if len(g.audit) > 0 {
		prev = g.audit[len(g.audit)-1].Hash
	}
	r := Record{Sequence: len(g.audit) + 1, Time: g.now().UTC(), Principal: principal, TaskID: task, Tool: tool, Decision: decision, Reason: reason, PrevHash: prev}
	payload, _ := json.Marshal(r)
	r.Hash = hash(payload)
	g.audit = append(g.audit, r)
}
