"""SQLite effect ledger with transaction claims and generation fencing."""

from contextlib import contextmanager
from dataclasses import dataclass
import json
from pathlib import Path
import sqlite3
import time

from .model import Call, canonical

SCHEMA = """
CREATE TABLE IF NOT EXISTS effects (
  tenant TEXT NOT NULL,
  task TEXT NOT NULL,
  intent TEXT NOT NULL,
  step TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  tool TEXT NOT NULL,
  dependencies TEXT NOT NULL,
  state TEXT NOT NULL,
  generation INTEGER NOT NULL,
  updated REAL NOT NULL,
  result TEXT,
  evidence TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (tenant, task, intent),
  UNIQUE (tenant, task, step)
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at REAL NOT NULL,
  tenant TEXT NOT NULL,
  task TEXT NOT NULL,
  intent TEXT NOT NULL,
  event TEXT NOT NULL,
  evidence TEXT NOT NULL
);
"""


class Conflict(ValueError):
    """The requested action conflicts with a recorded logical action."""


@dataclass(frozen=True)
class Record:
    state: str
    generation: int
    updated: float
    result: dict | None


class Ledger:
    """Owns atomic dispatch/compensation claims; does not issue network calls."""

    def __init__(self, filename: str):
        self.filename = filename
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.executescript(SCHEMA)

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.filename, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=10000")
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=FULL")
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _event(db, call: Call, event: str, evidence: str = ""):
        # Never log request args, response bodies or authorization secrets.
        db.execute("INSERT INTO events(at,tenant,task,intent,event,evidence) VALUES(?,?,?,?,?,?)",
                   (time.time(), call.tenant, call.task, call.intent, event, evidence))

    @staticmethod
    def _record(row) -> Record:
        return Record(row["state"], row["generation"], row["updated"],
                      json.loads(row["result"]) if row["result"] else None)

    def claim(self, call: Call) -> tuple[Record, bool]:
        """First dispatch wins; all later callers inspect the same record."""
        with self._db() as db:
            row = db.execute("SELECT * FROM effects WHERE tenant=? AND task=? AND intent=?",
                             (call.tenant, call.task, call.intent)).fetchone()
            if row:
                if row["fingerprint"] != call.fingerprint:
                    raise Conflict("相同意图的主体、参数、步骤或依赖已改变")
                return self._record(row), False
            other = db.execute("SELECT 1 FROM effects WHERE tenant=? AND task=? AND step=?",
                               (call.tenant, call.task, call.step)).fetchone()
            if other:
                raise Conflict("step 已绑定其他意图")
            for dependency in call.dependencies:
                prior = db.execute("SELECT state FROM effects WHERE tenant=? AND task=? AND step=?",
                                   (call.tenant, call.task, dependency)).fetchone()
                if not prior or prior["state"] != "confirmed":
                    raise Conflict(f"依赖未确认：{dependency}")
            now = time.time()
            db.execute("""INSERT INTO effects
                (tenant,task,intent,step,fingerprint,tool,dependencies,state,generation,updated)
                VALUES(?,?,?,?,?,?,?,'in_flight',1,?)""",
                (call.tenant, call.task, call.intent, call.step,
                 call.fingerprint, call.tool, canonical(call.dependencies), now))
            self._event(db, call, "dispatch", "new")
            return Record("in_flight", 1, now, None), True

    def record(self, call: Call) -> Record | None:
        with self._db() as db:
            row = db.execute("SELECT * FROM effects WHERE tenant=? AND task=? AND intent=?",
                             (call.tenant, call.task, call.intent)).fetchone()
            if row and row["fingerprint"] != call.fingerprint:
                raise Conflict("意图语义不一致")
            return self._record(row) if row else None

    def complete(self, call: Call, generation: int, state: str,
                 result: dict | None, evidence: str) -> bool:
        """Only the current owner can complete. Late workers cannot overwrite newer claims."""
        if state not in {"confirmed", "unknown"}:
            raise ValueError("invalid transition")
        with self._db() as db:
            count = db.execute("""UPDATE effects SET state=?,result=?,evidence=?,updated=?
                WHERE tenant=? AND task=? AND intent=? AND fingerprint=?
                AND generation=? AND state='in_flight'""",
                (state, canonical(result) if result is not None else None, evidence,
                 time.time(), call.tenant, call.task, call.intent, call.fingerprint, generation)).rowcount
            if count:
                self._event(db, call, state, evidence)
            return bool(count)

    def reconcile(self, call: Call, verified_result: dict) -> bool:
        """A positive upstream proof can resolve UNKNOWN without dispatching again."""
        with self._db() as db:
            count = db.execute("""UPDATE effects SET state='confirmed',result=?,evidence=?,updated=?
                WHERE tenant=? AND task=? AND intent=? AND fingerprint=?
                AND state IN ('unknown','in_flight','confirmed')""",
                (canonical(verified_result), "positive_readback", time.time(),
                 call.tenant, call.task, call.intent, call.fingerprint)).rowcount
            if count:
                self._event(db, call, "reconcile", "positive_readback")
            return bool(count)

    def retry_claim(self, call: Call, generation: int, stale_after: float) -> int | None:
        """CAS retry ownership, only after original lease expires or is UNKNOWN."""
        with self._db() as db:
            row = db.execute("SELECT state,generation,updated FROM effects WHERE tenant=? AND task=? AND intent=?",
                             (call.tenant, call.task, call.intent)).fetchone()
            if not row or row["generation"] != generation:
                return None
            if row["state"] == "in_flight" and time.time() - row["updated"] < stale_after:
                return None
            if row["state"] not in {"in_flight", "unknown"}:
                return None
            count = db.execute("""UPDATE effects SET generation=generation+1,
                state='in_flight',updated=?,evidence=''
                WHERE tenant=? AND task=? AND intent=? AND generation=?
                AND state IN ('in_flight','unknown')""",
                (time.time(), call.tenant, call.task, call.intent, generation)).rowcount
            if not count:
                return None
            self._event(db, call, "retry_claim", "verified_safe_operation")
            return generation + 1

    def mark_stale(self, call: Call, generation: int) -> None:
        """An expired high-risk lease becomes UNKNOWN, never a permission to retry."""
        with self._db() as db:
            changed = db.execute("""UPDATE effects SET state='unknown',updated=?,evidence='stale_owner'
                WHERE tenant=? AND task=? AND intent=? AND generation=? AND state='in_flight'""",
                (time.time(), call.tenant, call.task, call.intent, generation)).rowcount
            if changed:
                self._event(db, call, "unknown", "stale_owner")

    def claim_compensation(self, call: Call) -> tuple[int, dict] | None:
        """Claim once; never compensate a parent of an already-confirmed dependent."""
        with self._db() as db:
            row = db.execute("SELECT * FROM effects WHERE tenant=? AND task=? AND intent=?",
                             (call.tenant, call.task, call.intent)).fetchone()
            if not row or row["fingerprint"] != call.fingerprint or row["state"] != "confirmed":
                return None
            dependents = db.execute("""SELECT dependencies FROM effects
                WHERE tenant=? AND task=? AND state IN ('in_flight','confirmed','unknown','compensating','compensation_unknown')""",
                (call.tenant, call.task)).fetchall()
            if any(call.step in json.loads(d["dependencies"]) for d in dependents):
                raise Conflict("下游步骤可能已执行，不能单独补偿上游")
            generation = row["generation"] + 1
            db.execute("""UPDATE effects SET state='compensating',generation=?,updated=?
                WHERE tenant=? AND task=? AND intent=?""",
                (generation, time.time(), call.tenant, call.task, call.intent))
            self._event(db, call, "compensating", "approved")
            return generation, json.loads(row["result"])

    def finish_compensation(self, call: Call, generation: int, confirmed: bool) -> None:
        state = "compensated" if confirmed else "compensation_unknown"
        with self._db() as db:
            count = db.execute("""UPDATE effects SET state=?,updated=?,evidence=?
                WHERE tenant=? AND task=? AND intent=? AND generation=? AND state='compensating'""",
                (state, time.time(), "compensation_ack" if confirmed else "compensation_uncertain",
                 call.tenant, call.task, call.intent, generation)).rowcount
            if count:
                self._event(db, call, state)

    def events(self) -> list[dict]:
        with self._db() as db:
            return [dict(row) for row in db.execute("SELECT at,tenant,task,intent,event,evidence FROM events ORDER BY id")]
