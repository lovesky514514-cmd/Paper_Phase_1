"""Loopback-only JSON endpoint for HTTP/MCP adapters to call."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
import os

from .gateway import Gateway
from .ledger import Ledger
from .transport import SandboxClient


class Handler(BaseHTTPRequestHandler):
    gateway: Gateway
    api_key: str
    approval_key: str

    def log_message(self, fmt, *args):
        # No request payloads, access keys or business IDs in access logs.
        return

    def send_json(self, status: int, value: dict) -> None:
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except (ConnectionResetError, BrokenPipeError):
            # A disconnected client is exactly the uncertainty we study.
            pass

    def do_GET(self):
        if self.path == "/healthz":
            return self.send_json(200, {"status": "ok"})
        return self.send_json(404, {"error": "not_found"})

    def do_POST(self):
        if self.path not in {"/v1/calls", "/v1/compensate"}:
            return self.send_json(404, {"error": "not_found"})
        if self.api_key and not hmac.compare_digest(
                self.headers.get("X-RAGuard-Key", ""), self.api_key):
            return self.send_json(401, {"error": "unauthorized"})
        if self.path == "/v1/compensate" and (
                not self.approval_key or not hmac.compare_digest(
                    self.headers.get("X-RAGuard-Approval", ""), self.approval_key)):
            return self.send_json(403, {"error": "approval_required"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 8192:
                return self.send_json(413, {"error": "body_size_limit"})
            raw = json.loads(self.rfile.read(length))
        except (TypeError, ValueError, UnicodeError):
            return self.send_json(400, {"error": "invalid_json"})
        try:
            if self.path == "/v1/calls":
                status, response = self.gateway.call(raw)
            else:
                status, response = self.gateway.compensate(raw, approved=True)
        except Exception as exc:
            # Log exception type only, not the payload or sensitive business data.
            print("gateway error:", type(exc).__name__, flush=True)
            return self.send_json(500, {"error": "internal_error"})
        return self.send_json(status, response)


def create_server(gateway: Gateway, *, host: str = "127.0.0.1",
                  port: int = 8088, api_key: str = "",
                  approval_key: str = "") -> ThreadingHTTPServer:
    if host != "127.0.0.1":
        raise ValueError("研究原型只能监听 127.0.0.1")
    handler = type("LocalHandler", (Handler,), {
        "gateway": gateway, "api_key": api_key, "approval_key": approval_key,
    })
    server = ThreadingHTTPServer((host, port), handler)
    server.daemon_threads = True
    return server


def main():
    db = os.environ.get("RAGUARD_DB", "data/ledger.sqlite3")
    origin = os.environ.get("RAGUARD_UPSTREAM", "http://127.0.0.1:8181")
    gateway = Gateway(Ledger(db), SandboxClient(origin))
    with create_server(gateway, port=int(os.environ.get("RAGUARD_PORT", "8088")),
                       api_key=os.environ.get("RAGUARD_API_KEY", ""),
                       approval_key=os.environ.get("RAGUARD_APPROVAL_KEY", "")) as server:
        print(f"RAGuard: http://127.0.0.1:{server.server_port}", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()
