"""RAGuard: conservative recovery for sandbox tool calls."""
