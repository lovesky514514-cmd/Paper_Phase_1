"""Trusted effect policies, deliberately not inferred from LLM text."""

from dataclasses import dataclass
from enum import Enum


class Effect(str, Enum):
    READ = "read"
    IDEMPOTENT = "idempotent_write"
    REVERSIBLE = "reversible_write"
    OPAQUE = "opaque_write"


@dataclass(frozen=True)
class ToolPolicy:
    effect: Effect
    readback: bool = False

    @property
    def retryable(self) -> bool:
        # The sandbox *enforces* the stable key for idempotent writes.
        return self.effect in (Effect.READ, Effect.IDEMPOTENT)


# Only the gateway administrator can change these policies.
TOOLS: dict[str, ToolPolicy] = {
    "inventory.read": ToolPolicy(Effect.READ),
    "orders.create": ToolPolicy(Effect.IDEMPOTENT, readback=True),
    "tickets.create": ToolPolicy(Effect.REVERSIBLE, readback=True),
    "notifications.send": ToolPolicy(Effect.OPAQUE),
}
