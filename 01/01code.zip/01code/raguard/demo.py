"""A repeatable order demo: one logical intent, one real write."""

import json
import os
import urllib.error
import urllib.request
from uuid import uuid4


def request(tool: str, step: str, args: dict, dependencies=()) -> dict:
    return {"tenant": "demo", "principal": "researcher",
            "task": os.environ["RAGUARD_DEMO_TASK"],
            "step": step, "intent": step, "tool": tool,
            "args": args, "dependencies": list(dependencies)}


def send(value: dict) -> dict:
    data = json.dumps(value).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if os.environ.get("RAGUARD_API_KEY"):
        headers["X-RAGuard-Key"] = os.environ["RAGUARD_API_KEY"]
    req = urllib.request.Request("http://127.0.0.1:8088/v1/calls", data,
                                 headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        return json.load(exc)


def main():
    # Set RAGUARD_DEMO_TASK to replay the *same* demo between runs.
    os.environ.setdefault("RAGUARD_DEMO_TASK", "demo-" + uuid4().hex[:10])
    inventory = request("inventory.read", "inventory", {"sku": "sku-21"})
    order = request("orders.create", "order", {"sku": "sku-21", "quantity": 1}, ["inventory"])
    for name, value in (("inventory", inventory), ("order", order), ("repeated order", order)):
        print(name, json.dumps(send(value), ensure_ascii=False))


if __name__ == "__main__":
    main()
