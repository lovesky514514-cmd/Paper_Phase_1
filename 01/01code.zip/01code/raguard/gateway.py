"""Single public entry for risk-gated execution, replay and compensation."""

import time

from .ledger import Conflict, Ledger
from .model import BadCall, Call
from .policy import Effect, TOOLS, ToolPolicy
from .transport import SandboxClient, UncertainResult


def reply(action: str, state: str, *, result: dict | None = None,
          reason: str = "") -> dict:
    return {"action": action, "state": state, "result": result, "reason": reason}


class Gateway:
    """Never dispatch an unproven non-idempotent action twice."""

    def __init__(self, ledger: Ledger, upstream: SandboxClient,
                 lease_seconds: float = 5.0):
        if lease_seconds < 0:
            raise ValueError("lease_seconds 必须 >= 0")
        self.ledger = ledger
        self.upstream = upstream
        self.lease_seconds = lease_seconds

    def call(self, raw: object) -> tuple[int, dict]:
        try:
            call = Call.parse(raw)
        except BadCall as exc:
            return 400, reply("reject", "invalid", reason=str(exc))
        policy = TOOLS.get(call.tool)
        if policy is None:
            return 403, reply("reject", "forbidden", reason="工具不在可信注册表")
        try:
            record, is_new = self.ledger.claim(call)
            if is_new:
                return self._execute(call, policy, record.generation)
            if record.state == "confirmed":
                if policy.readback:
                    verified = self.upstream.readback(call, policy)
                    if verified is None:
                        return 409, reply("stop", "unverifiable", reason="已有结果无法核对现态")
                    if not self.ledger.reconcile(call, verified):
                        # A compensation may win during the readback round-trip.
                        return self._current(call)
                    return 200, reply("replay", "confirmed", result=verified)
                return 200, reply("replay", "confirmed", result=record.result)
            if record.state in {"compensated", "compensating", "compensation_unknown"}:
                return 409, reply("stop", record.state, reason="补偿已发生或状态不明")

            # A positive readback takes precedence over any retry, even in-flight.
            verified = self.upstream.readback(call, policy)
            if verified is not None and self.ledger.reconcile(call, verified):
                return 200, reply("replay", "confirmed", result=verified)
            if record.state == "in_flight" and time.time() - record.updated < self.lease_seconds:
                return 202, reply("wait", "in_flight", reason="原调用尚未确认")
            if not policy.retryable:
                self.ledger.mark_stale(call, record.generation)
                return 409, reply("stop", "unknown", reason="可能已写入，禁止重复调用")
            generation = self.ledger.retry_claim(call, record.generation,
                                                  self.lease_seconds)
            if generation is None:
                return 202, reply("wait", "in_flight", reason="另一请求已取得执行权")
            return self._execute(call, policy, generation)
        except Conflict as exc:
            return 409, reply("stop", "conflict", reason=str(exc))

    def _execute(self, call: Call, policy: ToolPolicy,
                 generation: int) -> tuple[int, dict]:
        attempts = 2 if policy.retryable else 1
        for index in range(attempts):
            try:
                result = self.upstream.execute(call, policy)
                if policy.readback:
                    result = self.upstream.readback(call, policy)
                    if result is None:
                        raise UncertainResult("正向回读不可用")
                evidence = "positive_readback" if policy.readback else "http_receipt"
                if self.ledger.complete(call, generation, "confirmed", result, evidence):
                    return 200, reply("execute" if index == 0 else "retry",
                                      "confirmed", result=result)
                return self._current(call)
            except UncertainResult:
                verified = self.upstream.readback(call, policy)
                if verified is not None and self.ledger.reconcile(call, verified):
                    return 200, reply("replay", "confirmed", result=verified)
                # Stable idempotency or truly read-only requests are the *only* retry path.
                if index + 1 < attempts:
                    time.sleep(0.02)
        self.ledger.complete(call, generation, "unknown", None, "uncertain_commit")
        return self._current(call)

    def _current(self, call: Call) -> tuple[int, dict]:
        record = self.ledger.record(call)
        if record and record.state == "confirmed":
            return 200, reply("replay", "confirmed", result=record.result)
        return 409, reply("stop", record.state if record else "unknown",
                          reason="无足够的副作用证据，需要人工检查")

    def compensate(self, raw: object, *, approved: bool = False) -> tuple[int, dict]:
        """Manual gate is mandatory; a recovery policy never calls this itself."""
        if not approved:
            return 403, reply("reject", "approval_required", reason="需要人工批准")
        try:
            call = Call.parse(raw)
        except BadCall as exc:
            return 400, reply("reject", "invalid", reason=str(exc))
        policy = TOOLS.get(call.tool)
        if policy is None or policy.effect != Effect.REVERSIBLE:
            return 403, reply("stop", "forbidden", reason="没有已登记的补偿动作")
        try:
            claimed = self.ledger.claim_compensation(call)
        except Conflict as exc:
            return 409, reply("stop", "conflict", reason=str(exc))
        if claimed is None:
            return 409, reply("stop", "conflict", reason="无可补偿的已确认效果")
        generation, original = claimed
        try:
            confirmed = self.upstream.compensate(call, original)
        except UncertainResult:
            confirmed = False
        self.ledger.finish_compensation(call, generation, confirmed)
        if confirmed:
            return 200, reply("compensate", "compensated", result=original)
        return 409, reply("stop", "compensation_unknown", reason="补偿结果不明，不可盲目重试")
