"""Public interface and cross-language safety checks."""
