"""Public Gateway interface: identity, safety gate and durable effect transitions."""

import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from raguard.gateway import Gateway
from raguard.ledger import Ledger
from raguard.model import Call
from raguard.policy import Effect


def request(tool="orders.create", step="order", intent="order", deps=(), args=None):
    if args is None:
        args = ({"sku": "s", "quantity": 1} if tool == "orders.create"
                else {"sku": "s"} if tool == "inventory.read" else {"message": "test"})
    return {"tenant": "t", "principal": "p", "task": "task", "step": step,
            "intent": intent, "tool": tool, "args": args, "dependencies": list(deps)}


class FakeUpstream:
    """Interface-level test adapter, with an actual mutable external state."""
    def __init__(self, fail_after=False, cannot_read=False, delay=0):
        self.effects = {}
        self.executions = 0
        self.compensations = 0
        self.fail_after = fail_after
        self.cannot_read = cannot_read
        self.delay = delay
        self.lock = threading.Lock()

    def execute(self, call, policy):
        from raguard.transport import UncertainResult
        if self.delay:
            time.sleep(self.delay)
        with self.lock:
            if policy.effect == Effect.IDEMPOTENT and call.stable_key in self.effects:
                return self.effects[call.stable_key]
            self.executions += 1
            result = {"effect_id": str(self.executions)}
            self.effects[call.stable_key] = result
            if self.fail_after:
                raise UncertainResult("response lost after commit")
            return result

    def readback(self, call, policy):
        if self.cannot_read or not policy.readback:
            return None
        return self.effects.get(call.stable_key)

    def compensate(self, call, result):
        self.compensations += 1
        return True


class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.ledger = Ledger(str(Path(self.tmp.name) / "ledger.db"))

    def gateway(self, **kwargs):
        upstream = FakeUpstream(**kwargs)
        return Gateway(self.ledger, upstream), upstream

    def test_write_after_lost_response_uses_positive_evidence(self):
        gateway, upstream = self.gateway(fail_after=True)
        code, result = gateway.call(request())
        self.assertEqual((code, result["action"]), (200, "replay"))
        self.assertEqual(gateway.call(request())[0], 200)
        self.assertEqual(upstream.executions, 1)

    def test_opaque_write_after_lost_response_never_retries(self):
        gateway, upstream = self.gateway(fail_after=True)
        notification = request("notifications.send")
        self.assertEqual(gateway.call(notification)[0], 409)
        self.assertEqual(gateway.call(notification)[0], 409)
        self.assertEqual(upstream.executions, 1)

    def test_idempotent_write_can_retry_if_readback_unavailable(self):
        gateway, upstream = self.gateway(fail_after=True, cannot_read=True)
        self.assertEqual(gateway.call(request())[0], 409)
        self.assertEqual(upstream.executions, 1)
        # Server side stable key still prevents duplicates on repeated submissions.
        self.assertEqual(gateway.call(request())[0], 409)
        self.assertEqual(upstream.executions, 1)

    def test_intent_changes_are_not_merged(self):
        gateway, upstream = self.gateway()
        self.assertEqual(gateway.call(request())[0], 200)
        changed = request(args={"sku": "s", "quantity": 2})
        code, _ = gateway.call(changed)
        self.assertEqual(code, 409)
        self.assertEqual(upstream.executions, 1)

    def test_dependency_must_be_confirmed(self):
        gateway, _ = self.gateway()
        dependent = request(deps=["inventory"])
        self.assertEqual(gateway.call(dependent)[0], 409)
        self.assertEqual(gateway.call(request("inventory.read", "inventory", "inventory"))[0], 200)
        self.assertEqual(gateway.call(dependent)[0], 200)

    def test_stale_owner_is_fenced_after_idempotent_takeover(self):
        gateway, upstream = self.gateway()
        call = request()
        old, fresh = self.ledger.claim(Call.parse(call))
        self.assertTrue(fresh)
        self.assertEqual(old.generation, 1)
        takeover = Gateway(self.ledger, upstream, lease_seconds=0)
        self.assertEqual(takeover.call(call)[0], 200)
        # Late request owner cannot corrupt the new generation's confirmed state.
        self.assertFalse(self.ledger.complete(Call.parse(call), 1, "unknown", None, "old_worker"))
        self.assertEqual(self.ledger.record(Call.parse(call)).state, "confirmed")

    def test_stale_opaque_owner_does_not_get_dispatched(self):
        gateway, upstream = self.gateway()
        call = request("notifications.send")
        self.ledger.claim(Call.parse(call))
        takeover = Gateway(self.ledger, upstream, lease_seconds=0)
        self.assertEqual(takeover.call(call)[0], 409)
        self.assertEqual(upstream.executions, 0)

    def test_parallel_callers_dispatch_one_effect(self):
        gateway, upstream = self.gateway(delay=0.1)
        with ThreadPoolExecutor(max_workers=12) as pool:
            statuses = list(pool.map(lambda _: gateway.call(request())[0], range(24)))
        self.assertTrue(all(status in (200, 202) for status in statuses))
        self.assertEqual(upstream.executions, 1)

    def test_compensation_needs_approval_and_single_claim(self):
        gateway, upstream = self.gateway()
        ticket = request("tickets.create")
        self.assertEqual(gateway.call(ticket)[0], 200)
        self.assertEqual(gateway.compensate(ticket)[0], 403)
        with ThreadPoolExecutor(max_workers=8) as pool:
            statuses = list(pool.map(lambda _: gateway.compensate(ticket, approved=True)[0], range(8)))
        self.assertEqual(statuses.count(200), 1)
        self.assertEqual(upstream.compensations, 1)
        self.assertEqual(gateway.call(ticket)[0], 409)

    def test_compensation_blocks_confirmed_descendants(self):
        gateway, upstream = self.gateway()
        ticket = request("tickets.create", "ticket", "ticket")
        self.assertEqual(gateway.call(ticket)[0], 200)
        downstream = request("inventory.read", "child", "child", ["ticket"])
        self.assertEqual(gateway.call(downstream)[0], 200)
        self.assertEqual(gateway.compensate(ticket, approved=True)[0], 409)
        self.assertEqual(upstream.compensations, 0)

    def test_replay_cannot_resurrect_compensated_effect(self):
        ticket = request("tickets.create")
        upstream = FakeUpstream()
        gateway = Gateway(self.ledger, upstream)
        self.assertEqual(gateway.call(ticket)[0], 200)
        original_readback = upstream.readback
        triggered = False

        def racing_readback(call, policy):
            nonlocal triggered
            if not triggered:
                triggered = True
                # Another user compensates *after* replay started.
                self.assertEqual(gateway.compensate(ticket, approved=True)[0], 200)
            return original_readback(call, policy)

        upstream.readback = racing_readback
        self.assertEqual(gateway.call(ticket)[0], 409)
        self.assertEqual(self.ledger.record(Call.parse(ticket)).state, "compensated")

    def test_malformed_and_unknown_tool_rejected(self):
        gateway, upstream = self.gateway()
        self.assertEqual(gateway.call({"foo": "bar"})[0], 400)
        self.assertEqual(gateway.call(request(tool="arbitrary.shell"))[0], 403)
        self.assertEqual(upstream.executions, 0)


if __name__ == "__main__":
    unittest.main()
