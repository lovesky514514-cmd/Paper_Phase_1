# 排错入口

| 现象 | 先检查 | 处理 |
|---|---|---|
| Python 找不到模块 | 在项目根目录运行 | `cd 01code` 后执行 `python -m raguard.http` |
| `go` / `python` 不是命令 | `go version`、`python --version` | 安装 README 对应版本并加入 PATH |
| 连接 8181 失败 | Go 沙箱窗口和端口占用 | 启动 `cd mock && go run .`；检查防火墙与端口 |
| 连接 8088 失败 | Python 网关窗口 | `python -m raguard.http` |
| HTTP 202 | 存在未完成调用 | 稍后以**同一意图**查询，不要生成新 ID |
| HTTP 409 `unknown` | 提交是否不确定 | 查看 Go 沙箱状态或业务回执；**勿盲目换 ID 重试** |
| HTTP 409 `conflict` | 同一意图更换了字段 | 新业务动作应使用新意图，旧动作保持原请求一致 |
| `unverifiable` | 回读不可用或沙箱被重启 | 停止自动恢复，核查两端状态；完整新实验同时重置沙箱与账本 |
| 单元测试失败 | Python 版本、路径、权限 | 运行 `python -m unittest discover -s tests -v` 定位测试 |
| Go 检查失败 | `go test` 的首条错误 | 在 `mock/` 中运行 `go test -v ./...` |

逐文件错误定位和修复步骤见 [files](files/)。若有安全性质回归失败，先停止实验；不要为了跑通改为无条件重试。所有诊断只针对**本地假服务**。
