# raguard/model.py

**用途**：对应源文件的局部排错入口。

- **症状**：相同业务意图出现 conflict。
- **如何定位**：测试 `python -m unittest tests.test_gateway.GatewayTests.test_intent_changes_are_not_merged -v`。
- **修复建议**：核对 principal、args、step、dependencies；不同意图须使用新 ID，不能绕过指纹。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
