# scripts/check_windows.bat

**用途**：对应源文件的局部排错入口。

- **症状**：Windows 自检中断。
- **如何定位**：从 cmd 手动启动 `scripts\check_windows.bat` 查看第一条 FAIL。
- **修复建议**：核对 Python/Go 安装与当前文件路径；修复后再自检。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
