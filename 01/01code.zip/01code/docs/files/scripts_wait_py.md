# scripts/wait.py

**用途**：启动后确认 8181 Go 沙箱真正可连接。

- **症状**：一直提示“未就绪”或连接失败。
- **如何定位**：查看 Go 沙箱窗口，访问 `http://127.0.0.1:8181/healthz`。
- **修复建议**：清理端口冲突、检查 Go 编译；不要通过关闭等待来掩盖错误。
- **复核**：运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`。
