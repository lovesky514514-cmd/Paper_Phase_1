# scripts/start_windows.bat

**用途**：对应源文件的局部排错入口。

- **症状**：Windows 运行后窗口退出。
- **如何定位**：先在 cmd 手动运行 `scripts\start_windows.bat` 看错误，执行 `where go` 和 `where python`。
- **修复建议**：检查 PATH、端口及 Windows 安全软件；确保不在受限系统目录解压。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
