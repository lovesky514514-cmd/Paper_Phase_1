# mock/main_test.go

**用途**：对应源文件的局部排错入口。

- **症状**：Go 幂等测试失败。
- **如何定位**：在 `mock/` 运行 `go test -v`。
- **修复建议**：检查服务端 key 冲突验证；修复后重新运行跨语言测试。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
