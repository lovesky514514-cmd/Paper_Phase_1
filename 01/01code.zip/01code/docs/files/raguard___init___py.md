# raguard/__init__.py

**用途**：对应源文件的局部排错入口。

- **症状**：包无法导入。
- **如何定位**：从项目根目录执行 `python -c "import raguard"`。
- **修复建议**：检查目录是否被移动；不要直接执行包内源文件。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
