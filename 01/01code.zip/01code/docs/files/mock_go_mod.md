# mock/go.mod

**用途**：对应源文件的局部排错入口。

- **症状**：Go 模块/版本报错。
- **如何定位**：运行 `go version`，应至少 Go 1.21。
- **修复建议**：安装符合版本的 Go；不要随意引入远端依赖。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
