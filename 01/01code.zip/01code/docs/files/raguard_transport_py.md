# raguard/transport.py

**用途**：对应源文件的局部排错入口。

- **症状**：上游请求失败或结果不可核验。
- **如何定位**：检查 `http://127.0.0.1:8181/healthz`、readback 的 intent_key/fingerprint。
- **修复建议**：启动沙箱，确认相同意图键；查不到不能作未执行证明。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
