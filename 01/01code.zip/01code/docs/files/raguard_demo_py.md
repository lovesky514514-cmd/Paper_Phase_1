# raguard/demo.py

**用途**：对应源文件的局部排错入口。

- **症状**：第二次订单没有回放。
- **如何定位**：确认正在使用同一个 task/intent；必要时设置 `RAGUARD_DEMO_TASK`。
- **修复建议**：先查看首个结果和本地账本；别通过变更 ID 来隐藏重复创建。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
