# scripts/start.sh

**用途**：对应源文件的局部排错入口。

- **症状**：Linux/macOS 一键启动失败。
- **如何定位**：在项目根目录运行 `sh scripts/start.sh` 看第一条错误。
- **修复建议**：检查 python3/go、8181 和 8088 是否占用。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
