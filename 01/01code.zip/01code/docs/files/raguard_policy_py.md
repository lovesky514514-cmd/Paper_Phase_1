# raguard/policy.py

**用途**：对应源文件的局部排错入口。

- **症状**：写操作被 Stop 而非重试。
- **如何定位**：核对 `TOOLS` 的 effect 类型和服务端是否强制幂等键。
- **修复建议**：不要仅因需要提高完成率就改成 READ 或 IDEMPOTENT；先做后端幂等保证。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
