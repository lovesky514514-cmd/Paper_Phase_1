# raguard/gateway.py

**用途**：对应源文件的局部排错入口。

- **症状**：未知提交自动重试 / 200 回放旧副作用。
- **如何定位**：跑 `tests.test_gateway` 与 `tests.test_end_to_end` 的高风险用例。
- **修复建议**：先查状态转换和 CAS，复现后补回归测试；禁止移除安全门。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
