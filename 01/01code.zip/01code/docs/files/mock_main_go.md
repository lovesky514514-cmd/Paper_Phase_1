# mock/main.go

**用途**：对应源文件的局部排错入口。

- **症状**：沙箱故障注入不生效。
- **如何定位**：核对 `MOCK_FAULT_ONCE` 写法 `orders.create:after` 且仅生效一次。
- **修复建议**：重启沙箱并同时重置对应的测试账本；切勿对真实服务注入。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
