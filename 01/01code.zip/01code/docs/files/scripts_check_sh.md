# scripts/check.sh

**用途**：对应源文件的局部排错入口。

- **症状**：Unix 自检失败。
- **如何定位**：运行 `sh scripts/check.sh` 查看首条编译/测试失败。
- **修复建议**：按异常对应文件的帮助页修复，不要跳过失败测试。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
