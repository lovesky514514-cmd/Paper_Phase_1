# tests/__init__.py

**用途**：对应源文件的局部排错入口。

- **症状**：测试 import 报错。
- **如何定位**：从根目录运行 `python -m unittest discover -s tests -v`。
- **修复建议**：确认包目录完整，勿从 tests 子目录启动。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
