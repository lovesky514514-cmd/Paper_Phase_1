# raguard/ledger.py

**用途**：对应源文件的局部排错入口。

- **症状**：数据库 locked / 旧执行者覆盖新状态。
- **如何定位**：运行 `python -m unittest tests.test_gateway -v`，检查 data 目录可写和是否有多进程残留。
- **修复建议**：结束残留进程；保留数据库证据；确需重置时须同时重置上游沙箱。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
