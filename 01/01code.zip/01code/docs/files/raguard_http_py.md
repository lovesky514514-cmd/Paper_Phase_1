# raguard/http.py

**用途**：对应源文件的局部排错入口。

- **症状**：返回 400/401/403 或监听失败。
- **如何定位**：检查 Content-Type、请求 JSON、RAGUARD_API_KEY、端口 8088。
- **修复建议**：纠正字段和本地配置；避免暴露非 loopback 监听。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
