# tests/test_end_to_end.py

**用途**：对应源文件的局部排错入口。

- **症状**：跨语言测试连接失败。
- **如何定位**：检查 `go version`、编译权限和回环端口。
- **修复建议**：结束残留沙箱进程、解除端口冲突；若 Go 不存在先安装 Go。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
