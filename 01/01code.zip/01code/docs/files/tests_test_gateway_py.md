# tests/test_gateway.py

**用途**：对应源文件的局部排错入口。

- **症状**：单测非预期失败。
- **如何定位**：先用 `python -m unittest tests.test_gateway -v` 找到具体安全场景。
- **修复建议**：复现、找失败状态转换、修复，再执行全套检查。
- **复核**：修复后运行 `scripts/check_windows.bat` 或 `sh scripts/check.sh`，不得跳过失败用例。
