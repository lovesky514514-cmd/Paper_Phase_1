# 01code · RAGuard

**目标**：研究 Agent 工具调用失败后，如何在不重复危险写入的前提下恢复。当前是本地 **v0 研究骨架**，不是生产网关，也不是已完成的 SCI 研究结果。

**安装**：Python **3.11+**、Go **1.21+**，无需 `pip install`，无需 API Key 或真实模型。

| 操作 | Windows | macOS / Linux |
|---|---|---|
| 启动 | 双击 `scripts/start_windows.bat` | `sh scripts/start.sh` |
| 演示（另开终端，在项目根目录） | `python -m raguard.demo` | `python3 -m raguard.demo` |
| 自检 | 双击 `scripts/check_windows.bat` | `sh scripts/check.sh` |

演示会查库存、创建模拟订单，再重复同一订单请求；第二次应该回放，不应再次创建订单。网关默认端口 **8088**，Go 沙箱默认端口 **8181**。

首次运行 Go 需要编译。**只限本机假数据**；切勿连接真实支付、邮件或业务系统。若重启 Go 沙箱，会清空其内存状态；做全新试验时请同时清理 `data/ledger.sqlite3*`，不要仅重置其中一端。

遇到问题先看 [排错索引](docs/DEBUG_INDEX.md)，设计边界见 [DESIGN](docs/DESIGN.md)，接口见 [USAGE](docs/USAGE.md)，逐文件说明在 `docs/files/`。
