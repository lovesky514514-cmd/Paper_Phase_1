package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func post(t *testing.T, origin, raw string) int {
	t.Helper()
	resp, err := http.Post(origin+"/v1/execute", "application/json", strings.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	return resp.StatusCode
}

func TestStableIdempotencyKey(t *testing.T) {
	server := httptest.NewServer(newSandbox("", false).routes())
	defer server.Close()
	raw := `{"tool_id":"orders.create","intent_key":"key","idempotency_key":"key","fingerprint":"f","args":{"sku":"s","quantity":1}}`
	if post(t, server.URL, raw) != 200 || post(t, server.URL, raw) != 200 {
		t.Fatal("valid stable-key writes must succeed")
	}
	counts, err := http.Get(server.URL + "/v1/counts")
	if err != nil {
		t.Fatal(err)
	}
	defer counts.Body.Close()
	var value map[string]int
	if err := json.NewDecoder(counts.Body).Decode(&value); err != nil {
		t.Fatal(err)
	}
	if value["orders.create"] != 1 {
		t.Fatalf("duplicated side effect: %v", value)
	}
	modified := strings.Replace(raw, `"fingerprint":"f"`, `"fingerprint":"other"`, 1)
	if post(t, server.URL, modified) != 409 {
		t.Fatal("identity conflict not rejected")
	}
}

func TestReadbackReturnsOnlyMatchingPositiveEvidence(t *testing.T) {
	server := httptest.NewServer(newSandbox("", false).routes())
	defer server.Close()
	raw := `{"tool_id":"tickets.create","intent_key":"i","fingerprint":"f","args":{"message":"hello"}}`
	if post(t, server.URL, raw) != 200 {
		t.Fatal("ticket create failed")
	}
	res, err := http.Get(server.URL + "/v1/effects?tool_id=tickets.create&intent_key=i")
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	var value map[string]any
	if err := json.NewDecoder(res.Body).Decode(&value); err != nil {
		t.Fatal(err)
	}
	if value["status"] != "confirmed" || value["fingerprint"] != "f" {
		t.Fatal(value)
	}
}
