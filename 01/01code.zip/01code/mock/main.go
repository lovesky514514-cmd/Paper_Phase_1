// Local-only fake tools. No payments, email delivery or external connections.
package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
)

type request struct {
	Tool        string         `json:"tool_id"`
	Intent      string         `json:"intent_key"`
	Idempotency string         `json:"idempotency_key"`
	Fingerprint string         `json:"fingerprint"`
	Args        map[string]any `json:"args"`
}

type effect struct {
	Fingerprint string
	Result      map[string]any
	Cancelled   bool
}

type sandbox struct {
	mu         sync.Mutex
	effects    map[string][]effect
	commits    map[string]int
	fault      string
	faultFired bool
	noReadback bool
}

func newSandbox(fault string, noReadback bool) *sandbox {
	return &sandbox{
		effects: make(map[string][]effect), commits: make(map[string]int),
		fault: fault, noReadback: noReadback,
	}
}

func respond(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func decode(w http.ResponseWriter, r *http.Request, target any) error {
	r.Body = http.MaxBytesReader(w, r.Body, 8192)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		return fmt.Errorf("unexpected trailing JSON")
	}
	return nil
}

func (s *sandbox) disconnect(w http.ResponseWriter) {
	// Distinguish an absent response from a successful execution response.
	if hijacker, ok := w.(http.Hijacker); ok {
		conn, _, err := hijacker.Hijack()
		if err == nil {
			_ = conn.Close()
		}
	}
}

func (s *sandbox) inject(w http.ResponseWriter, tool, phase string) bool {
	if s.faultFired || s.fault != tool+":"+phase {
		return false
	}
	s.faultFired = true
	s.disconnect(w)
	return true
}

func valid(call request) bool {
	switch call.Tool {
	case "inventory.read":
		sku, ok := call.Args["sku"].(string)
		return ok && sku != ""
	case "orders.create":
		sku, ok := call.Args["sku"].(string)
		quantity, okQty := call.Args["quantity"].(float64)
		return ok && sku != "" && okQty && quantity >= 1 && quantity <= 100 && quantity == float64(int(quantity))
	case "tickets.create", "notifications.send":
		msg, ok := call.Args["message"].(string)
		return ok && len(msg) > 0 && len(msg) <= 500
	default:
		return false
	}
}

func (s *sandbox) execute(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		respond(w, 405, map[string]string{"error": "method"})
		return
	}
	var call request
	if decode(w, r, &call) != nil || call.Intent == "" || call.Fingerprint == "" || call.Args == nil {
		respond(w, 400, map[string]string{"error": "invalid_request"})
		return
	}
	if !valid(call) {
		respond(w, 422, map[string]string{"error": "invalid_arguments"})
		return
	}
	if call.Tool == "orders.create" && call.Idempotency != call.Intent {
		respond(w, 400, map[string]string{"error": "idempotency_required"})
		return
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	key := call.Tool + ":" + call.Intent
	// Server-side stable-key behavior is essential to the safety assumption.
	if call.Tool == "orders.create" && len(s.effects[key]) > 0 {
		first := s.effects[key][0]
		if first.Fingerprint != call.Fingerprint {
			respond(w, 409, map[string]string{"error": "key_conflict"})
			return
		}
		respond(w, 200, map[string]any{"ok": true, "intent_key": call.Intent, "result": first.Result})
		return
	}
	if s.inject(w, call.Tool, "before") {
		return
	}
	s.commits[call.Tool]++
	result := map[string]any{"tool_id": call.Tool}
	switch call.Tool {
	case "inventory.read":
		result["sku"] = call.Args["sku"]
		result["in_stock"] = true
	case "orders.create":
		result["order_id"] = fmt.Sprintf("order-%04d", s.commits[call.Tool])
	case "tickets.create":
		result["ticket_id"] = fmt.Sprintf("ticket-%04d", s.commits[call.Tool])
	case "notifications.send":
		result["delivered"] = true
	}
	if call.Tool != "inventory.read" {
		s.effects[key] = append(s.effects[key], effect{Fingerprint: call.Fingerprint, Result: result})
	}
	// Fault-after-commit is the core ambiguous-commit experiment.
	if s.inject(w, call.Tool, "after") {
		return
	}
	respond(w, 200, map[string]any{"ok": true, "intent_key": call.Intent, "result": result})
}

func (s *sandbox) readback(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		respond(w, 405, map[string]string{"error": "method"})
		return
	}
	tool, intent := r.URL.Query().Get("tool_id"), r.URL.Query().Get("intent_key")
	if tool != "orders.create" && tool != "tickets.create" {
		respond(w, 403, map[string]string{"status": "unsupported"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.noReadback {
		respond(w, 503, map[string]string{"status": "unavailable"})
		return
	}
	records := s.effects[tool+":"+intent]
	if len(records) != 1 || records[0].Cancelled {
		respond(w, 200, map[string]string{"status": "unknown"})
		return
	}
	respond(w, 200, map[string]any{
		"status": "confirmed", "intent_key": intent,
		"fingerprint": records[0].Fingerprint, "result": records[0].Result,
	})
}

func (s *sandbox) compensate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		respond(w, 405, map[string]string{"error": "method"})
		return
	}
	var call struct {
		Tool     string `json:"tool_id"`
		Intent   string `json:"intent_key"`
		TicketID string `json:"ticket_id"`
	}
	if decode(w, r, &call) != nil || call.Tool != "tickets.create" {
		respond(w, 400, map[string]string{"error": "invalid_compensation"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	key := call.Tool + ":" + call.Intent
	records := s.effects[key]
	if len(records) != 1 || records[0].Result["ticket_id"] != call.TicketID || records[0].Cancelled {
		respond(w, 409, map[string]string{"error": "not_compensatable"})
		return
	}
	records[0].Cancelled = true
	s.effects[key] = records
	respond(w, 200, map[string]string{"status": "compensated", "intent_key": call.Intent})
}

func (s *sandbox) counts(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		respond(w, 405, map[string]string{"error": "method"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	respond(w, 200, s.commits)
}

func (s *sandbox) routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		respond(w, 200, map[string]string{"status": "ok"})
	})
	mux.HandleFunc("/v1/execute", s.execute)
	mux.HandleFunc("/v1/effects", s.readback)
	mux.HandleFunc("/v1/compensate", s.compensate)
	mux.HandleFunc("/v1/counts", s.counts) // Local test-only observability.
	return mux
}

func main() {
	address := os.Getenv("MOCK_ADDR")
	if address == "" {
		address = "127.0.0.1:8181"
	}
	if !strings.HasPrefix(address, "127.0.0.1:") {
		log.Fatal("mock only supports loopback address")
	}
	log.Printf("sandbox at %s", address)
	log.Fatal(http.ListenAndServe(address,
		newSandbox(os.Getenv("MOCK_FAULT_ONCE"), os.Getenv("MOCK_DISABLE_READBACK") == "1").routes()))
}
