#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 -m compileall -q raguard tests
python3 -m unittest discover -s tests -v
(cd mock && go test ./... && go vet ./...)
echo 'Checks passed.'
