@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0.."
where python >nul 2>nul || (echo [FAIL] 请安装 Python 3.11+ & exit /b 1)
where go >nul 2>nul || (echo [FAIL] 请安装 Go 1.21+ & exit /b 1)
python -m compileall -q raguard tests || exit /b 1
python -m unittest discover -s tests -v || exit /b 1
pushd mock
go test ./... || (popd & exit /b 1)
go vet ./... || (popd & exit /b 1)
popd
echo [PASS] 检查全部通过
