#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
command -v go >/dev/null || { echo 'Install Go >= 1.21'; exit 1; }
command -v python3 >/dev/null || { echo 'Install Python >= 3.11'; exit 1; }
mkdir -p data
(cd mock && go build -o ../data/raguard-mock .)
./data/raguard-mock &
mock_pid=$!
trap 'kill "$mock_pid" 2>/dev/null || true' EXIT INT TERM
python3 scripts/wait.py
echo 'In another terminal: python3 -m raguard.demo'
python3 -m raguard.http
