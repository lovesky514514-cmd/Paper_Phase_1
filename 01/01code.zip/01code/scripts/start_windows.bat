@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0.."
where python >nul 2>nul || (echo 请安装 Python 3.11+ & exit /b 1)
where go >nul 2>nul || (echo 请安装 Go 1.21+ & exit /b 1)
if not exist data mkdir data
pushd mock
go build -o ..\data\raguard-mock.exe .
if errorlevel 1 (popd & echo Go 编译失败 & exit /b 1)
popd
echo 正在启动本地 Go 沙箱...
start "RAGuard sandbox" /D "%CD%" cmd /k "data\raguard-mock.exe"
python scripts\wait.py || exit /b 1
echo 已启动，另开终端执行：python -m raguard.demo
echo 当前窗口正在运行 Python 网关，退出使用 Ctrl+C
echo 关闭时也请关闭 Go 沙箱窗口。
python -m raguard.http
